# LifeFlow - Blood Donation Platform

## Overview

LifeFlow is a full-stack blood donation management platform that connects blood donors with people in need. The application supports donor registration and discovery, blood requests with urgency levels, donation tracking, blood camp management, real-time chat between donors and requesters, a rewards/badges system, and an admin panel for platform management.

Key features:
- User registration and donor profile management
- Blood donor search by blood group, country, state/region, and city with compatibility matching
- Blood request creation with urgency levels (normal/urgent/emergency)
- Donation history tracking with reward points and downloadable certificates
- Blood camp discovery and registration
- In-app messaging between donors and requesters (polling-based)
- Notifications system
- Gamification with badges and reward points
- Full admin panel with dashboard, user/request/camp management, and reports
- **Available Blood Donors** section on post-login Dashboard (2-column grid, Call/WhatsApp buttons, profile photos, blood group badge, green availability dot)
- **Admin Donor Management** enhancements: photo upload (camera button → FileReader base64), Activate/Deactivate toggle, Available/Unavailable toggle, Delete with confirmation
- **4-column footer** on landing page (admin-managed via `/admin/footer`)
- Public featured donors API at `/api/public/donors/featured` (no auth required)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
The project uses a monorepo layout with three main directories:
- `client/` — React frontend (Vite)
- `server/` — Express backend (Node.js)
- `shared/` — Shared TypeScript types and database schema

The `shared/schema.ts` file is used by both frontend and backend, ensuring type safety across the stack without code duplication.

### Frontend Architecture

**Framework:** React 18 with TypeScript, bundled via Vite.

**Routing:** Uses `wouter` (lightweight React router). Routes are defined in `client/src/App.tsx` with two protected route wrappers — one for regular users and one for admins.

**State Management:** TanStack Query (React Query) handles all server state. No global client-side state store (Redux/Zustand) is used. Auth state is stored in `localStorage` (token, user object, admin object).

**UI Components:** shadcn/ui component library built on Radix UI primitives, styled with Tailwind CSS. Custom theme uses CSS variables with a red/blood-donation primary color. Components live in `client/src/components/ui/`.

**Layout:**
- Mobile users see a bottom navigation bar (`MobileNav` component)
- Admin users see a sidebar layout (`AppSidebar` component using shadcn Sidebar)
- The app is designed mobile-first with a max-width constraint on content

**Key Custom Components:**
- `BloodGroupBadge` — color-coded blood group display
- `DonorCard` — donor profile card with contact/message actions
- `MobileNav` — fixed bottom nav for mobile users

### Backend Architecture

**Framework:** Express.js on Node.js, written in TypeScript, run with `tsx` in development.

**Entry Point:** `server/index.ts` creates the HTTP server and sets up middleware. In development, Vite middleware is attached for HMR. In production, static files are served from `dist/public/`.

**Routing:** All API routes are registered in `server/routes.ts` via `registerRoutes()`. Routes are prefixed with `/api`.

**Authentication:**
- JWT-based authentication (no sessions/cookies for users)
- Tokens stored on the client in `localStorage`, sent as `Authorization: Bearer <token>` header
- `authMiddleware` verifies JWT on protected routes
- `adminMiddleware` additionally checks the `role: "admin"` claim
- Passwords hashed with bcryptjs (10 rounds)
- Separate user and admin auth flows (`/api/auth/*` vs `/api/admin/auth/*`)
- Token expiry: 30 days
- **Email Verification:** New users must verify their email via a 6-digit OTP before logging in. OTP sent via Gmail SMTP (nodemailer). Routes: `POST /api/auth/verify-email`, `POST /api/auth/resend-verification`. Admin-created users bypass this and are auto-verified.
- **Forgot Password:** Identity verified via email + registered phone number. Route: `POST /api/auth/reset-password`

**Data Layer:** All database access goes through the `storage` object defined in `server/storage.ts`, which implements the `IStorage` interface. This provides a clean abstraction — routes call storage methods, not raw SQL.

**Database Seeding:** `server/seed.ts` seeds initial admin account and sample data on first run (checks if `adminUsers` table is empty before seeding).

**Build:** The `script/build.ts` file builds both the Vite frontend and the Express backend (bundled via esbuild into `dist/index.cjs`). Commonly-used server dependencies are bundled to reduce cold start time; others are externalized.

### Database

**ORM:** Drizzle ORM with PostgreSQL dialect.

**Schema** (defined in `shared/schema.ts`):
- `users` — donor/requester profiles with blood group, location, availability, donation count, reward points
- `adminUsers` — separate admin accounts with role field
- `bloodRequests` — blood requests with urgency, status, and blood group enums
- `donations` — donation records with certificate ID
- `bloodCamps` — donation camp events with registration tracking
- `campRegistrations` — user registrations for camps
- `chatMessages` — messages scoped to a blood request
- `notifications` — user notification inbox
- `badges` + `userBadges` — gamification badge definitions and awards
- `emailVerifications` — OTP records for email verification (userId, otp, expiresAt, used)

**Enums:** PostgreSQL native enums for `blood_group`, `request_status`, `urgency`, `donation_status`, `notification_type`, `badge_level`.

**Migrations:** Managed via `drizzle-kit` (`db:push` command). Migration files output to `./migrations/`.

### Real-time Features

Chat is implemented via client-side polling (`refetchInterval: 3000` in TanStack Query) rather than WebSockets, keeping the implementation simple. Messages are marked as read when a chat room is opened.

### Chat System Flow
1. **Request-based chat:** Blood requests create a conversation context. Donor and requester chat within a specific `requestId`. Route: `/chat/:requestId`
2. **Donor-to-Donor (D2D) direct chat:** Any user can directly message another user without a blood request context. `requestId` is `null` for D2D messages. Route: `/direct-chat/:userId`
3. Conversations list (`/api/conversations`) aggregates last messages, returning both types with `isDirect: boolean`, `requestId`, and `directUserId` fields
4. D2D chats are accessible via "Chat" button on `DonorProfile` page and `DonorCard` component (Find Donors page)
5. Chat inbox (`/chat`) shows both request-based and direct conversations. Direct ones show a "Direct" badge
6. API routes: `GET /api/direct-chat/:userId`, `POST /api/direct-chat`, `POST /api/direct-chat/:userId/read`

## External Dependencies

### Core Runtime Dependencies
- **PostgreSQL** — primary database (connection via `DATABASE_URL` env var using `pg` pool)
- **Drizzle ORM** — type-safe database access, schema management
- **Express** — HTTP server framework
- **jsonwebtoken** — JWT creation and verification
- **bcryptjs** — password hashing
- **nanoid** — unique ID generation (used in Vite dev server)

### Frontend Libraries
- **React 18** — UI framework
- **Vite** — dev server and build tool
- **TanStack Query v5** — server state management and data fetching
- **wouter** — client-side routing
- **Tailwind CSS** — utility-first styling
- **shadcn/ui + Radix UI** — accessible UI component primitives
- **Recharts** — charts for admin reports
- **react-hook-form + zod** — form state and validation
- **date-fns** — date formatting utilities
- **lucide-react** — icon library

### Build & Dev Tools
- **tsx** — TypeScript execution for development
- **esbuild** — server bundling for production
- **drizzle-kit** — schema migration tooling
- **@replit/vite-plugin-runtime-error-modal** — dev error overlay (Replit-specific)
- **@replit/vite-plugin-cartographer** — Replit dev tool (dev only)

### Environment Variables Required
- `DATABASE_URL` — PostgreSQL connection string (required, throws on missing)
- `SESSION_SECRET` — JWT signing secret (falls back to hardcoded default if not set — should be set in production)
- `GMAIL_USER` — Gmail address for sending emails (`mahiralam801@gmail.com`)
- `GMAIL_APP_PASSWORD` — Gmail App Password for SMTP auth (stored as secret)