import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MobileNav } from "@/components/MobileNav";
import { DonorCard } from "@/components/DonorCard";
import { Skeleton } from "@/components/ui/skeleton";
import { BLOOD_GROUPS, getStoredUser } from "@/lib/auth";
import { Search, MapPin, Filter, Users, ChevronDown, Zap, X, Droplets, Globe } from "lucide-react";
import type { User } from "@shared/schema";
import { COUNTRIES } from "@/lib/countries";

const COMPATIBLE: Record<string, string[]> = {
  "A+":  ["A+", "A-", "O+", "O-"],
  "A-":  ["A-", "O-"],
  "B+":  ["B+", "B-", "O+", "O-"],
  "B-":  ["B-", "O-"],
  "AB+": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
  "AB-": ["A-", "B-", "AB-", "O-"],
  "O+":  ["O+", "O-"],
  "O-":  ["O-"],
};

const BG_COLORS: Record<string, string> = {
  "A+":  "bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400",
  "A-":  "bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-900/30 dark:text-rose-400",
  "B+":  "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-400",
  "B-":  "bg-indigo-100 text-indigo-700 border-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-400",
  "AB+": "bg-purple-100 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-400",
  "AB-": "bg-violet-100 text-violet-700 border-violet-200 dark:bg-violet-900/30 dark:text-violet-400",
  "O+":  "bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-400",
  "O-":  "bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-400",
};

function DonorSkeleton() {
  return (
    <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
      <div className="flex items-start gap-3">
        <Skeleton className="w-16 h-16 rounded-full flex-shrink-0" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-3 w-20" />
          <Skeleton className="h-3 w-28" />
        </div>
        <Skeleton className="h-7 w-12 rounded-full" />
      </div>
      <div className="flex gap-2 pt-2">
        <Skeleton className="h-8 flex-1 rounded-lg" />
        <Skeleton className="h-8 flex-1 rounded-lg" />
      </div>
    </div>
  );
}

export default function FindDonors() {
  const [, setLocation] = useLocation();
  const currentUser = getStoredUser();

  const [bloodGroup, setBloodGroup] = useState("all");
  const [selectedCountry, setSelectedCountry] = useState("all");
  const [selectedState, setSelectedState] = useState("all");
  const [selectedCity, setSelectedCity] = useState("all");
  const [compatibleMode, setCompatibleMode] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [nearbyAutoSearched, setNearbyAutoSearched] = useState(false);

  const { data: locationData } = useQuery<{ countries: string[]; states: string[]; cities: Record<string, string[]> }>({
    queryKey: ["/api/donors/locations"],
  });

  const availableStates = useMemo(() => {
    if (!selectedCountry || selectedCountry === "all") return locationData?.states || [];
    return locationData?.statesByCountry?.[selectedCountry] || locationData?.states || [];
  }, [locationData, selectedCountry]);

  const availableCities = useMemo(() => {
    if (!selectedState || selectedState === "all") return [];
    return locationData?.cities[selectedState] || [];
  }, [locationData, selectedState]);

  const params = useMemo(() => {
    const p = new URLSearchParams();
    if (bloodGroup && bloodGroup !== "all") p.set("bloodGroup", bloodGroup);
    if (selectedCountry && selectedCountry !== "all") p.set("country", selectedCountry);
    if (selectedState && selectedState !== "all") p.set("state", selectedState);
    if (selectedCity && selectedCity !== "all") p.set("city", selectedCity);
    return p.toString();
  }, [bloodGroup, selectedCountry, selectedState, selectedCity]);

  const { data: donors = [], isLoading, refetch } = useQuery<Omit<User, "password">[]>({
    queryKey: ["/api/donors", params],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/donors?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: false,
  });

  useEffect(() => {
    if (nearbyAutoSearched) return;
    if (!currentUser) return;
    if (currentUser.country || currentUser.state || currentUser.city) {
      if ((currentUser as any).country) setSelectedCountry((currentUser as any).country);
      if (currentUser.state) setSelectedState(currentUser.state);
      if (currentUser.city) setSelectedCity(currentUser.city);
      setNearbyAutoSearched(true);
      setHasSearched(true);
      setTimeout(() => refetch(), 100);
    }
  }, [currentUser, nearbyAutoSearched]);

  const handleSearch = () => {
    setHasSearched(true);
    refetch();
  };

  const handleQuickBloodGroup = (bg: string) => {
    setBloodGroup(bg);
    setCompatibleMode(false);
    setHasSearched(true);
    setTimeout(() => refetch(), 0);
  };

  const handleCompatible = () => {
    if (!currentUser?.bloodGroup) return;
    setBloodGroup("all");
    setCompatibleMode(true);
    setHasSearched(true);
    setTimeout(() => refetch(), 0);
  };

  const clearFilters = () => {
    setBloodGroup("all");
    setSelectedCountry("all");
    setSelectedState("all");
    setSelectedCity("all");
    setCompatibleMode(false);
    setHasSearched(false);
  };

  const displayDonors = useMemo(() => {
    if (!hasSearched) return [];
    let list = [...donors];
    if (compatibleMode && currentUser?.bloodGroup) {
      const compat = COMPATIBLE[currentUser.bloodGroup] || [];
      list = list.filter(d => compat.includes(d.bloodGroup));
    }
    return list.sort((a, b) => {
      if (a.isAvailable && !b.isAvailable) return -1;
      if (!a.isAvailable && b.isAvailable) return 1;
      return (b.totalDonations || 0) - (a.totalDonations || 0);
    });
  }, [donors, hasSearched, compatibleMode, currentUser]);

  const availableCount = displayDonors.filter(d => d.isAvailable).length;

  const hasActiveFilters = bloodGroup !== "all" || selectedCountry !== "all" || selectedState !== "all" || selectedCity !== "all" || compatibleMode;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary via-red-700 to-red-900 text-white px-4 pt-10 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-white/20 blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-36 h-36 rounded-full bg-white/10 blur-2xl translate-y-1/2" />
        </div>
        <div className="max-w-md mx-auto relative">
          <button onClick={() => setLocation("/dashboard")} className="mb-4 flex items-center gap-1 text-red-100 text-sm">
            ← Dashboard
          </button>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-black">Find Donors</h1>
              <p className="text-red-200 text-xs">
                {nearbyAutoSearched && currentUser?.city
                  ? `Showing nearby donors in ${currentUser.city}`
                  : "Search compatible blood donors near you"}
              </p>
            </div>
            {nearbyAutoSearched && (
              <div className="flex items-center gap-1 bg-white/20 rounded-lg px-2 py-1 text-[10px] font-semibold">
                <MapPin className="w-3 h-3" /> Nearby
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="px-4 max-w-md mx-auto -mt-4 space-y-4">

        {/* Quick Blood Group Buttons */}
        <Card className="shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-semibold">Quick Search by Blood Group</span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {BLOOD_GROUPS.map(bg => (
                <button
                  key={bg}
                  data-testid={`button-quick-bg-${bg.replace("+", "pos").replace("-", "neg")}`}
                  onClick={() => handleQuickBloodGroup(bg)}
                  className={`py-2 px-1 rounded-xl border-2 font-black text-sm transition-all ${
                    bloodGroup === bg && !compatibleMode
                      ? "border-primary bg-primary text-white scale-105 shadow-md"
                      : `border ${BG_COLORS[bg]} hover:scale-105`
                  }`}
                >
                  {bg}
                </button>
              ))}
            </div>
            {currentUser?.bloodGroup && (
              <button
                onClick={handleCompatible}
                data-testid="button-compatible-search"
                className={`mt-3 w-full py-2.5 rounded-xl border-2 text-sm font-semibold transition-all ${
                  compatibleMode
                    ? "border-purple-600 bg-purple-600 text-white"
                    : "border-purple-200 text-purple-700 bg-purple-50 dark:border-purple-800 dark:text-purple-400 dark:bg-purple-900/20"
                }`}
              >
                ✦ Compatible with my blood group ({currentUser.bloodGroup})
              </button>
            )}
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="shadow-sm">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <Filter className="w-4 h-4 text-muted-foreground" />
                Search Filters
              </div>
              {hasActiveFilters && (
                <button onClick={clearFilters} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                  <X className="w-3 h-3" /> Clear all
                </button>
              )}
            </div>

            {/* Blood Group dropdown */}
            <div>
              <label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1">
                <Droplets className="w-3 h-3 text-primary" /> Blood Group
              </label>
              <Select
                value={bloodGroup}
                onValueChange={v => {
                  setBloodGroup(v);
                  setCompatibleMode(false);
                }}
              >
                <SelectTrigger data-testid="select-blood-group" className="h-9">
                  <SelectValue placeholder="Select Blood Group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Blood Groups</SelectItem>
                  {BLOOD_GROUPS.map(bg => (
                    <SelectItem key={bg} value={bg}>
                      <span className="font-bold">{bg}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Country */}
            <div>
              <label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <Globe className="w-3 h-3" /> Country
              </label>
              <Select
                value={selectedCountry}
                onValueChange={v => { setSelectedCountry(v); setSelectedState("all"); setSelectedCity("all"); }}
              >
                <SelectTrigger data-testid="select-country" className="h-9">
                  <SelectValue placeholder="Select Country" />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  <SelectItem value="all">All Countries</SelectItem>
                  {COUNTRIES.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* State */}
            <div>
              <label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <MapPin className="w-3 h-3" /> State / Region
              </label>
              <Select
                value={selectedState}
                onValueChange={v => { setSelectedState(v); setSelectedCity("all"); }}
              >
                <SelectTrigger data-testid="select-state" className="h-9">
                  <SelectValue placeholder="Select State" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All States</SelectItem>
                  {availableStates.map(s => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* City (shows only when state is selected) */}
            <div>
              <label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <ChevronDown className="w-3 h-3" /> District / City
              </label>
              <Select
                value={selectedCity}
                onValueChange={setSelectedCity}
                disabled={selectedState === "all" || availableCities.length === 0}
              >
                <SelectTrigger data-testid="select-city" className="h-9">
                  <SelectValue placeholder={selectedState === "all" ? "Select state first" : "Select City"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {availableCities.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleSearch}
              className="w-full h-10"
              disabled={isLoading}
              data-testid="button-search-donors"
            >
              <Search className="w-4 h-4 mr-2" />
              {isLoading ? "Searching..." : "Search Donors"}
            </Button>
          </CardContent>
        </Card>

        {/* Results count banner */}
        {hasSearched && !isLoading && (
          <div className={`flex items-center justify-between px-4 py-3 rounded-xl ${
            displayDonors.length > 0
              ? "bg-green-50 border border-green-200 dark:bg-green-900/20 dark:border-green-800"
              : "bg-muted border border-border"
          }`} data-testid="text-donors-found">
            <div className="flex items-center gap-2">
              <Users className={`w-4 h-4 ${displayDonors.length > 0 ? "text-green-600" : "text-muted-foreground"}`} />
              <span className={`text-sm font-bold ${displayDonors.length > 0 ? "text-green-700 dark:text-green-400" : "text-muted-foreground"}`}>
                {displayDonors.length} Donor{displayDonors.length !== 1 ? "s" : ""} Found
                {selectedCity !== "all" ? ` near ${selectedCity}` : selectedState !== "all" ? ` in ${selectedState}` : selectedCountry !== "all" ? ` in ${selectedCountry}` : " Near You"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {nearbyAutoSearched && selectedCity !== "all" && (
                <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded-full font-medium flex items-center gap-0.5">
                  <MapPin className="w-2.5 h-2.5" /> Nearby
                </span>
              )}
              {availableCount > 0 && (
                <span className="text-xs bg-green-600 text-white px-2 py-0.5 rounded-full font-medium">
                  {availableCount} Available
                </span>
              )}
            </div>
          </div>
        )}

        {/* Loading state */}
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <DonorSkeleton key={i} />)}
          </div>
        )}

        {/* Empty state */}
        {hasSearched && !isLoading && displayDonors.length === 0 && (
          <div className="text-center py-14">
            <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-muted-foreground opacity-50" />
            </div>
            <p className="font-bold text-base">No donors found</p>
            <p className="text-sm text-muted-foreground mt-1 mb-4">
              Try adjusting your blood group or location filters
            </p>
            <Button variant="outline" size="sm" onClick={clearFilters}>
              Clear Filters
            </Button>
          </div>
        )}

        {/* Initial state (before search) */}
        {!hasSearched && (
          <div className="text-center py-14">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Users className="w-10 h-10 text-primary opacity-60" />
            </div>
            <p className="font-semibold text-sm text-muted-foreground">
              Select a blood group or use filters<br />to find donors near you
            </p>
          </div>
        )}

        {/* Donor results */}
        {!isLoading && displayDonors.length > 0 && (
          <div className="space-y-3 pb-2">
            {displayDonors.map(donor => (
              <DonorCard
                key={donor.id}
                donor={donor}
                onViewProfile={() => setLocation(`/donor/${donor.id}`)}
                onContact={() => { window.location.href = `tel:${donor.phone}`; }}
                onDirectChat={() => setLocation(`/direct-chat/${donor.id}`)}
              />
            ))}
          </div>
        )}
      </div>

      <MobileNav />
    </div>
  );
}
