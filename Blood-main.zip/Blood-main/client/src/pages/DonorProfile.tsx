import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MobileNav } from "@/components/MobileNav";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { getStoredUser, isAdminLoggedIn } from "@/lib/auth";
import { isEligibleToDonate, daysUntilEligible, nextEligibleDate } from "@/lib/eligibility";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft, MapPin, Phone, MessageCircle, Star, CheckCircle,
  Heart, Award, Calendar, Droplets, Shield, Clock, Edit2, Save, X
} from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import type { User, Donation } from "@shared/schema";

export default function DonorProfile() {
  const [location, setLocation] = useLocation();
  const currentUser = getStoredUser();
  const isAdmin = isAdminLoggedIn();
  const { toast } = useToast();
  const [editingDate, setEditingDate] = useState(false);
  const [dateInput, setDateInput] = useState("");
  // Support both /donor/:id and /admin/donors/:id
  const donorId = location.split("/").pop();

  const { data: donor, isLoading: loadingDonor } = useQuery<Omit<User, "password">>({
    queryKey: ["/api/users", donorId],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/users/${donorId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
    enabled: !!donorId,
  });

  const { data: donations = [], isLoading: loadingDonations } = useQuery<Donation[]>({
    queryKey: ["/api/users", donorId, "donations"],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/users/${donorId}/donations`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!donorId,
  });

  const updateDonorMutation = useMutation({
    mutationFn: (data: Record<string, unknown>) =>
      apiRequest("PUT", `/api/admin/users/${donorId}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", donorId] });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setEditingDate(false);
      toast({ title: "Updated", description: "Last donation date saved." });
    },
    onError: () => toast({ title: "Error", description: "Failed to update.", variant: "destructive" }),
  });

  const isOwnProfile = currentUser?.id === donorId;
  const initials = donor?.fullName?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "??";
  const eligible = isEligibleToDonate(donor?.lastDonationDate);
  const daysLeft = daysUntilEligible(donor?.lastDonationDate);
  const eligibleOn = nextEligibleDate(donor?.lastDonationDate);

  const levelLabel = (pts: number) => {
    if (pts >= 2500) return { label: "Legend", color: "text-purple-600 bg-purple-100 dark:bg-purple-900/30" };
    if (pts >= 1000) return { label: "Gold", color: "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30" };
    if (pts >= 500) return { label: "Silver", color: "text-gray-500 bg-gray-100 dark:bg-gray-800" };
    return { label: "Bronze", color: "text-orange-600 bg-orange-100 dark:bg-orange-900/30" };
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-10 pb-16">
        <div className="max-w-md mx-auto">
          <button
            onClick={() => window.history.back()}
            className="mb-4 flex items-center gap-1 text-red-100 text-sm"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          {loadingDonor ? (
            <div className="space-y-3">
              <Skeleton className="h-16 w-16 rounded-full bg-white/20" />
              <Skeleton className="h-6 w-40 bg-white/20" />
              <Skeleton className="h-4 w-24 bg-white/20" />
            </div>
          ) : donor ? (
            <div className="flex items-center gap-4">
              <div className="relative">
                {donor.profileImage ? (
                  <img src={donor.profileImage} alt={donor.fullName} className="w-16 h-16 rounded-full object-cover border-2 border-white/40" />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-white font-bold text-xl">
                    {initials}
                  </div>
                )}
                <span className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-white ${donor.isAvailable ? "bg-green-400" : "bg-gray-400"}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-black" data-testid="text-donor-name">{donor.fullName}</h1>
                  {donor.isVerified && <Star className="w-4 h-4 text-yellow-300 fill-yellow-300" />}
                </div>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <BloodGroupBadge group={donor.bloodGroup} size="sm" />
                  {donor.isVerified && (
                    <span className="flex items-center gap-1 text-xs bg-white/20 px-2 py-0.5 rounded-full">
                      <CheckCircle className="w-3 h-3" /> Verified
                    </span>
                  )}
                  <span className={`text-xs px-2 py-0.5 rounded-full ${donor.isAvailable ? "bg-green-400/30" : "bg-white/10"}`}>
                    {donor.isAvailable ? "Available" : "Unavailable"}
                  </span>
                </div>
                {donor.city && (
                  <div className="flex items-center gap-1 mt-1 text-red-200 text-xs">
                    <MapPin className="w-3 h-3" />
                    {donor.city}{donor.state ? `, ${donor.state}` : ""}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <p className="text-white/80">Donor not found</p>
          )}
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-8 space-y-4">
        {/* Stats Row */}
        {!loadingDonor && donor && (
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Donations", value: donor.totalDonations || 0, icon: Droplets, color: "text-primary" },
              { label: "Points", value: donor.rewardPoints || 0, icon: Award, color: "text-yellow-600" },
              { label: "Level", value: levelLabel(donor.rewardPoints || 0).label, icon: Shield, color: "text-purple-600" },
            ].map(({ label, value, icon: Icon, color }) => (
              <Card key={label}>
                <CardContent className="p-3 text-center">
                  <Icon className={`w-5 h-5 mx-auto mb-1 ${color}`} />
                  <p className="font-black text-lg leading-none" data-testid={`stat-${label.toLowerCase()}`}>{value}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        {!isOwnProfile && !isAdmin && !loadingDonor && donor && (
          <div className="space-y-2">
            <div className="flex gap-2">
              {donor.phone && (
                <Button
                  className="flex-1"
                  onClick={() => { window.location.href = `tel:${donor.phone}`; }}
                  data-testid="button-call-donor"
                >
                  <Phone className="w-4 h-4 mr-1.5" /> Call
                </Button>
              )}
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setLocation(`/direct-chat/${donor.id}`)}
                data-testid="button-direct-chat-donor"
              >
                <MessageCircle className="w-4 h-4 mr-1.5" /> Chat
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setLocation(`/request-blood?donor=${donor.id}`)}
                data-testid="button-request-donor"
              >
                Request
              </Button>
            </div>
            {donor.phone && (
              <Button
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                onClick={() => {
                  const phone = donor.phone!.replace(/[^0-9]/g, "");
                  const text = encodeURIComponent(
                    `Hi ${donor.fullName}, I found your profile on LifeFlow blood donation app and would like to connect with you regarding blood donation.`
                  );
                  window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
                }}
                data-testid="button-whatsapp-donor"
              >
                <SiWhatsapp className="w-4 h-4 mr-2" /> Chat on WhatsApp
              </Button>
            )}
          </div>
        )}

        {/* About Card */}
        {!loadingDonor && donor && (
          <Card>
            <CardContent className="p-4 space-y-3">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <Heart className="w-4 h-4 text-primary" /> About
              </h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Blood Group</p>
                  <p className="font-medium">{donor.bloodGroup}</p>
                </div>
                {donor.city && (
                  <div>
                    <p className="text-xs text-muted-foreground">Location</p>
                    <p className="font-medium">{donor.city}{donor.state ? `, ${donor.state}` : ""}</p>
                  </div>
                )}
                <div>
                  <p className="text-xs text-muted-foreground">Donor Status</p>
                  <p className="font-medium">{donor.isDonor ? "Active Donor" : "Not a Donor"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Last Donation</p>
                  {isAdmin && editingDate ? (
                    <div className="flex items-center gap-1 mt-0.5">
                      <Input
                        type="date"
                        value={dateInput}
                        onChange={e => setDateInput(e.target.value)}
                        className="h-7 text-xs px-2 w-32"
                        data-testid="input-last-donation-date"
                      />
                      <button
                        onClick={() => updateDonorMutation.mutate({ lastDonationDate: dateInput || null })}
                        disabled={updateDonorMutation.isPending}
                        className="text-green-600 hover:text-green-700"
                        data-testid="button-save-donation-date"
                      >
                        <Save className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => setEditingDate(false)} className="text-muted-foreground hover:text-foreground">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1">
                      <p className="font-medium text-sm">
                        {donor.lastDonationDate
                          ? new Date(donor.lastDonationDate).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
                          : <span className="text-muted-foreground">Not recorded</span>
                        }
                      </p>
                      {isAdmin && (
                        <button
                          onClick={() => { setDateInput(donor.lastDonationDate || ""); setEditingDate(true); }}
                          className="text-muted-foreground hover:text-primary ml-1"
                          data-testid="button-edit-donation-date"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Eligibility Banner */}
              <div className={`mt-1 flex items-center gap-3 px-3 py-2.5 rounded-xl ${
                eligible
                  ? "bg-green-50 border border-green-200 dark:bg-green-900/20 dark:border-green-800"
                  : "bg-amber-50 border border-amber-200 dark:bg-amber-900/20 dark:border-amber-800"
              }`} data-testid="eligibility-banner">
                {eligible ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-green-700 dark:text-green-400">Eligible to Donate Again</p>
                      <p className="text-[10px] text-green-600/70 dark:text-green-500/70">
                        {donor.lastDonationDate ? "90+ days have passed since last donation" : "No previous donation recorded"}
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <Clock className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-amber-700 dark:text-amber-400">
                        Not Yet Eligible — {daysLeft} days remaining
                      </p>
                      <p className="text-[10px] text-amber-600/70 dark:text-amber-500/70">
                        Eligible to donate again on:{" "}
                        <span className="font-semibold">
                          {eligibleOn?.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}
                        </span>
                      </p>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Donation History */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold text-sm flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4 text-primary" />
              Donation History
              <span className="ml-auto text-xs text-muted-foreground font-normal">{donations.length} total</span>
            </h3>

            {loadingDonations ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : donations.length === 0 ? (
              <div className="text-center py-6">
                <Droplets className="w-8 h-8 mx-auto text-muted-foreground/30 mb-2" />
                <p className="text-xs text-muted-foreground">No donations recorded yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {donations.map((d) => (
                  <div key={d.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/40" data-testid={`donation-item-${d.id}`}>
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Droplets className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{d.hospital}</p>
                      <p className="text-xs text-muted-foreground">{d.donationDate} · {d.units} unit{d.units > 1 ? "s" : ""}</p>
                    </div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${d.status === "completed" ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300" : "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300"}`}>
                      {d.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {!isAdmin && <MobileNav />}
    </div>
  );
}
