import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { MobileNav } from "@/components/MobileNav";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getStoredUser, urgencyColor, timeSince } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import {
  Droplets, Heart, Users, Award, Bell, ArrowRight, PlusCircle, Search,
  ChevronRight, Flame, Calendar, MessageCircle, Shield, Hospital,
  MapPin, Clock, CheckCircle2, Phone, EyeOff, User, Siren, PhoneCall,
} from "lucide-react";
import type { BloodRequest, BloodCamp, Notification, User as UserType } from "@shared/schema";

const COMPATIBLE_GROUPS: Record<string, string[]> = {
  "O-": ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"],
  "O+": ["O+", "A+", "B+", "AB+"],
  "A-": ["A-", "A+", "AB-", "AB+"],
  "A+": ["A+", "AB+"],
  "B-": ["B-", "B+", "AB-", "AB+"],
  "B+": ["B+", "AB+"],
  "AB-": ["AB-", "AB+"],
  "AB+": ["AB+"],
};

function getSkippedRequests(): Set<string> {
  try {
    const stored = localStorage.getItem("skipped_requests");
    return stored ? new Set(JSON.parse(stored)) : new Set();
  } catch { return new Set(); }
}

function skipRequest(id: string) {
  const set = getSkippedRequests();
  set.add(id);
  localStorage.setItem("skipped_requests", JSON.stringify([...set]));
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const storedUser = getStoredUser();
  const { data: freshUser } = useQuery<Omit<UserType, "password">>({ queryKey: ["/api/auth/me"] });
  const user = freshUser || storedUser;
  const [skipped, setSkipped] = useState<Set<string>>(getSkippedRequests);

  const { data: myRequests = [] } = useQuery<BloodRequest[]>({ queryKey: ["/api/requests"] });
  const { data: openRequests = [] } = useQuery<BloodRequest[]>({ queryKey: ["/api/requests/open"] });
  const { data: camps = [] } = useQuery<BloodCamp[]>({ queryKey: ["/api/camps"] });
  const { data: notifications = [] } = useQuery<Notification[]>({ queryKey: ["/api/notifications"] });
  const { data: featuredDonors = [], isLoading: loadingDonors } = useQuery<Omit<UserType, "password">[]>({
    queryKey: ["/api/public/donors/featured"],
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const pendingRequests = myRequests.filter(r => r.status === "pending").length;
  const upcomingCamps = camps.slice(0, 3);

  const userBloodGroup = user?.bloodGroup || "";
  const compatibleGroups = COMPATIBLE_GROUPS[userBloodGroup] || [];
  const incomingRequests = openRequests
    .filter(r => !skipped.has(r.id) && compatibleGroups.includes(r.bloodGroup))
    .sort((a, b) => {
      const order = { emergency: 0, urgent: 1, normal: 2 };
      return (order[a.urgency as keyof typeof order] ?? 2) - (order[b.urgency as keyof typeof order] ?? 2);
    })
    .slice(0, 3);

  const acceptMutation = useMutation({
    mutationFn: async (requestId: string) => {
      const res = await apiRequest("PATCH", `/api/requests/${requestId}`, {
        status: "accepted",
        donorId: user?.id,
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to accept");
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/open"] });
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "Request accepted!", description: "Opening chat with the requester." });
      setLocation(`/chat/${data.id}`);
    },
    onError: (e: any) => toast({ title: "Could not accept", description: e.message, variant: "destructive" }),
  });

  const handleSkip = (id: string) => {
    skipRequest(id);
    setSkipped(getSkippedRequests());
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary via-red-700 to-red-800 text-white px-4 pt-10 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -top-4 -right-4 w-32 h-32 rounded-full bg-white/30 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full bg-white/20 blur-2xl" />
        </div>
        <div className="relative max-w-md mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Droplets className="w-5 h-5" />
              <span className="font-bold text-sm">LifeFlow</span>
            </div>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <button onClick={() => setLocation("/notifications")} className="relative" data-testid="button-notifications">
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-400 text-yellow-900 text-[9px] font-bold rounded-full flex items-center justify-center">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => setLocation("/profile")} className="relative flex-shrink-0" data-testid="button-avatar">
                {user?.profileImage ? (
                  <img src={user.profileImage} alt="Profile" className="w-12 h-12 rounded-full object-cover border-2 border-white/40" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-white/20 border-2 border-white/40 flex items-center justify-center text-white font-black text-lg">
                    {user?.fullName?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?"}
                  </div>
                )}
              </button>
              <div>
                <p className="text-red-200 text-xs">Welcome back,</p>
                <h2 className="text-xl font-black mt-0.5" data-testid="text-user-name">
                  {user?.fullName?.split(" ")[0] || "Donor"}
                </h2>
                <p className="text-red-200 text-xs mt-0.5">{user?.city || "Set your location"}</p>
              </div>
            </div>
            <div className="text-right">
              <BloodGroupBadge group={user?.bloodGroup || "O+"} size="lg" className="shadow-lg" />
              <p className="text-red-200 text-xs mt-1">{user?.isAvailable ? "Available" : "Unavailable"}</p>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-2 mt-5">
            {[
              { icon: Heart, label: "Donations", value: user?.totalDonations || 0, color: "text-red-100" },
              { icon: Award, label: "Points", value: user?.rewardPoints || 0, color: "text-yellow-200" },
              { icon: Users, label: "Requests", value: myRequests.length, color: "text-blue-200" },
            ].map(({ icon: Icon, label, value, color }) => (
              <div key={label} className="bg-white/10 backdrop-blur rounded-xl p-2.5 text-center">
                <Icon className={`w-4 h-4 mx-auto mb-1 ${color}`} />
                <p className="text-white font-black text-sm" data-testid={`stat-${label.toLowerCase()}`}>{value}</p>
                <p className="text-red-200 text-[10px]">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto space-y-5">
        {/* Quick Actions */}
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: Search, label: "Find Donors", sub: "Search by blood group", href: "/find-donors", color: "from-blue-500 to-blue-700" },
              { icon: PlusCircle, label: "Request Blood", sub: "Create urgent request", href: "/request-blood", color: "from-primary to-red-700" },
              { icon: Heart, label: "My Donations", sub: "View history", href: "/donations", color: "from-pink-500 to-rose-600" },
              { icon: Calendar, label: "Blood Camps", sub: "Upcoming events", href: "/camps", color: "from-green-500 to-green-700" },
            ].map(({ icon: Icon, label, sub, href, color }) => (
              <button
                key={href}
                onClick={() => setLocation(href)}
                data-testid={`action-${label.toLowerCase().replace(/\s/g, "-")}`}
                className={`bg-gradient-to-br ${color} text-white rounded-xl p-4 text-left hover-elevate`}
              >
                <Icon className="w-6 h-6 mb-2 opacity-90" />
                <p className="font-semibold text-sm leading-tight">{label}</p>
                <p className="text-white/70 text-xs mt-0.5">{sub}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Emergency Blood Alert Button */}
        <button
          onClick={() => setLocation("/emergency-alert")}
          data-testid="button-emergency-alert"
          className="w-full bg-gradient-to-r from-red-600 via-red-700 to-red-800 text-white rounded-xl p-4 flex items-center gap-3 hover-elevate shadow-lg shadow-red-500/20"
        >
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center flex-shrink-0">
            <Siren className="w-5 h-5 animate-pulse" />
          </div>
          <div className="flex-1 text-left">
            <p className="font-bold text-sm">Emergency Blood Alert</p>
            <p className="text-red-200 text-xs mt-0.5">Instantly notify 50 nearby matching donors</p>
          </div>
          <div className="flex items-center gap-1 bg-white/20 rounded-lg px-2.5 py-1.5 text-[10px] font-bold tracking-wide">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-white animate-ping mr-0.5" />
            EMERGENCY
          </div>
        </button>

        {/* My Pending Requests Alert */}
        {pendingRequests > 0 && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Flame className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm">You have {pendingRequests} pending request{pendingRequests > 1 ? "s" : ""}</p>
                  <p className="text-xs text-muted-foreground">Track your blood requests status</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => setLocation("/my-requests")} data-testid="button-view-requests">
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Incoming Requests for this Donor */}
        {incomingRequests.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold">Incoming Blood Requests</h3>
                <span className="bg-primary text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                  {incomingRequests.length}
                </span>
              </div>
              <button onClick={() => setLocation("/open-requests")} className="text-xs text-primary font-medium flex items-center gap-0.5">
                View all <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="space-y-3">
              {incomingRequests.map(req => {
                const isEmergency = req.urgency === "emergency";
                const isUrgent = req.urgency === "urgent";
                const r = req as any;
                return (
                  <Card
                    key={req.id}
                    data-testid={`incoming-request-card-${req.id}`}
                    className={`overflow-hidden ${isEmergency ? "border-red-300 dark:border-red-700" : isUrgent ? "border-orange-200 dark:border-orange-800" : ""}`}
                  >
                    {isEmergency && (
                      <div className="bg-red-600 text-white px-3 py-1 text-[10px] font-bold flex items-center gap-1">
                        <Flame className="w-2.5 h-2.5 animate-pulse" /> EMERGENCY
                      </div>
                    )}
                    {isUrgent && !isEmergency && (
                      <div className="bg-orange-500 text-white px-3 py-1 text-[10px] font-bold">URGENT</div>
                    )}
                    <CardContent className="p-3">
                      <div className="flex items-start gap-2 mb-2">
                        <BloodGroupBadge group={req.bloodGroup} size="sm" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{req.patientName}</p>
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground mt-0.5">
                            <Hospital className="w-2.5 h-2.5" />
                            <span className="truncate">{req.hospital}</span>
                          </div>
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            <MapPin className="w-2.5 h-2.5" />
                            <span className="truncate">{req.city}{req.state ? `, ${req.state}` : ""}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-2">
                        <Clock className="w-2.5 h-2.5" />
                        <span>{req.unitsNeeded} unit{req.unitsNeeded > 1 ? "s" : ""} · {timeSince(req.createdAt!)}</span>
                        {r.contactName && (
                          <>
                            <User className="w-2.5 h-2.5 ml-1" />
                            <span>{r.contactName}</span>
                          </>
                        )}
                      </div>

                      {/* Contact */}
                      <a
                        href={`tel:${req.contactPhone}`}
                        className="flex items-center gap-1.5 text-[10px] text-primary font-medium mb-3"
                        data-testid={`link-contact-incoming-${req.id}`}
                      >
                        <Phone className="w-2.5 h-2.5" /> {req.contactPhone}
                      </a>

                      {/* Action Buttons */}
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 h-8 text-xs"
                          onClick={() => acceptMutation.mutate(req.id)}
                          disabled={acceptMutation.isPending}
                          data-testid={`button-accept-incoming-${req.id}`}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Accept
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 px-3 text-xs text-muted-foreground"
                          onClick={() => setLocation(`/chat/${req.id}`)}
                          data-testid={`button-contact-incoming-${req.id}`}
                        >
                          <MessageCircle className="w-3.5 h-3.5 mr-1" /> Contact
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 px-2.5 text-xs text-muted-foreground"
                          onClick={() => handleSkip(req.id)}
                          data-testid={`button-skip-incoming-${req.id}`}
                          title="Not available for this request"
                        >
                          <EyeOff className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Recent Notifications */}
        {notifications.slice(0, 2).length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">Recent Alerts</h3>
              <button onClick={() => setLocation("/notifications")} className="text-xs text-primary font-medium flex items-center gap-0.5">
                View all <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="space-y-2">
              {notifications.slice(0, 2).map(n => (
                <Card key={n.id} className={n.isRead ? "opacity-70" : ""} data-testid={`notification-${n.id}`}>
                  <CardContent className="p-3">
                    <div className="flex items-start gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Bell className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium leading-tight">{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                      </div>
                      {!n.isRead && <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1" />}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Upcoming Camps */}
        {upcomingCamps.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">Upcoming Blood Camps</h3>
              <button onClick={() => setLocation("/camps")} className="text-xs text-primary font-medium flex items-center gap-0.5">
                View all <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="space-y-2">
              {upcomingCamps.map(camp => (
                <Card key={camp.id} className="hover-elevate" data-testid={`camp-${camp.id}`}>
                  <CardContent className="p-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center flex-shrink-0">
                        <Calendar className="w-5 h-5 text-green-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{camp.title}</p>
                        <p className="text-xs text-muted-foreground">{camp.venue}, {camp.city}</p>
                        <p className="text-xs text-primary mt-0.5">{camp.startDate}</p>
                      </div>
                      <Badge variant="secondary" className="text-xs flex-shrink-0">{camp.registeredCount}/{camp.maxParticipants}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* ===== Available Blood Donors ===== */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
                <Heart className="w-3.5 h-3.5 text-white" />
              </div>
              <h3 className="text-sm font-semibold">Available Blood Donors</h3>
            </div>
            <button
              onClick={() => setLocation("/find-donors")}
              className="text-xs text-primary font-medium flex items-center gap-0.5"
              data-testid="link-view-all-donors"
            >
              View All <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {loadingDonors && (
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map(i => (
                <Card key={i}><CardContent className="p-3"><Skeleton className="h-28 w-full rounded-lg" /></CardContent></Card>
              ))}
            </div>
          )}

          {!loadingDonors && featuredDonors.length === 0 && (
            <Card>
              <CardContent className="p-6 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-40" />
                <p className="text-sm text-muted-foreground">No donors available right now</p>
                <p className="text-xs text-muted-foreground mt-1">Check back later or register as a donor</p>
              </CardContent>
            </Card>
          )}

          {!loadingDonors && featuredDonors.length > 0 && (
            <>
              <div className="grid grid-cols-2 gap-3">
                {featuredDonors.slice(0, 12).map(donor => {
                  const initials = donor.fullName.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2);
                  const waMsg = encodeURIComponent(`Hi ${donor.fullName}, I need blood of group ${donor.bloodGroup}. Can you help?`);
                  const waUrl = donor.phone ? `https://wa.me/${donor.phone.replace(/\D/g, "")}?text=${waMsg}` : "#";
                  const callUrl = donor.phone ? `tel:${donor.phone}` : "#";
                  return (
                    <Card
                      key={donor.id}
                      className="overflow-hidden border border-border hover:border-primary/30 transition-colors"
                      data-testid={`donor-card-${donor.id}`}
                    >
                      <CardContent className="p-3">
                        {/* Photo */}
                        <div className="flex flex-col items-center gap-2 mb-2">
                          <div className="relative">
                            {donor.profilePhoto ? (
                              <img
                                src={donor.profilePhoto}
                                alt={donor.fullName}
                                className="w-14 h-14 rounded-full object-cover border-2 border-primary/30"
                              />
                            ) : (
                              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center text-primary font-bold text-lg border-2 border-primary/20">
                                {initials}
                              </div>
                            )}
                            {/* Available dot */}
                            <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-background" />
                          </div>

                          {/* Blood group badge */}
                          <span className="px-2 py-0.5 rounded-full text-[11px] font-black bg-primary text-white">
                            {donor.bloodGroup}
                          </span>
                        </div>

                        {/* Name */}
                        <p className="text-xs font-semibold text-center leading-tight line-clamp-1 mb-1">
                          {donor.fullName}
                        </p>

                        {/* City */}
                        {donor.city && (
                          <div className="flex items-center justify-center gap-1 mb-2">
                            <MapPin className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                            <p className="text-[11px] text-muted-foreground truncate">{donor.city}</p>
                          </div>
                        )}

                        {/* Buttons */}
                        <div className="flex gap-1.5">
                          <a
                            href={callUrl}
                            className="flex-1 flex items-center justify-center gap-1 h-7 rounded-md bg-primary/10 text-primary text-[11px] font-semibold hover:bg-primary/20 transition-colors"
                            data-testid={`button-call-donor-${donor.id}`}
                          >
                            <PhoneCall className="w-3 h-3" /> Call
                          </a>
                          <a
                            href={waUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-1 h-7 rounded-md bg-green-500/10 text-green-600 text-[11px] font-semibold hover:bg-green-500/20 transition-colors"
                            data-testid={`button-whatsapp-donor-${donor.id}`}
                          >
                            <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                            </svg>
                            WhatsApp
                          </a>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* View All Donors button */}
              <Button
                variant="outline"
                className="w-full mt-3 border-primary/30 text-primary hover:bg-primary/5"
                onClick={() => setLocation("/find-donors")}
                data-testid="button-view-all-donors"
              >
                <Users className="w-4 h-4 mr-2" />
                View All Donors
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </>
          )}
        </div>

        {/* AI Donor Match Teaser */}
        <Card className="bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500 flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">AI Smart Matching</p>
                <p className="text-xs text-muted-foreground">Find best donors based on proximity and history</p>
              </div>
              <Button size="sm" variant="outline" onClick={() => setLocation("/find-donors")} data-testid="button-ai-match">
                Try <ChevronRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      <MobileNav />
    </div>
  );
}
