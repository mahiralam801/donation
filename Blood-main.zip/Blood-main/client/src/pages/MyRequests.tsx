import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MobileNav } from "@/components/MobileNav";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { statusColor, statusLabel, urgencyColor, timeSince } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Droplets, Hospital, MapPin, Clock, MessageCircle, X, Plus, Calendar, User, FileText, Shield } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import type { BloodRequest } from "@shared/schema";

function shareOnWhatsApp(req: BloodRequest) {
  const today = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  const r = req as any;
  const location = [req.city, r.district, req.state].filter(Boolean).join(", ");
  const message = [
    "🚨 *Urgent Blood Needed*",
    "",
    `Blood Group: *${req.bloodGroup}*`,
    `Hospital: ${req.hospital}`,
    `Location: ${location}`,
    `Date: ${today}`,
    `Units: ${req.unitsNeeded}`,
    req.urgency === "emergency" ? "\n⚠️ *This is a CRITICAL EMERGENCY*" : "",
    r.notes ? `\nNote: ${r.notes}` : "",
    "",
    "If you can donate please contact:",
    `Phone: *${req.contactPhone}*`,
  ].filter(l => l !== null).join("\n");
  window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, "_blank");
}

export default function MyRequests() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: requests = [], isLoading } = useQuery<BloodRequest[]>({
    queryKey: ["/api/requests"],
  });

  const cancelMutation = useMutation({
    mutationFn: async ({ id }: { id: string }) => {
      const res = await apiRequest("PATCH", `/api/requests/${id}`, { status: "cancelled" });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "Request cancelled" });
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const grouped = {
    pending: requests.filter(r => r.status === "pending"),
    active: requests.filter(r => ["accepted", "approved", "donor_found"].includes(r.status || "")),
    closed: requests.filter(r => ["fulfilled", "rejected", "cancelled"].includes(r.status || "")),
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-10 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-red-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Droplets className="w-5 h-5" />
                <h1 className="text-xl font-black">My Requests</h1>
              </div>
              <p className="text-red-200 text-xs">{requests.length} total request{requests.length !== 1 ? "s" : ""}</p>
            </div>
            <Button size="sm" variant="outline" className="bg-white/10 border-white/30 text-white" onClick={() => setLocation("/request-blood")} data-testid="button-new-request">
              <Plus className="w-4 h-4 mr-1" /> New
            </Button>
          </div>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto space-y-5">
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Card key={i}><CardContent className="p-4"><Skeleton className="h-24 w-full" /></CardContent></Card>)}
          </div>
        )}

        {!isLoading && requests.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
              <Droplets className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">No blood requests yet</p>
            <p className="text-xs text-muted-foreground mt-1 mb-4">Create your first blood request</p>
            <Button onClick={() => setLocation("/request-blood")} data-testid="button-create-first-request">
              Create Request
            </Button>
          </div>
        )}

        {grouped.pending.length > 0 && (
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Pending ({grouped.pending.length})</h3>
            <div className="space-y-3">
              {grouped.pending.map(req => <RequestCard key={req.id} request={req} onCancel={() => cancelMutation.mutate({ id: req.id })} onMessage={() => setLocation(`/chat/${req.id}`)} onShare={() => shareOnWhatsApp(req)} />)}
            </div>
          </section>
        )}

        {grouped.active.length > 0 && (
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Active ({grouped.active.length})</h3>
            <div className="space-y-3">
              {grouped.active.map(req => <RequestCard key={req.id} request={req} onMessage={() => setLocation(`/chat/${req.id}`)} onShare={() => shareOnWhatsApp(req)} />)}
            </div>
          </section>
        )}

        {grouped.closed.length > 0 && (
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Closed ({grouped.closed.length})</h3>
            <div className="space-y-3">
              {grouped.closed.map(req => <RequestCard key={req.id} request={req} onShare={() => shareOnWhatsApp(req)} />)}
            </div>
          </section>
        )}
      </div>
      <MobileNav />
    </div>
  );
}

function RequestCard({ request, onCancel, onMessage, onShare }: {
  request: BloodRequest;
  onCancel?: () => void;
  onMessage?: () => void;
  onShare?: () => void;
}) {
  const req = request as any;
  const isDonorFound = ["approved", "donor_found", "accepted"].includes(request.status || "");
  return (
    <Card data-testid={`request-card-${request.id}`} className={isDonorFound ? "border-blue-200 dark:border-blue-800" : ""}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm truncate">{request.patientName}</p>
            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
              <p className="text-xs text-muted-foreground">{timeSince(request.createdAt!)}</p>
              {req.requestType === "user_to_admin" && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 flex items-center gap-0.5">
                  <Shield className="w-2.5 h-2.5" /> Admin
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <BloodGroupBadge group={request.bloodGroup} size="sm" />
            <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${urgencyColor(request.urgency || "normal")}`}>
              {(request.urgency || "normal").charAt(0).toUpperCase() + (request.urgency || "normal").slice(1)}
            </span>
          </div>
        </div>

        <div className="space-y-1 mb-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Hospital className="w-3 h-3" />
            <span className="truncate">{request.hospital}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span>
              {request.city}
              {req.district ? `, ${req.district}` : ""}
              {request.state ? `, ${request.state}` : ""}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{request.unitsNeeded} unit{request.unitsNeeded > 1 ? "s" : ""} needed</span>
          </div>
          {req.requiredByDate && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Calendar className="w-3 h-3 text-orange-500" />
              <span>Required: {new Date(req.requiredByDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
            </div>
          )}
          {req.contactName && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <User className="w-3 h-3" />
              <span>Contact: {req.contactName}</span>
            </div>
          )}
          {req.requisitionForm && (
            <div className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400">
              <FileText className="w-3 h-3" />
              <span>Requisition form attached ({req.requisitionFormType})</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between">
          <span className={`text-xs px-2 py-1 rounded-md font-medium ${statusColor(request.status || "pending")}`} data-testid={`status-${request.id}`}>
            {statusLabel(request.status || "pending")}
          </span>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="ghost"
              className="px-2 text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-900/20"
              onClick={onShare}
              data-testid={`button-whatsapp-${request.id}`}
              title="Share on WhatsApp"
            >
              <SiWhatsapp className="w-3.5 h-3.5" />
            </Button>
            {onMessage && (
              <Button size="sm" variant="outline" onClick={onMessage} data-testid={`button-chat-${request.id}`}>
                <MessageCircle className="w-3.5 h-3.5 mr-1" /> Chat
              </Button>
            )}
            {onCancel && (
              <Button size="sm" variant="outline" onClick={onCancel} className="text-red-600 border-red-200" data-testid={`button-cancel-${request.id}`}>
                <X className="w-3.5 h-3.5 mr-1" /> Cancel
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
