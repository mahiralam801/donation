import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MobileNav } from "@/components/MobileNav";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { BLOOD_GROUPS, getStoredUser } from "@/lib/auth";
import {
  ArrowLeft, Droplets, AlertTriangle, CheckCircle, Flame,
  Upload, FileText, ImageIcon, X, Calendar,
  Phone, User, Building2, MapPin
} from "lucide-react";

const INDIA_STATES = [
  "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana",
  "Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur",
  "Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana",
  "Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Delhi","Jammu & Kashmir","Ladakh",
  "Puducherry","Chandigarh","Andaman & Nicobar Islands","Lakshadweep","Dadra & Nagar Haveli",
];

export default function RequestBlood() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const user = getStoredUser();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; type: string; data: string } | null>(null);
  const [uploadingFile, setUploadingFile] = useState(false);

  const [form, setForm] = useState({
    patientName: "",
    bloodGroup: user?.bloodGroup || "",
    unitsNeeded: "1",
    hospital: "",
    state: user?.state || "",
    district: "",
    city: user?.city || "",
    contactName: user?.fullName || "",
    contactPhone: user?.phone || "",
    urgency: "normal" as "normal" | "urgent" | "emergency",
    requiredByDate: "",
    notes: "",
  });

  const update = (k: string, v: string) => setForm(prev => ({ ...prev, [k]: v }));

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      toast({ title: "File too large", description: "Maximum file size is 5MB", variant: "destructive" });
      return;
    }
    const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "application/pdf"];
    if (!allowedTypes.includes(file.type)) {
      toast({ title: "Invalid file type", description: "Only JPG, PNG, and PDF files are allowed", variant: "destructive" });
      return;
    }
    setUploadingFile(true);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const data = ev.target?.result as string;
      const fileType = file.type === "application/pdf" ? "pdf" : "image";
      setUploadedFile({ name: file.name, type: fileType, data });
      setUploadingFile(false);
    };
    reader.onerror = () => {
      toast({ title: "Failed to read file", variant: "destructive" });
      setUploadingFile(false);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.patientName || !form.bloodGroup || !form.hospital || !form.city || !form.contactPhone) {
      return toast({ title: "Please fill all required fields", variant: "destructive" });
    }
    if (!form.contactName) {
      return toast({ title: "Contact person name is required", variant: "destructive" });
    }
    setLoading(true);
    try {
      await apiRequest("POST", "/api/requests", {
        patientName: form.patientName,
        bloodGroup: form.bloodGroup,
        unitsNeeded: parseInt(form.unitsNeeded),
        hospital: form.hospital,
        state: form.state,
        district: form.district,
        city: form.city,
        contactName: form.contactName,
        contactPhone: form.contactPhone,
        urgency: form.urgency,
        requestType: "user_to_donor",
        requiredByDate: form.requiredByDate || undefined,
        notes: form.notes || undefined,
        requisitionForm: uploadedFile?.data || undefined,
        requisitionFormType: uploadedFile?.type || undefined,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/requests/open"] });
      setSubmitted(true);
    } catch (err: any) {
      toast({ title: err.message?.replace(/^\d+: /, "") || "Submission failed", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const urgencyConfig = {
    normal: {
      color: "bg-secondary text-secondary-foreground border-secondary",
      activeColor: "bg-secondary text-secondary-foreground border-2 border-gray-400 ring-2 ring-gray-200",
      icon: null,
      label: "Normal",
      desc: "Standard request",
    },
    urgent: {
      color: "border-border bg-background",
      activeColor: "bg-orange-50 text-orange-700 border-2 border-orange-400 dark:bg-orange-900/20 dark:text-orange-300 ring-2 ring-orange-100",
      icon: AlertTriangle,
      label: "Urgent",
      desc: "Within 24 hours",
    },
    emergency: {
      color: "border-border bg-background",
      activeColor: "bg-red-50 text-red-700 border-2 border-red-400 dark:bg-red-900/20 dark:text-red-300 ring-2 ring-red-100",
      icon: Flame,
      label: "Emergency",
      desc: "Immediately",
    },
  };

  const resetForm = () => {
    setSubmitted(false);
    setUploadedFile(null);
    setForm({
      patientName: "",
      bloodGroup: user?.bloodGroup || "",
      unitsNeeded: "1",
      hospital: "",
      state: user?.state || "",
      district: "",
      city: user?.city || "",
      contactName: user?.fullName || "",
      contactPhone: user?.phone || "",
      urgency: "normal",
      requiredByDate: "",
      notes: "",
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 pb-20">
        <div className="text-center max-w-sm">
          <div className="w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-xl font-black mb-2">Request Submitted!</h2>
          <p className="text-muted-foreground text-sm mb-1">Your blood request has been posted.</p>
          <p className="text-muted-foreground text-xs mb-6">
            Nearby compatible donors have been notified. You will receive a response soon.
          </p>
          <div className="space-y-2">
            <Button onClick={() => setLocation("/my-requests")} className="w-full" data-testid="button-view-my-requests">
              View My Requests
            </Button>
            <Button variant="outline" onClick={resetForm} className="w-full" data-testid="button-new-request">
              New Request
            </Button>
          </div>
        </div>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-10 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-red-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center gap-2 mb-1">
            <Droplets className="w-5 h-5" />
            <h1 className="text-xl font-black">Request Blood</h1>
          </div>
          <p className="text-red-200 text-xs">Fill in all the details to send an urgent blood request</p>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto">
        <form onSubmit={handleSubmit} className="space-y-4">

          {/* Emergency Level */}
          <Card>
            <CardContent className="p-4">
              <Label className="text-sm font-semibold mb-3 block flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-orange-500" /> Emergency Level *
              </Label>
              <div className="grid grid-cols-3 gap-2">
                {(["normal", "urgent", "emergency"] as const).map(u => {
                  const conf = urgencyConfig[u];
                  const Icon = conf.icon;
                  const isActive = form.urgency === u;
                  return (
                    <button
                      key={u}
                      type="button"
                      onClick={() => update("urgency", u)}
                      data-testid={`urgency-${u}`}
                      className={`py-2.5 px-2 rounded-lg border text-xs font-medium transition-all flex flex-col items-center gap-1 ${isActive ? conf.activeColor : "border-border bg-background hover:bg-muted/30"}`}
                    >
                      {Icon && <Icon className="w-4 h-4" />}
                      <span className="font-semibold">{conf.label}</span>
                      <span className="text-[10px] opacity-70">{conf.desc}</span>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Patient Information */}
          <Card>
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-base flex items-center gap-2">
                <User className="w-4 h-4 text-primary" /> Patient Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pb-4">
              <div>
                <Label>Patient Name *</Label>
                <Input
                  value={form.patientName}
                  onChange={e => update("patientName", e.target.value)}
                  placeholder="Full name of patient"
                  className="mt-1"
                  data-testid="input-patient-name"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Blood Group *</Label>
                  <Select value={form.bloodGroup} onValueChange={v => update("bloodGroup", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-request-blood-group">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {BLOOD_GROUPS.map(bg => <SelectItem key={bg} value={bg}>{bg}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Units Required *</Label>
                  <Select value={form.unitsNeeded} onValueChange={v => update("unitsNeeded", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-units">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1,2,3,4,5,6,7,8,9,10].map(n => <SelectItem key={n} value={String(n)}>{n} unit{n > 1 ? "s" : ""}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-muted-foreground" /> Required By Date
                </Label>
                <Input
                  type="date"
                  value={form.requiredByDate}
                  onChange={e => update("requiredByDate", e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="mt-1"
                  data-testid="input-required-by"
                />
              </div>
            </CardContent>
          </Card>

          {/* Hospital & Location */}
          <Card>
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="w-4 h-4 text-primary" /> Hospital & Location
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pb-4">
              <div>
                <Label>Hospital Name *</Label>
                <Input
                  value={form.hospital}
                  onChange={e => update("hospital", e.target.value)}
                  placeholder="Name of the hospital"
                  className="mt-1"
                  data-testid="input-hospital"
                />
              </div>
              <div>
                <Label>State</Label>
                <Select value={form.state} onValueChange={v => update("state", v)}>
                  <SelectTrigger className="mt-1" data-testid="select-req-state">
                    <SelectValue placeholder="Select state" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDIA_STATES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>District</Label>
                  <Input
                    value={form.district}
                    onChange={e => update("district", e.target.value)}
                    placeholder="District"
                    className="mt-1"
                    data-testid="input-district"
                  />
                </div>
                <div>
                  <Label>Block / City *</Label>
                  <Input
                    value={form.city}
                    onChange={e => update("city", e.target.value)}
                    placeholder="City or block"
                    className="mt-1"
                    data-testid="input-req-city"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-base flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary" /> Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pb-4">
              <div>
                <Label>Contact Person Name *</Label>
                <Input
                  value={form.contactName}
                  onChange={e => update("contactName", e.target.value)}
                  placeholder="Name of person to contact"
                  className="mt-1"
                  data-testid="input-contact-name"
                />
              </div>
              <div>
                <Label>Phone Number *</Label>
                <Input
                  value={form.contactPhone}
                  onChange={e => update("contactPhone", e.target.value)}
                  placeholder="+91 XXXXX XXXXX"
                  type="tel"
                  className="mt-1"
                  data-testid="input-contact-phone"
                />
              </div>
              <div>
                <Label>Message / Additional Details</Label>
                <Textarea
                  value={form.notes}
                  onChange={e => update("notes", e.target.value)}
                  placeholder="Blood type compatibility notes, special requirements, patient condition..."
                  className="mt-1 resize-none"
                  rows={3}
                  data-testid="textarea-notes"
                />
              </div>
            </CardContent>
          </Card>

          {/* Requisition Form Upload */}
          <Card>
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-base flex items-center gap-2">
                <Upload className="w-4 h-4 text-primary" /> Upload Requisition Form
                <span className="text-xs font-normal text-muted-foreground">(Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pb-4">
              {!uploadedFile ? (
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/jpg,application/pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                    data-testid="input-requisition-file"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingFile}
                    data-testid="button-upload-requisition"
                    className="w-full border-2 border-dashed border-border rounded-lg p-6 text-center hover:bg-muted/30 transition-colors"
                  >
                    {uploadingFile ? (
                      <p className="text-sm text-muted-foreground">Reading file...</p>
                    ) : (
                      <>
                        <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm font-medium">Upload Hospital Requisition Form</p>
                        <p className="text-xs text-muted-foreground mt-1">JPG, PNG, or PDF · Max 5MB</p>
                        <div className="flex items-center justify-center gap-3 mt-3">
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <ImageIcon className="w-3.5 h-3.5" /> Image
                          </span>
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <FileText className="w-3.5 h-3.5" /> PDF
                          </span>
                        </div>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                  {uploadedFile.type === "pdf" ? (
                    <FileText className="w-8 h-8 text-red-600 flex-shrink-0" />
                  ) : (
                    <ImageIcon className="w-8 h-8 text-blue-600 flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" data-testid="text-uploaded-filename">{uploadedFile.name}</p>
                    <p className="text-xs text-green-600 dark:text-green-400">
                      <CheckCircle className="w-3 h-3 inline mr-1" />
                      {uploadedFile.type === "pdf" ? "PDF document ready" : "Image ready"}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setUploadedFile(null)}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    data-testid="button-remove-file"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </CardContent>
          </Card>

          {form.urgency === "emergency" && (
            <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
              <Flame className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-red-700 dark:text-red-300">
                <strong>Emergency Alert:</strong> All compatible donors in your area will be notified immediately.
              </p>
            </div>
          )}

          <Button
            type="submit"
            className="w-full h-12 text-base font-semibold"
            disabled={loading}
            data-testid="button-submit-request"
          >
            {loading ? "Submitting..." : (
              <>
                <Droplets className="w-4 h-4 mr-2" />
                Submit Blood Request
              </>
            )}
          </Button>
        </form>
      </div>
      <MobileNav />
    </div>
  );
}
