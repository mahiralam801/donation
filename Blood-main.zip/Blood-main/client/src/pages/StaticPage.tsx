import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Droplets } from "lucide-react";
import { Link } from "wouter";

const PAGE_META: Record<string, { title: string; icon: string }> = {
  about_us: { title: "About Us", icon: "❤️" },
  contact_us: { title: "Contact Us", icon: "📬" },
  privacy_policy: { title: "Privacy Policy", icon: "🔒" },
  terms_of_use: { title: "Terms of Use", icon: "📋" },
  disclaimer: { title: "Disclaimer", icon: "⚠️" },
};

const SLUG_TO_TYPE: Record<string, string> = {
  about: "about_us",
  contact: "contact_us",
  privacy: "privacy_policy",
  terms: "terms_of_use",
  disclaimer: "disclaimer",
};

export default function StaticPage() {
  const params = useParams<{ slug: string }>();
  const [, navigate] = useLocation();
  const pageType = SLUG_TO_TYPE[params.slug] || params.slug;
  const meta = PAGE_META[pageType];

  const { data: page, isLoading, isError } = useQuery<any>({
    queryKey: ["/api/pages", pageType],
    queryFn: async () => {
      const res = await fetch(`/api/pages/${pageType}`);
      if (!res.ok) throw new Error("Page not found");
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-3xl mx-auto px-4 py-10 space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-4/6" />
          <Skeleton className="h-40 w-full" />
        </div>
      </div>
    );
  }

  if (isError || !page) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center px-4">
        <p className="text-4xl">📄</p>
        <h1 className="text-xl font-bold">Page not found</h1>
        <p className="text-muted-foreground text-sm">This page hasn't been set up yet.</p>
        <Button variant="outline" onClick={() => navigate(-1 as any)}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Go Back
        </Button>
      </div>
    );
  }

  if (!page.isPublished) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 text-center px-4">
        <p className="text-4xl">🔒</p>
        <h1 className="text-xl font-bold">Page Unavailable</h1>
        <p className="text-muted-foreground text-sm">This page is currently not available.</p>
        <Button variant="outline" onClick={() => navigate(-1 as any)}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Go Back
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur z-10">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center gap-3">
          <Link href="/">
            <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-back-home">
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
          </Link>
          <div className="w-px h-4 bg-border" />
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-primary/10 flex items-center justify-center">
              <Droplets className="w-3.5 h-3.5 text-primary" />
            </div>
            <span className="font-black text-sm text-primary">LifeFlow</span>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-10">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">{meta?.icon || "📄"}</span>
            <h1 className="text-3xl font-black" data-testid="static-page-title">{page.title}</h1>
          </div>
          {page.updatedAt && (
            <p className="text-xs text-muted-foreground">
              Last updated: {new Date(page.updatedAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
            </p>
          )}
        </div>

        <article
          className="prose prose-sm max-w-none dark:prose-invert prose-headings:font-black prose-a:text-primary"
          dangerouslySetInnerHTML={{ __html: page.content }}
          data-testid="static-page-content"
        />
      </main>

      <footer className="border-t mt-16">
        <div className="max-w-3xl mx-auto px-4 py-6 flex flex-wrap gap-4 text-xs text-muted-foreground justify-center">
          {[
            { slug: "about", label: "About Us" },
            { slug: "contact", label: "Contact Us" },
            { slug: "privacy", label: "Privacy Policy" },
            { slug: "terms", label: "Terms of Use" },
            { slug: "disclaimer", label: "Disclaimer" },
          ].map(({ slug, label }) => (
            <Link key={slug} href={`/pages/${slug}`}>
              <button className="hover:text-foreground transition-colors" data-testid={`footer-link-${slug}`}>{label}</button>
            </Link>
          ))}
        </div>
      </footer>
    </div>
  );
}
