import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MobileNav } from "@/components/MobileNav";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getStoredUser, urgencyColor, timeSince } from "@/lib/auth";
import {
  Droplets, Hospital, MapPin, Clock, Phone, MessageCircle,
  CheckCircle2, RefreshCw, AlertTriangle, Flame, ChevronRight,
  Calendar, User, XCircle, EyeOff,
} from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import type { BloodRequest } from "@shared/schema";

function shareOnWhatsApp(req: BloodRequest) {
  const today = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  const r = req as any;
  const location = [req.city, r.district, req.state].filter(Boolean).join(", ");
  const message = [
    "🚨 *Urgent Blood Needed*",
    "",
    `Blood Group: *${req.bloodGroup}*`,
    `Hospital: ${req.hospital}`,
    `Location: ${location}`,
    `Date: ${today}`,
    `Units: ${req.unitsNeeded}`,
    req.urgency === "emergency" ? "\n⚠️ *This is a CRITICAL EMERGENCY*" : "",
    r.notes ? `\nNote: ${r.notes}` : "",
    "",
    "If you can donate please contact:",
    `Phone: *${req.contactPhone}*`,
  ].filter(l => l !== null).join("\n");
  window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, "_blank");
}

const URGENCY_ICONS: Record<string, any> = {
  emergency: Flame,
  urgent: AlertTriangle,
  normal: null,
};

const COMPATIBLE_GROUPS: Record<string, string[]> = {
  "O-": ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"],
  "O+": ["O+", "A+", "B+", "AB+"],
  "A-": ["A-", "A+", "AB-", "AB+"],
  "A+": ["A+", "AB+"],
  "B-": ["B-", "B+", "AB-", "AB+"],
  "B+": ["B+", "AB+"],
  "AB-": ["AB-", "AB+"],
  "AB+": ["AB+"],
};

function getSkippedRequests(): Set<string> {
  try {
    const stored = localStorage.getItem("skipped_requests");
    return stored ? new Set(JSON.parse(stored)) : new Set();
  } catch { return new Set(); }
}

function skipRequest(id: string) {
  const set = getSkippedRequests();
  set.add(id);
  localStorage.setItem("skipped_requests", JSON.stringify([...set]));
}

export default function OpenRequests() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const user = getStoredUser();
  const [filter, setFilter] = useState<"all" | "compatible">("compatible");
  const [skipped, setSkipped] = useState<Set<string>>(getSkippedRequests);

  const { data: openRequests = [], isLoading, refetch, isFetching } = useQuery<BloodRequest[]>({
    queryKey: ["/api/requests/open"],
    refetchInterval: 5000,
  });

  const acceptMutation = useMutation({
    mutationFn: async (requestId: string) => {
      const res = await apiRequest("PATCH", `/api/requests/${requestId}`, {
        status: "accepted",
        donorId: user?.id,
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to accept");
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/open"] });
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({ title: "You accepted the request!", description: "You can now chat with the requester." });
      setLocation(`/chat/${data.id}`);
    },
    onError: (e: any) => {
      toast({ title: "Could not accept", description: e.message, variant: "destructive" });
    },
  });

  const handleSkip = (id: string) => {
    skipRequest(id);
    setSkipped(getSkippedRequests());
    toast({ title: "Request hidden", description: "You won't see this request again." });
  };

  const userBloodGroup = user?.bloodGroup || "";
  const compatibleGroups = COMPATIBLE_GROUPS[userBloodGroup] || [];

  const visibleRequests = openRequests.filter(r => !skipped.has(r.id));

  const filtered = filter === "compatible"
    ? visibleRequests.filter(r => compatibleGroups.includes(r.bloodGroup))
    : visibleRequests;

  const urgencyOrder = { emergency: 0, urgent: 1, normal: 2 };
  const sorted = [...filtered].sort((a, b) =>
    (urgencyOrder[a.urgency as keyof typeof urgencyOrder] ?? 2) -
    (urgencyOrder[b.urgency as keyof typeof urgencyOrder] ?? 2)
  );

  const emergencyCount = visibleRequests.filter(r => r.urgency === "emergency").length;

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-10 pb-6 sticky top-0 z-10">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <Droplets className="w-5 h-5" />
              <h1 className="text-xl font-black">Donate Blood</h1>
            </div>
            <button
              onClick={() => refetch()}
              disabled={isFetching}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              data-testid="button-refresh-requests"
            >
              <RefreshCw className={`w-4 h-4 ${isFetching ? "animate-spin" : ""}`} />
            </button>
          </div>
          <p className="text-red-200 text-xs">
            {visibleRequests.length} open request{visibleRequests.length !== 1 ? "s" : ""}
            {emergencyCount > 0 && (
              <span className="ml-2 bg-red-900/50 text-red-100 px-1.5 py-0.5 rounded text-[10px] font-semibold">
                {emergencyCount} EMERGENCY
              </span>
            )}
          </p>
          <p className="text-red-300 text-[10px] mt-0.5 flex items-center gap-1">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            Live · updates every 5 seconds
          </p>
        </div>
      </div>

      <div className="px-4 py-4 max-w-md mx-auto space-y-4">
        {/* Filter Toggle */}
        <div className="flex items-center gap-2 bg-muted rounded-lg p-1">
          <button
            onClick={() => setFilter("compatible")}
            className={`flex-1 text-xs py-1.5 px-3 rounded-md font-medium transition-all ${filter === "compatible" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
            data-testid="filter-compatible"
          >
            Compatible ({visibleRequests.filter(r => compatibleGroups.includes(r.bloodGroup)).length})
          </button>
          <button
            onClick={() => setFilter("all")}
            className={`flex-1 text-xs py-1.5 px-3 rounded-md font-medium transition-all ${filter === "all" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
            data-testid="filter-all"
          >
            All Requests ({visibleRequests.length})
          </button>
        </div>

        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Card key={i}><CardContent className="p-4"><Skeleton className="h-28 w-full" /></CardContent></Card>
            ))}
          </div>
        )}

        {!isLoading && sorted.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <p className="font-semibold text-sm">
              {filter === "compatible" ? "No compatible requests right now" : "No open requests right now"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {filter === "compatible"
                ? "Switch to 'All Requests' to see other blood groups"
                : "Check back soon — this refreshes every 5 seconds"}
            </p>
            {filter === "compatible" && (
              <Button variant="outline" size="sm" className="mt-4" onClick={() => setFilter("all")} data-testid="button-show-all">
                Show All Requests
              </Button>
            )}
          </div>
        )}

        {sorted.map(req => {
          const isEmergency = req.urgency === "emergency";
          const isUrgent = req.urgency === "urgent";
          const r = req as any;

          return (
            <Card
              key={req.id}
              data-testid={`open-request-card-${req.id}`}
              className={`overflow-hidden transition-all ${isEmergency ? "border-red-300 dark:border-red-700 shadow-red-100 dark:shadow-none shadow-md" : isUrgent ? "border-orange-200 dark:border-orange-800" : ""}`}
            >
              {isEmergency && (
                <div className="bg-red-600 text-white px-3 py-1.5 flex items-center gap-1.5 text-xs font-semibold">
                  <Flame className="w-3 h-3 animate-pulse" />
                  EMERGENCY — Immediate donor needed
                </div>
              )}
              {isUrgent && !isEmergency && (
                <div className="bg-orange-500 text-white px-3 py-1.5 flex items-center gap-1.5 text-xs font-semibold">
                  <AlertTriangle className="w-3 h-3" /> URGENT
                </div>
              )}
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm truncate">{req.patientName}</p>
                    <p className="text-[10px] text-muted-foreground">{timeSince(req.createdAt!)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <BloodGroupBadge group={req.bloodGroup} size="md" />
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${urgencyColor(req.urgency || "normal")}`}>
                      {(req.urgency || "normal").charAt(0).toUpperCase() + (req.urgency || "normal").slice(1)}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 mb-4">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Hospital className="w-3.5 h-3.5 flex-shrink-0" />
                    <span className="truncate font-medium text-foreground">{req.hospital}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>
                      {req.city}{r.district ? `, ${r.district}` : ""}{req.state ? `, ${req.state}` : ""}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{req.unitsNeeded} unit{req.unitsNeeded > 1 ? "s" : ""} needed</span>
                  </div>
                  {r.requiredByDate && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="w-3.5 h-3.5 flex-shrink-0 text-orange-500" />
                      <span>Required by: <strong className="text-foreground">{new Date(r.requiredByDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</strong></span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <User className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>Contact: <strong className="text-foreground">{r.contactName || "—"}</strong></span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Phone className="w-3.5 h-3.5 flex-shrink-0 text-muted-foreground" />
                    <a href={`tel:${req.contactPhone}`} className="text-primary font-medium hover:underline" data-testid={`link-contact-${req.id}`}>
                      {req.contactPhone}
                    </a>
                  </div>
                </div>

                {req.notes && (
                  <p className="text-xs text-muted-foreground bg-muted rounded-md px-2.5 py-1.5 mb-3 italic">
                    "{req.notes}"
                  </p>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button
                    className="flex-1 bg-primary hover:bg-primary/90"
                    size="sm"
                    onClick={() => acceptMutation.mutate(req.id)}
                    disabled={acceptMutation.isPending}
                    data-testid={`button-accept-request-${req.id}`}
                  >
                    {acceptMutation.isPending ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 mr-1.5" />
                    )}
                    Accept
                    <ChevronRight className="w-3.5 h-3.5 ml-auto" />
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    className="px-3 text-muted-foreground border-border hover:bg-muted/50 hover:text-foreground"
                    onClick={() => handleSkip(req.id)}
                    data-testid={`button-skip-request-${req.id}`}
                    title="Not available for this request"
                  >
                    <EyeOff className="w-4 h-4 mr-1" />
                    Skip
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="px-2 text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-900/20"
                    onClick={() => shareOnWhatsApp(req)}
                    data-testid={`button-whatsapp-${req.id}`}
                    title="Share on WhatsApp"
                  >
                    <SiWhatsapp className="w-4 h-4" />
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="px-3 text-muted-foreground hover:text-foreground"
                    onClick={() => setLocation(`/chat/${req.id}`)}
                    data-testid={`button-contact-${req.id}`}
                    title="Contact requester"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <MobileNav />
    </div>
  );
}
