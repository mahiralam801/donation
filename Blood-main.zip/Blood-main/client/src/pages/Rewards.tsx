import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { MobileNav } from "@/components/MobileNav";
import { Skeleton } from "@/components/ui/skeleton";
import { getStoredUser } from "@/lib/auth";
import { ArrowLeft, Award, Star, Zap, Trophy, Lock, CheckCircle } from "lucide-react";
import type { Badge, UserBadge } from "@shared/schema";

const badgeStyle: Record<string, { bg: string; text: string; ring: string }> = {
  bronze:   { bg: "from-amber-600 to-amber-800", text: "text-amber-50", ring: "ring-amber-500" },
  silver:   { bg: "from-gray-400 to-gray-600", text: "text-gray-50", ring: "ring-gray-400" },
  gold:     { bg: "from-yellow-400 to-yellow-600", text: "text-yellow-50", ring: "ring-yellow-400" },
  platinum: { bg: "from-purple-500 to-purple-700", text: "text-purple-50", ring: "ring-purple-500" },
};

export default function Rewards() {
  const [, setLocation] = useLocation();
  const user = getStoredUser();

  const { data: allBadges = [], isLoading: badgesLoading } = useQuery<Badge[]>({
    queryKey: ["/api/badges"],
  });

  const { data: myBadges = [] } = useQuery<(UserBadge & { badge: Badge })[]>({
    queryKey: ["/api/my-badges"],
  });

  const earnedBadgeIds = new Set(myBadges.map(ub => ub.badgeId));
  const points = user?.rewardPoints || 0;
  const donations = user?.totalDonations || 0;

  const levels = [
    { name: "New Donor", min: 0, max: 1, points: 0 },
    { name: "Active Donor", min: 1, max: 3, points: 100 },
    { name: "Regular Donor", min: 3, max: 10, points: 300 },
    { name: "Dedicated Donor", min: 10, max: 25, points: 1000 },
    { name: "Hero Donor", min: 25, max: 999, points: 2500 },
  ];

  const currentLevel = levels.findLast(l => donations >= l.min) || levels[0];
  const nextLevel = levels[levels.indexOf(currentLevel) + 1];
  const progress = nextLevel
    ? Math.round(((donations - currentLevel.min) / (nextLevel.min - currentLevel.min)) * 100)
    : 100;

  const rewards = [
    { points: 100, label: "1st Donation Badge", done: donations >= 1 },
    { points: 300, label: "Regular Donor Recognition", done: donations >= 3 },
    { points: 500, label: "Community Champion", done: points >= 500 },
    { points: 1000, label: "Elite Donor Status", done: donations >= 10 },
    { points: 2500, label: "Life Hero Certificate", done: donations >= 25 },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-gradient-to-br from-yellow-500 via-orange-500 to-red-600 text-white px-4 pt-10 pb-8">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-yellow-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5" />
            <h1 className="text-xl font-black">Rewards</h1>
          </div>

          {/* Points display */}
          <div className="bg-white/15 backdrop-blur rounded-2xl p-5 text-center mb-4">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Zap className="w-6 h-6 text-yellow-200" />
              <span className="text-4xl font-black" data-testid="text-reward-points">{points}</span>
            </div>
            <p className="text-yellow-100 text-sm">Reward Points</p>
            <div className="flex justify-center gap-6 mt-3 pt-3 border-t border-white/20">
              <div className="text-center">
                <p className="text-xl font-black">{donations}</p>
                <p className="text-yellow-200 text-xs">Donations</p>
              </div>
              <div className="text-center">
                <p className="text-xl font-black">{myBadges.length}</p>
                <p className="text-yellow-200 text-xs">Badges</p>
              </div>
              <div className="text-center">
                <p className="text-xl font-black">{currentLevel.name.split(" ")[0]}</p>
                <p className="text-yellow-200 text-xs">Level</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto space-y-5">
        {/* Level Progress */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Trophy className="w-4 h-4 text-yellow-500" /> Donor Level
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <div>
                <p className="font-bold text-sm">{currentLevel.name}</p>
                <p className="text-xs text-muted-foreground">{donations} donations</p>
              </div>
              {nextLevel && (
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Next level</p>
                  <p className="font-medium text-xs">{nextLevel.name}</p>
                </div>
              )}
            </div>
            <Progress value={progress} className="h-2" />
            {nextLevel && (
              <p className="text-xs text-muted-foreground mt-1.5">
                {nextLevel.min - donations} more donation{nextLevel.min - donations !== 1 ? "s" : ""} to reach {nextLevel.name}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Milestones */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-500" /> Milestones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2.5">
              {rewards.map(r => (
                <div key={r.label} className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${r.done ? "bg-green-100 dark:bg-green-900/30" : "bg-muted"}`}>
                    {r.done ? <CheckCircle className="w-4 h-4 text-green-600" /> : <Lock className="w-3.5 h-3.5 text-muted-foreground" />}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm ${r.done ? "font-medium" : "text-muted-foreground"}`}>{r.label}</p>
                    <p className="text-xs text-muted-foreground">{r.points} points</p>
                  </div>
                  {r.done && <span className="text-xs text-green-600 font-medium">Earned</span>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Badges */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Award className="w-4 h-4 text-yellow-500" /> Badges
              <span className="text-xs text-muted-foreground font-normal ml-auto">{myBadges.length}/{allBadges.length} earned</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {badgesLoading && <Skeleton className="h-24 w-full" />}
            <div className="grid grid-cols-2 gap-3">
              {allBadges.map(badge => {
                const earned = earnedBadgeIds.has(badge.id);
                const style = badgeStyle[badge.level || "bronze"];
                return (
                  <div
                    key={badge.id}
                    className={`p-3 rounded-xl ${earned ? `bg-gradient-to-br ${style.bg} ring-2 ${style.ring}` : "bg-muted"}`}
                    data-testid={`badge-item-${badge.id}`}
                  >
                    <div className="text-2xl mb-1.5">{badge.icon}</div>
                    <p className={`text-xs font-bold ${earned ? style.text : "text-muted-foreground"}`}>{badge.name}</p>
                    <p className={`text-[10px] mt-0.5 ${earned ? "text-white/70" : "text-muted-foreground"}`}>
                      {badge.donationsRequired}+ donations
                    </p>
                    {earned && (
                      <div className="flex items-center gap-1 mt-1.5">
                        <CheckCircle className="w-3 h-3 text-white/80" />
                        <span className="text-[10px] text-white/80">Earned</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
      <MobileNav />
    </div>
  );
}
