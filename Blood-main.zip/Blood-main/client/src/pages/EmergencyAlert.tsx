import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MobileNav } from "@/components/MobileNav";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { BLOOD_GROUPS, getStoredUser } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, ArrowLeft, Siren, Users, MapPin, Hospital, Phone, Flame, CheckCircle2 } from "lucide-react";

const emergencySchema = z.object({
  bloodGroup: z.enum(["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]),
  state: z.string().min(2, "State is required"),
  district: z.string().min(2, "District is required"),
  city: z.string().min(2, "City / Block is required"),
  hospital: z.string().min(3, "Hospital name is required"),
  unitsNeeded: z.coerce.number().min(1).max(20),
  contactPhone: z.string().min(10, "Valid phone number required"),
  notes: z.string().max(500).optional(),
});
type EmergencyFormData = z.infer<typeof emergencySchema>;

export default function EmergencyAlert() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const currentUser = getStoredUser();
  const [submitted, setSubmitted] = useState(false);
  const [alertId, setAlertId] = useState<string | null>(null);

  const form = useForm<EmergencyFormData>({
    resolver: zodResolver(emergencySchema),
    defaultValues: {
      bloodGroup: (currentUser?.bloodGroup as any) || "O+",
      state: currentUser?.state || "",
      district: "",
      city: currentUser?.city || "",
      hospital: "",
      unitsNeeded: 1,
      contactPhone: currentUser?.phone || "",
      notes: "",
    },
  });

  const alertMutation = useMutation({
    mutationFn: async (data: EmergencyFormData) => {
      const res = await apiRequest("POST", "/api/requests", {
        patientName: "Emergency Patient",
        bloodGroup: data.bloodGroup,
        unitsNeeded: data.unitsNeeded,
        hospital: data.hospital,
        city: data.city,
        state: data.state,
        district: data.district,
        contactPhone: data.contactPhone,
        contactName: currentUser?.fullName || "Emergency Contact",
        urgency: "emergency",
        requestType: "emergency_alert",
        notes: data.notes || null,
      });
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      setAlertId(result.id);
      setSubmitted(true);
    },
    onError: (e: any) => {
      toast({ title: e.message?.replace(/^\d+: /, "") || "Failed to send alert", variant: "destructive" });
    },
  });

  const onSubmit = (data: EmergencyFormData) => alertMutation.mutate(data);

  if (submitted) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <div className="bg-gradient-to-br from-red-600 to-red-900 text-white px-4 pt-10 pb-8">
          <div className="max-w-md mx-auto">
            <button onClick={() => setLocation("/dashboard")} className="mb-4 flex items-center gap-1 text-red-200 text-sm">
              <ArrowLeft className="w-4 h-4" /> Dashboard
            </button>
            <h1 className="text-2xl font-black flex items-center gap-2">
              <Siren className="w-6 h-6 animate-pulse" /> Emergency Alert
            </h1>
          </div>
        </div>
        <div className="px-4 py-8 max-w-md mx-auto text-center">
          <div className="w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-xl font-black mb-2">Alert Sent!</h2>
          <p className="text-muted-foreground text-sm mb-6">
            Your emergency blood alert has been sent to up to <strong>50 nearby donors</strong> matching the blood group and location. They will receive notifications immediately.
          </p>
          <Card className="border-green-200 dark:border-green-800 mb-6 text-left">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Users className="w-3.5 h-3.5 text-green-600" />
                <span>Up to 50 nearby donors notified</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="w-3.5 h-3.5 text-blue-500" />
                <span>Filtered by your district and city</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Flame className="w-3.5 h-3.5 text-red-500" />
                <span>Alert is live in the open requests feed</span>
              </div>
            </CardContent>
          </Card>
          <div className="flex flex-col gap-3">
            <Button onClick={() => setLocation(`/chat/${alertId}`)} className="w-full">
              <Phone className="w-4 h-4 mr-2" /> Monitor Responses
            </Button>
            <Button variant="outline" onClick={() => setLocation("/my-requests")} className="w-full">
              View My Requests
            </Button>
            <Button variant="ghost" onClick={() => { setSubmitted(false); form.reset(); }} className="w-full text-sm">
              Send Another Alert
            </Button>
          </div>
        </div>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-red-600 via-red-700 to-red-900 text-white px-4 pt-10 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-white/20 blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-32 h-32 rounded-full bg-white/10 blur-2xl translate-y-1/2" />
        </div>
        <div className="max-w-md mx-auto relative">
          <button onClick={() => setLocation("/dashboard")} className="mb-4 flex items-center gap-1 text-red-200 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-11 h-11 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Siren className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-black">Emergency Blood Alert</h1>
              <p className="text-red-200 text-xs">Notify up to 50 nearby donors instantly</p>
            </div>
          </div>
        </div>
      </div>

      {/* Warning Banner */}
      <div className="max-w-md mx-auto px-4 mt-4">
        <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl p-3 flex items-start gap-2.5 mb-4">
          <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-red-700 dark:text-red-400">
            <strong>Use only for genuine emergencies.</strong> This will immediately notify nearby donors with matching blood groups. False alerts are a misuse of the system.
          </p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="px-4 max-w-md mx-auto space-y-4">

          {/* Blood Group */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                  <span className="text-red-600 text-xs font-black">+</span>
                </div>
                <span className="font-semibold text-sm">Blood Group Required</span>
              </div>
              <FormField
                control={form.control}
                name="bloodGroup"
                render={({ field }) => (
                  <FormItem>
                    <div className="grid grid-cols-4 gap-2">
                      {BLOOD_GROUPS.map(bg => (
                        <button
                          key={bg}
                          type="button"
                          data-testid={`bg-btn-${bg.replace("+", "pos").replace("-", "neg")}`}
                          onClick={() => field.onChange(bg)}
                          className={`py-2.5 rounded-xl border-2 font-black text-sm transition-all ${
                            field.value === bg
                              ? "border-red-600 bg-red-600 text-white scale-105 shadow-md"
                              : "border-border hover:border-red-300 hover:scale-105"
                          }`}
                        >
                          {bg}
                        </button>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Location */}
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-blue-500" />
                <span className="font-semibold text-sm">Location</span>
              </div>
              <FormField control={form.control} name="state" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground">State / Region</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. West Bengal" data-testid="input-state" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="district" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground">District</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. Burdwan" data-testid="input-district" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="city" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground">City / Block</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. Durgapur" data-testid="input-city" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </CardContent>
          </Card>

          {/* Hospital Details */}
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <Hospital className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">Hospital & Contact</span>
              </div>
              <FormField control={form.control} name="hospital" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground">Hospital Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. City Medical Center" data-testid="input-hospital" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="unitsNeeded" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground">Units Needed</FormLabel>
                    <FormControl>
                      <Input {...field} type="number" min="1" max="20" data-testid="input-units" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="contactPhone" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground">Contact Phone</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="+91XXXXXXXXXX" data-testid="input-contact-phone" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </CardContent>
          </Card>

          {/* Emergency Message */}
          <Card>
            <CardContent className="p-4">
              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold flex items-center gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-orange-500" /> Emergency Message (optional)
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      rows={3}
                      placeholder="e.g. Critical surgery tonight, patient is type 2 diabetic, please contact immediately."
                      className="resize-none text-sm"
                      data-testid="input-emergency-message"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </CardContent>
          </Card>

          <Button
            type="submit"
            className="w-full h-12 text-base font-bold bg-red-600 hover:bg-red-700 shadow-lg shadow-red-500/30"
            disabled={alertMutation.isPending}
            data-testid="button-send-emergency-alert"
          >
            {alertMutation.isPending ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Sending Alert…
              </>
            ) : (
              <>
                <Siren className="w-5 h-5 mr-2" />
                Send Emergency Alert to 50 Donors
              </>
            )}
          </Button>
        </form>
      </Form>
      <MobileNav />
    </div>
  );
}
