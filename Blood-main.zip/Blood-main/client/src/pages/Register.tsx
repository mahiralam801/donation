import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { setToken, setStoredUser, BLOOD_GROUPS } from "@/lib/auth";
import { ArrowLeft, Droplets, User, Phone, MapPin, Heart } from "lucide-react";
import { COUNTRIES } from "@/lib/countries";

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [isDonor, setIsDonor] = useState(true);

  const [form, setForm] = useState({
    fullName: "", email: "", phone: "", password: "", confirmPassword: "",
    bloodGroup: "", dateOfBirth: "", gender: "",
    address: "", city: "", state: "", country: "India",
  });

  const update = (k: string, v: string) => setForm(prev => ({ ...prev, [k]: v }));

  const handleNext = () => {
    if (step === 1) {
      if (!form.fullName || !form.email || !form.phone || !form.password || !form.confirmPassword) {
        return toast({ title: "Please fill all fields", variant: "destructive" });
      }
      if (form.password !== form.confirmPassword) {
        return toast({ title: "Passwords don't match", variant: "destructive" });
      }
      if (form.password.length < 6) {
        return toast({ title: "Password must be at least 6 characters", variant: "destructive" });
      }
    }
    if (step === 2) {
      if (!form.bloodGroup) {
        return toast({ title: "Please select your blood group", variant: "destructive" });
      }
    }
    setStep(s => s + 1);
  };

  const handleSubmit = async () => {
    if (!form.city) return toast({ title: "Please enter your city", variant: "destructive" });
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/auth/register", {
        ...form,
        isDonor,
        isAvailable: isDonor,
      });
      const data = await res.json();
      if (data.requiresVerification === false && data.token) {
        const { setToken, setStoredUser } = await import("@/lib/auth");
        setToken(data.token);
        setStoredUser(data.user);
        toast({ title: "Registration successful! Welcome to LifeFlow." });
        setLocation("/dashboard");
      } else {
        toast({ title: "Registration successful! Check your email for a verification code." });
        setLocation(`/verify-email?email=${encodeURIComponent(data.email || form.email)}`);
      }
    } catch (e: any) {
      toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const steps = [
    { icon: User, label: "Account" },
    { icon: Heart, label: "Blood Info" },
    { icon: MapPin, label: "Location" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-8 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => step > 1 ? setStep(s => s - 1) : setLocation("/")} className="mb-4 flex items-center gap-1 text-red-100">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">{step > 1 ? "Back" : "Login"}</span>
          </button>
          <div className="flex items-center gap-2 mb-4">
            <Droplets className="w-6 h-6" />
            <h1 className="text-xl font-bold">Create Account</h1>
          </div>
          {/* Step Indicators */}
          <div className="flex items-center gap-2">
            {steps.map((s, i) => {
              const Icon = s.icon;
              const isActive = step === i + 1;
              const isDone = step > i + 1;
              return (
                <div key={s.label} className="flex items-center gap-2">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold border-2 transition-colors ${isActive ? "bg-white text-primary border-white" : isDone ? "bg-white/30 border-white/60 text-white" : "bg-white/10 border-white/30 text-white/50"}`}>
                    {isDone ? "✓" : <Icon className="w-4 h-4" />}
                  </div>
                  <span className={`text-xs ${isActive ? "text-white font-medium" : "text-red-200"}`}>{s.label}</span>
                  {i < steps.length - 1 && <div className="w-4 h-px bg-white/30" />}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="px-4 py-6 max-w-md mx-auto">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{steps[step - 1].label} Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {step === 1 && (
              <>
                <div>
                  <Label>Full Name</Label>
                  <Input value={form.fullName} onChange={e => update("fullName", e.target.value)} placeholder="John Doe" className="mt-1" data-testid="input-full-name" />
                </div>
                <div>
                  <Label>Email Address</Label>
                  <Input type="email" value={form.email} onChange={e => update("email", e.target.value)} placeholder="john@example.com" className="mt-1" data-testid="input-reg-email" />
                </div>
                <div>
                  <Label>Phone Number</Label>
                  <Input value={form.phone} onChange={e => update("phone", e.target.value)} placeholder="+1234567890" className="mt-1" data-testid="input-phone" />
                </div>
                <div>
                  <Label>Password</Label>
                  <Input type="password" value={form.password} onChange={e => update("password", e.target.value)} placeholder="At least 6 characters" className="mt-1" data-testid="input-reg-password" />
                </div>
                <div>
                  <Label>Confirm Password</Label>
                  <Input type="password" value={form.confirmPassword} onChange={e => update("confirmPassword", e.target.value)} placeholder="Repeat password" className="mt-1" data-testid="input-confirm-password" />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div>
                  <Label>Blood Group *</Label>
                  <Select value={form.bloodGroup} onValueChange={v => update("bloodGroup", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-blood-group">
                      <SelectValue placeholder="Select blood group" />
                    </SelectTrigger>
                    <SelectContent>
                      {BLOOD_GROUPS.map(bg => (
                        <SelectItem key={bg} value={bg}>{bg}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Date of Birth</Label>
                  <Input type="date" value={form.dateOfBirth} onChange={e => update("dateOfBirth", e.target.value)} className="mt-1" data-testid="input-dob" />
                </div>
                <div>
                  <Label>Gender</Label>
                  <Select value={form.gender} onValueChange={v => update("gender", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-gender">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                  <div>
                    <p className="text-sm font-medium">Register as Donor</p>
                    <p className="text-xs text-muted-foreground">Allow others to find you for blood requests</p>
                  </div>
                  <Switch checked={isDonor} onCheckedChange={setIsDonor} data-testid="switch-is-donor" />
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div>
                  <Label>Country *</Label>
                  <Select value={form.country} onValueChange={v => update("country", v)}>
                    <SelectTrigger className="mt-1" data-testid="select-country">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent className="max-h-60 overflow-y-auto">
                      {COUNTRIES.map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>State / Region</Label>
                    <Input value={form.state} onChange={e => update("state", e.target.value)} placeholder="Your state" className="mt-1" data-testid="input-state" />
                  </div>
                  <div>
                    <Label>City *</Label>
                    <Input value={form.city} onChange={e => update("city", e.target.value)} placeholder="Your city" className="mt-1" data-testid="input-city" />
                  </div>
                </div>
                <div>
                  <Label>Address</Label>
                  <Input value={form.address} onChange={e => update("address", e.target.value)} placeholder="Street address" className="mt-1" data-testid="input-address" />
                </div>
              </>
            )}

            {step < 3 ? (
              <Button onClick={handleNext} className="w-full" data-testid="button-next-step">
                Continue
              </Button>
            ) : (
              <Button onClick={handleSubmit} className="w-full" disabled={loading} data-testid="button-register-submit">
                {loading ? "Creating Account..." : "Create Account"}
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
