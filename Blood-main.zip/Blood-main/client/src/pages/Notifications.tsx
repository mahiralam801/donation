import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MobileNav } from "@/components/MobileNav";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { timeSince } from "@/lib/auth";
import { ArrowLeft, Bell, CheckCheck, Heart, Calendar, Award, AlertTriangle, Info } from "lucide-react";
import type { Notification } from "@shared/schema";

const typeConfig: Record<string, { icon: any; color: string; bg: string }> = {
  request: { icon: Heart, color: "text-red-600", bg: "bg-red-100 dark:bg-red-900/30" },
  acceptance: { icon: CheckCheck, color: "text-green-600", bg: "bg-green-100 dark:bg-green-900/30" },
  camp: { icon: Calendar, color: "text-blue-600", bg: "bg-blue-100 dark:bg-blue-900/30" },
  reward: { icon: Award, color: "text-yellow-600", bg: "bg-yellow-100 dark:bg-yellow-900/30" },
  system: { icon: Info, color: "text-gray-600", bg: "bg-gray-100 dark:bg-gray-800" },
};

export default function Notifications() {
  const [, setLocation] = useLocation();

  const { data: notifications = [], isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  const markAllMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/notifications/read-all", {});
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/notifications"] }),
  });

  const markOneMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/notifications/${id}/read`, {});
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/notifications"] }),
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const grouped: Record<string, Notification[]> = {};
  notifications.forEach(n => {
    const date = n.createdAt ? new Date(n.createdAt).toLocaleDateString() : "Unknown";
    if (!grouped[date]) grouped[date] = [];
    grouped[date].push(n);
  });

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-10 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-red-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Bell className="w-5 h-5" />
                <h1 className="text-xl font-black">Notifications</h1>
              </div>
              <p className="text-red-200 text-xs">{unreadCount} unread</p>
            </div>
            {unreadCount > 0 && (
              <Button
                size="sm"
                variant="outline"
                className="bg-white/10 border-white/30 text-white"
                onClick={() => markAllMutation.mutate()}
                disabled={markAllMutation.isPending}
                data-testid="button-mark-all-read"
              >
                <CheckCheck className="w-3.5 h-3.5 mr-1" /> Mark all read
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto space-y-5">
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}
          </div>
        )}

        {!isLoading && notifications.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
              <Bell className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">All caught up!</p>
            <p className="text-xs text-muted-foreground mt-1">No notifications yet</p>
          </div>
        )}

        {Object.entries(grouped).map(([date, notifs]) => (
          <section key={date}>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{date}</p>
            <div className="space-y-2">
              {notifs.map(n => {
                const config = typeConfig[n.type || "system"] || typeConfig.system;
                const Icon = config.icon;
                return (
                  <button
                    key={n.id}
                    onClick={() => !n.isRead && markOneMutation.mutate(n.id)}
                    className={`w-full text-left rounded-xl p-3.5 border transition-colors ${n.isRead ? "bg-background border-border opacity-70" : "bg-card border-card-border shadow-sm"}`}
                    data-testid={`notification-item-${n.id}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-9 h-9 rounded-full ${config.bg} flex items-center justify-center flex-shrink-0`}>
                        <Icon className={`w-4 h-4 ${config.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className={`text-sm leading-tight ${!n.isRead ? "font-semibold" : "font-medium"}`}>{n.title}</p>
                          {n.isGlobal && (
                            <span className="text-[9px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground uppercase tracking-wide flex-shrink-0">Global</span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{n.message}</p>
                        <p className="text-[10px] text-muted-foreground mt-1">{timeSince(n.createdAt!)}</p>
                      </div>
                      {!n.isRead && <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1.5" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </div>
      <MobileNav />
    </div>
  );
}
