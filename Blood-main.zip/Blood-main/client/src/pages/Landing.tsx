import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { setToken, setStoredUser, setStoredAdmin } from "@/lib/auth";
import { Droplets, Heart, Users, Award, ChevronRight, Phone, Mail, MapPin, Shield, FileText, Info, MessageSquare, AlertTriangle } from "lucide-react";
import { Link } from "wouter";

function formatStat(n: number | undefined): string {
  if (n === undefined) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M+`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K+`;
  return String(n);
}

const FOOTER_DEFAULTS = {
  brandName: "LifeFlow",
  brandTagline: "Blood Donation Network",
  brandDescription: "Connecting donors with patients in need. Every drop counts — be the reason someone smiles today.",
  showBloodTypes: true,
  quickLinks: '[{"label":"Home","href":"/"},{"label":"Register","href":"/register"},{"label":"About Us","href":"/pages/about"},{"label":"Contact Us","href":"/pages/contact"}]',
  legalLinks: '[{"label":"Privacy Policy","href":"/pages/privacy"},{"label":"Terms of Use","href":"/pages/terms"},{"label":"Disclaimer","href":"/pages/disclaimer"}]',
  contactEmail: "support@lifeflow.app",
  contactPhone: "+1 (800) LIFEFLOW",
  contactAddress: "Available Worldwide",
  showEmergencyBanner: true,
  emergencyTitle: "Need Blood Urgently?",
  emergencyText: "Post an emergency request — donors respond within minutes.",
  copyrightText: "LifeFlow Blood Donation Network. All rights reserved.",
};

function parseLinks(val: unknown): { label: string; href: string }[] {
  if (Array.isArray(val)) return val;
  try { return JSON.parse(val as string); } catch { return []; }
}

export default function Landing() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [tab, setTab] = useState<"user" | "admin">("user");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [adminPass, setAdminPass] = useState("");
  const [loading, setLoading] = useState(false);

  const [forgotStep, setForgotStep] = useState<0 | 1 | 2 | 3>(0);
  const [fpEmail, setFpEmail] = useState("");
  const [fpPhone, setFpPhone] = useState("");
  const [fpNewPass, setFpNewPass] = useState("");
  const [fpConfirm, setFpConfirm] = useState("");

  const handleForgotVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fpEmail) return toast({ title: "Please enter your email", variant: "destructive" });
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/auth/reset-password", {
        email: fpEmail, phone: "__check__", newPassword: "placeholder123",
      });
      await res.json();
    } catch (e: any) {
      const msg = e.message?.replace(/^\d+: /, "") || "";
      if (msg === "No account found with this email") {
        setLoading(false);
        return toast({ title: msg, variant: "destructive" });
      }
    } finally {
      setLoading(false);
    }
    setForgotStep(2);
  };

  const handleForgotReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fpPhone) return toast({ title: "Please enter your phone number", variant: "destructive" });
    if (!fpNewPass || fpNewPass.length < 6) return toast({ title: "Password must be at least 6 characters", variant: "destructive" });
    if (fpNewPass !== fpConfirm) return toast({ title: "Passwords do not match", variant: "destructive" });
    setLoading(true);
    try {
      await apiRequest("POST", "/api/auth/reset-password", {
        email: fpEmail, phone: fpPhone, newPassword: fpNewPass,
      });
      toast({ title: "Password reset successfully! Please log in." });
      setForgotStep(0);
      setFpEmail(""); setFpPhone(""); setFpNewPass(""); setFpConfirm("");
    } catch (e: any) {
      toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const { data: footerData } = useQuery<any>({
    queryKey: ["/api/public/footer"],
  });

  const footer = { ...FOOTER_DEFAULTS, ...(footerData && Object.keys(footerData).length ? footerData : {}) };
  const quickLinks = parseLinks(footer.quickLinks).length ? parseLinks(footer.quickLinks) : parseLinks(FOOTER_DEFAULTS.quickLinks);
  const legalLinks = parseLinks(footer.legalLinks).length ? parseLinks(footer.legalLinks) : parseLinks(FOOTER_DEFAULTS.legalLinks);

  const { data: stats } = useQuery<{ activeDonors: number; livesSaved: number; campsHeld: number }>({
    queryKey: ["/api/stats"],
    refetchInterval: 30_000,
  });

  const handleUserLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return toast({ title: "Please fill all fields", variant: "destructive" });
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/auth/login", { email, password });
      const data = await res.json();
      setToken(data.token);
      setStoredUser(data.user);
      setLocation("/dashboard");
    } catch (e: any) {
      const raw = e.message || "";
      const msg = raw.replace(/^\d+: /, "");
      try {
        const parsed = JSON.parse(raw.replace(/^\d+: /, ""));
        if (parsed?.needsVerification) {
          toast({ title: "Please verify your email first.", variant: "destructive" });
          setLocation(`/verify-email?email=${encodeURIComponent(parsed.email || email)}`);
          return;
        }
      } catch (_) {}
      toast({ title: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !adminPass) return toast({ title: "Please fill all fields", variant: "destructive" });
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/admin/auth/login", { username, password: adminPass });
      const data = await res.json();
      setToken(data.token);
      setStoredAdmin(data.admin);
      setLocation("/admin/dashboard");
    } catch (e: any) {
      toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-primary via-red-700 to-red-900 text-white">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute bottom-0 right-0 w-60 h-60 rounded-full bg-white/10 blur-3xl" />
        </div>
        <div className="relative px-6 pt-12 pb-10 max-w-md mx-auto text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Droplets className="w-9 h-9 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-black tracking-tight mb-2">LifeFlow</h1>
          <p className="text-red-100 text-sm font-medium mb-1">Blood Donation Network</p>
          <p className="text-red-200 text-xs leading-relaxed max-w-xs mx-auto">
            Connect donors with patients in need. Every drop of blood saves a life.
          </p>

          {/* Live indicator */}
          <div className="flex items-center justify-center gap-1.5 mt-5 mb-3">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400" />
            </span>
            <span className="text-red-100 text-[11px] font-medium tracking-wide" data-testid="text-live-indicator">Live</span>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: Users, label: "Active Donors", value: formatStat(stats?.activeDonors), testid: "stat-active-donors" },
              { icon: Heart, label: "Lives Saved", value: formatStat(stats?.livesSaved), testid: "stat-lives-saved" },
              { icon: Award, label: "Camps Held", value: formatStat(stats?.campsHeld), testid: "stat-camps-held" },
            ].map(({ icon: Icon, label, value, testid }) => (
              <div key={label} className="bg-white/10 backdrop-blur rounded-xl p-2.5 text-center">
                <Icon className="w-4 h-4 mx-auto mb-1 text-red-200" />
                <p className="text-white font-black text-sm" data-testid={testid}>{value}</p>
                <p className="text-red-200 text-[10px]">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Auth Section */}
      <div className="flex-1 px-4 py-6 max-w-md mx-auto w-full">
        {/* Tab Toggle */}
        <div className="flex bg-muted rounded-lg p-1 mb-5">
          <button
            data-testid="tab-user-login"
            onClick={() => setTab("user")}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${tab === "user" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
          >
            User Login
          </button>
          <button
            data-testid="tab-admin-login"
            onClick={() => setTab("admin")}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${tab === "admin" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
          >
            Admin Login
          </button>
        </div>

        {tab === "user" ? (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">
                {forgotStep === 0 ? "Welcome Back" : forgotStep === 1 ? "Forgot Password" : "Reset Password"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {forgotStep === 0 ? (
                <>
                  <form onSubmit={handleUserLogin} className="space-y-4">
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        data-testid="input-email"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="••••••••"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        data-testid="input-password"
                        className="mt-1"
                      />
                    </div>
                    <div className="flex justify-end -mt-1">
                      <button
                        type="button"
                        onClick={() => { setForgotStep(1); setFpEmail(email); }}
                        className="text-xs text-primary font-medium"
                        data-testid="link-forgot-password"
                      >
                        Forgot Password?
                      </button>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading} data-testid="button-login">
                      {loading ? "Signing In..." : "Sign In"}
                      {!loading && <ChevronRight className="w-4 h-4 ml-1" />}
                    </Button>
                  </form>
                  <div className="mt-4 text-center">
                    <span className="text-sm text-muted-foreground">Don't have an account? </span>
                    <button
                      onClick={() => setLocation("/register")}
                      className="text-sm text-primary font-medium"
                      data-testid="link-register"
                    >
                      Register as Donor
                    </button>
                  </div>
                </>
              ) : forgotStep === 1 ? (
                <form onSubmit={handleForgotVerify} className="space-y-4">
                  <p className="text-sm text-muted-foreground">Enter your registered email address to continue.</p>
                  <div>
                    <Label htmlFor="fp-email">Email Address</Label>
                    <Input
                      id="fp-email"
                      type="email"
                      placeholder="your@email.com"
                      value={fpEmail}
                      onChange={e => setFpEmail(e.target.value)}
                      data-testid="input-fp-email"
                      className="mt-1"
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading} data-testid="button-fp-next">
                    {loading ? "Checking..." : "Continue"}
                  </Button>
                  <button type="button" onClick={() => setForgotStep(0)} className="w-full text-sm text-muted-foreground text-center" data-testid="link-back-to-login">
                    Back to Login
                  </button>
                </form>
              ) : forgotStep === 2 ? (
                <form onSubmit={handleForgotReset} className="space-y-4">
                  <p className="text-sm text-muted-foreground">Enter your registered phone number and a new password.</p>
                  <div>
                    <Label htmlFor="fp-phone">Registered Phone Number</Label>
                    <Input
                      id="fp-phone"
                      type="tel"
                      placeholder="+91 XXXXX XXXXX"
                      value={fpPhone}
                      onChange={e => setFpPhone(e.target.value)}
                      data-testid="input-fp-phone"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="fp-newpass">New Password</Label>
                    <Input
                      id="fp-newpass"
                      type="password"
                      placeholder="Min. 6 characters"
                      value={fpNewPass}
                      onChange={e => setFpNewPass(e.target.value)}
                      data-testid="input-fp-newpass"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="fp-confirm">Confirm Password</Label>
                    <Input
                      id="fp-confirm"
                      type="password"
                      placeholder="Re-enter new password"
                      value={fpConfirm}
                      onChange={e => setFpConfirm(e.target.value)}
                      data-testid="input-fp-confirm"
                      className="mt-1"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-primary" disabled={loading} data-testid="button-fp-reset">
                    {loading ? "Resetting..." : "Reset Password"}
                  </Button>
                  <button type="button" onClick={() => setForgotStep(1)} className="w-full text-sm text-muted-foreground text-center" data-testid="link-back-to-email">
                    Back
                  </button>
                </form>
              ) : null}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Admin Access</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div>
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    placeholder="admin"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    data-testid="input-admin-username"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="adminPass">Password</Label>
                  <Input
                    id="adminPass"
                    type="password"
                    placeholder="••••••••"
                    value={adminPass}
                    onChange={e => setAdminPass(e.target.value)}
                    data-testid="input-admin-password"
                    className="mt-1"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading} data-testid="button-admin-login">
                  {loading ? "Signing In..." : "Admin Sign In"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-300 mt-auto">
        {/* 4-column grid */}
        <div className="px-5 pt-10 pb-8 max-w-5xl mx-auto">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8">

            {/* Column 1 — Brand */}
            <div className="col-span-2 sm:col-span-1 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
                  <Droplets className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-white font-black text-base leading-none">{footer.brandName}</p>
                  <p className="text-gray-500 text-[11px]">{footer.brandTagline}</p>
                </div>
              </div>
              <p className="text-gray-400 text-xs leading-relaxed">{footer.brandDescription}</p>
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400" />
                </span>
                <span className="text-green-400 text-[11px] font-medium">Platform Active</span>
              </div>
              {footer.showBloodTypes && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {["A+", "A−", "B+", "B−", "AB+", "AB−", "O+", "O−"].map(bg => (
                    <span key={bg} className="px-1.5 py-0.5 rounded bg-primary/20 border border-primary/30 text-primary text-[10px] font-bold">
                      {bg}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Column 2 — Quick Links */}
            <div className="space-y-3">
              <p className="text-white text-xs font-bold uppercase tracking-widest">Quick Links</p>
              <ul className="space-y-2">
                {quickLinks.map(({ label, href }) => (
                  <li key={label}>
                    <Link
                      href={href}
                      className="text-gray-400 hover:text-white text-xs flex items-center gap-1.5 transition-colors"
                      data-testid={`footer-link-${label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <span className="w-1 h-1 rounded-full bg-primary inline-block flex-shrink-0" />
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 3 — Legal */}
            <div className="space-y-3">
              <p className="text-white text-xs font-bold uppercase tracking-widest">Legal</p>
              <ul className="space-y-2">
                {legalLinks.map(({ label, href }) => (
                  <li key={label}>
                    <Link
                      href={href}
                      className="text-gray-400 hover:text-white text-xs flex items-center gap-1.5 transition-colors"
                      data-testid={`footer-link-${label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <span className="w-1 h-1 rounded-full bg-primary inline-block flex-shrink-0" />
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Column 4 — Contact */}
            <div className="space-y-3">
              <p className="text-white text-xs font-bold uppercase tracking-widest">Contact</p>
              <ul className="space-y-2.5">
                {footer.contactEmail && (
                  <li className="flex items-start gap-2 text-xs text-gray-400">
                    <Mail className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5" />
                    <span>{footer.contactEmail}</span>
                  </li>
                )}
                {footer.contactPhone && (
                  <li className="flex items-start gap-2 text-xs text-gray-400">
                    <Phone className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5" />
                    <span>{footer.contactPhone}</span>
                  </li>
                )}
                {footer.contactAddress && (
                  <li className="flex items-start gap-2 text-xs text-gray-400">
                    <MapPin className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5" />
                    <span>{footer.contactAddress}</span>
                  </li>
                )}
              </ul>
              {footer.showEmergencyBanner && (
                <div className="mt-3 bg-primary/10 border border-primary/25 rounded-lg p-3">
                  <p className="text-white text-[11px] font-bold flex items-center gap-1.5">
                    <Heart className="w-3 h-3 text-primary" /> {footer.emergencyTitle}
                  </p>
                  <p className="text-gray-400 text-[10px] mt-1 leading-relaxed">{footer.emergencyText}</p>
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800" />

        {/* Bottom bar */}
        <div className="px-5 py-4 max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-gray-500 text-[11px]">
            © {new Date().getFullYear()} {footer.copyrightText}
          </p>
          <p className="text-gray-600 text-[10px] flex items-center gap-1">
            Made with <Heart className="w-2.5 h-2.5 text-primary" /> to save lives worldwide
          </p>
        </div>
      </footer>
    </div>
  );
}
