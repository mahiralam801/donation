import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getStoredUser } from "@/lib/auth";
import { ArrowLeft, Send, Info } from "lucide-react";
import type { ChatMessage, BloodRequest, User } from "@shared/schema";

export default function ChatRoom() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/chat/:requestId");
  const requestId = params?.requestId;
  const user = getStoredUser();
  const [message, setMessage] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: messages = [], isLoading, refetch } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat", requestId],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/chat/${requestId}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error("Failed to load");
      return res.json();
    },
    refetchInterval: 3000,
  });

  const { data: request } = useQuery<BloodRequest>({
    queryKey: ["/api/requests", requestId],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/requests/${requestId}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  // Mark messages as read
  useEffect(() => {
    if (requestId && messages.length > 0) {
      apiRequest("POST", `/api/chat/${requestId}/read`, {});
    }
  }, [requestId, messages.length]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMutation = useMutation({
    mutationFn: async (msg: string) => {
      if (!requestId || !request) throw new Error("No request");
      const otherId = request.requesterId === user?.id ? request.donorId : request.requesterId;
      if (!otherId) throw new Error("No recipient");
      const res = await apiRequest("POST", "/api/chat", {
        requestId,
        receiverId: otherId,
        message: msg,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat", requestId] });
      setMessage("");
    },
  });

  const handleSend = () => {
    if (!message.trim()) return;
    sendMutation.mutate(message.trim());
  };

  const getInitials = (name?: string) => name?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?";

  const grouped = messages.reduce((acc, msg) => {
    const date = new Date(msg.createdAt!).toLocaleDateString();
    if (!acc[date]) acc[date] = [];
    acc[date].push(msg);
    return acc;
  }, {} as Record<string, ChatMessage[]>);

  return (
    <div className="flex flex-col h-screen bg-background max-w-md mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 pt-10 pb-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={() => setLocation("/chat")} className="text-blue-100">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-sm font-bold">
            {request?.patientName ? getInitials(request.patientName) : "?"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-sm truncate">{request?.patientName || "Blood Request"}</p>
            <p className="text-blue-200 text-xs">{request?.bloodGroup} • {request?.hospital}</p>
          </div>
          <button className="text-blue-200" data-testid="button-request-info">
            <Info className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-3/4" />)}
          </div>
        )}

        {!isLoading && messages.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-sm">Start the conversation</p>
            <p className="text-xs mt-1">Coordinate the blood donation with the requester</p>
          </div>
        )}

        {Object.entries(grouped).map(([date, msgs]) => (
          <div key={date}>
            <div className="flex items-center gap-2 my-3">
              <div className="flex-1 h-px bg-border" />
              <span className="text-[10px] text-muted-foreground px-2">{date}</span>
              <div className="flex-1 h-px bg-border" />
            </div>
            <div className="space-y-2">
              {msgs.map(msg => {
                const isMe = msg.senderId === user?.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`} data-testid={`message-${msg.id}`}>
                    <div className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${
                      isMe
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}>
                      <p className="leading-snug">{msg.message}</p>
                      <p className={`text-[10px] mt-1 ${isMe ? "text-primary-foreground/70 text-right" : "text-muted-foreground"}`}>
                        {new Date(msg.createdAt!).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex-shrink-0 px-4 py-3 border-t border-border bg-background">
        <div className="flex items-center gap-2">
          <Input
            value={message}
            onChange={e => setMessage(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder="Type a message..."
            className="flex-1"
            data-testid="input-chat-message"
          />
          <Button
            size="icon"
            onClick={handleSend}
            disabled={!message.trim() || sendMutation.isPending}
            data-testid="button-send-message"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
