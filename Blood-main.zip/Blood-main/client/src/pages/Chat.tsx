import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { MobileNav } from "@/components/MobileNav";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { getStoredUser, timeSince } from "@/lib/auth";
import { ArrowLeft, MessageCircle, User } from "lucide-react";
import type { User as UserType } from "@shared/schema";

interface Conversation {
  requestId: string | null;
  directUserId: string | null;
  isDirect: boolean;
  lastMessage: {
    id: string;
    message: string;
    senderId: string;
    createdAt: string;
    isRead: boolean;
  };
  otherUser: UserType | undefined;
}

export default function Chat() {
  const [, setLocation] = useLocation();
  const user = getStoredUser();

  const { data: conversations = [], isLoading } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 pt-10 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-blue-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            <h1 className="text-xl font-black">Messages</h1>
          </div>
          <p className="text-blue-200 text-xs mt-1">{conversations.length} conversation{conversations.length !== 1 ? "s" : ""}</p>
        </div>
      </div>

      <div className="max-w-md mx-auto divide-y divide-border">
        {isLoading && (
          <div className="p-4 space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
          </div>
        )}

        {!isLoading && conversations.length === 0 && (
          <div className="text-center py-16 px-4">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
              <MessageCircle className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="font-semibold text-sm">No messages yet</p>
            <p className="text-xs text-muted-foreground mt-1">Start a conversation through a blood request</p>
          </div>
        )}

        {conversations.map((conv, idx) => {
          const other = conv.otherUser;
          const isUnread = !conv.lastMessage.isRead && conv.lastMessage.senderId !== user?.id;
          const initials = other?.fullName?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?";
          const convKey = conv.isDirect ? `direct_${conv.directUserId}` : conv.requestId || String(idx);
          const navTarget = conv.isDirect
            ? `/direct-chat/${conv.directUserId}`
            : `/chat/${conv.requestId}`;

          return (
            <button
              key={convKey}
              onClick={() => setLocation(navTarget)}
              className="w-full flex items-center gap-3 px-4 py-3.5 hover-elevate text-left"
              data-testid={`conversation-${convKey}`}
            >
              <div className="relative flex-shrink-0">
                {other?.profileImage ? (
                  <img src={other.profileImage} className="w-12 h-12 rounded-full object-cover" alt={other.fullName} />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                    {initials}
                  </div>
                )}
                {other?.bloodGroup && (
                  <div className="absolute -bottom-1 -right-1">
                    <BloodGroupBadge group={other.bloodGroup} size="sm" className="text-[9px] px-1 py-0" />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <p className={`text-sm ${isUnread ? "font-bold" : "font-medium"} truncate`}>
                      {other?.fullName || "Unknown User"}
                    </p>
                    {conv.isDirect && (
                      <span className="flex-shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                        Direct
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-muted-foreground flex-shrink-0">
                    {timeSince(conv.lastMessage.createdAt)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 mt-0.5">
                  <p className={`text-xs truncate ${isUnread ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                    {conv.lastMessage.senderId === user?.id ? "You: " : ""}{conv.lastMessage.message}
                  </p>
                  {isUnread && <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                </div>
              </div>
            </button>
          );
        })}
      </div>
      <MobileNav />
    </div>
  );
}
