import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { statusColor, statusLabel, urgencyColor } from "@/lib/auth";
import {
  Search, Droplets, Hospital, MapPin, Clock, Phone,
  CheckCircle, Pencil, Trash2, AlertTriangle, User, X,
  Shield, Users, FileText, ImageIcon, Eye, Calendar,
  ThumbsUp, UserCheck, XCircle,
} from "lucide-react";
import type { BloodRequest, User as UserRecord } from "@shared/schema";

const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const URGENCY_LEVELS = ["normal", "urgent", "emergency"];
const STATUS_OPTIONS = ["pending", "accepted", "rejected", "fulfilled", "cancelled"];

const editSchema = z.object({
  patientName: z.string().min(2, "Patient name is required"),
  bloodGroup: z.enum(["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]),
  unitsNeeded: z.coerce.number().min(1, "At least 1 unit required").max(20),
  hospital: z.string().min(2, "Hospital name is required"),
  city: z.string().min(2, "City is required"),
  state: z.string().optional(),
  district: z.string().optional(),
  contactPhone: z.string().min(7, "Valid phone required"),
  contactName: z.string().optional(),
  urgency: z.enum(["normal", "urgent", "emergency"]),
  status: z.enum(["pending", "accepted", "fulfilled", "rejected", "cancelled"]),
  notes: z.string().optional(),
  requestType: z.string().optional(),
});
type EditFormValues = z.infer<typeof editSchema>;

export default function AdminRequests() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [editReq, setEditReq] = useState<BloodRequest | null>(null);
  const [deleteReq, setDeleteReq] = useState<BloodRequest | null>(null);
  const [viewFileReq, setViewFileReq] = useState<BloodRequest | null>(null);

  const { data: requests = [], isLoading } = useQuery<BloodRequest[]>({
    queryKey: ["/api/requests/all"],
  });

  const { data: allUsers = [] } = useQuery<Omit<UserRecord, "password">[]>({
    queryKey: ["/api/users"],
  });

  const getUserById = (id: string | null | undefined) =>
    id ? allUsers.find(u => u.id === id) : undefined;

  const form = useForm<EditFormValues>({
    resolver: zodResolver(editSchema),
    defaultValues: {
      patientName: "", bloodGroup: "O+", unitsNeeded: 1,
      hospital: "", city: "", state: "", district: "",
      contactPhone: "", contactName: "",
      urgency: "normal", status: "pending", notes: "", requestType: "user_to_donor",
    },
  });

  const openEdit = (req: BloodRequest) => {
    setEditReq(req);
    const r = req as any;
    form.reset({
      patientName: req.patientName,
      bloodGroup: req.bloodGroup as EditFormValues["bloodGroup"],
      unitsNeeded: req.unitsNeeded,
      hospital: req.hospital,
      city: req.city,
      state: req.state || "",
      district: r.district || "",
      contactPhone: req.contactPhone || "",
      contactName: r.contactName || "",
      urgency: (req.urgency || "normal") as EditFormValues["urgency"],
      status: (req.status || "pending") as EditFormValues["status"],
      notes: req.notes || "",
      requestType: r.requestType || "user_to_donor",
    });
  };

  const quickStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PUT", `/api/admin/requests/${id}`, { status });
      return res.json();
    },
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/requests/open"] });
      const labels: Record<string, string> = {
        accepted:  "Request accepted — requester notified",
        rejected:  "Request rejected",
        cancelled: "Request cancelled",
        fulfilled: "Request marked as completed",
      };
      toast({ title: labels[vars.status] || "Status updated" });
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const editMutation = useMutation({
    mutationFn: async (data: EditFormValues) => {
      const res = await apiRequest("PUT", `/api/admin/requests/${editReq!.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/all"] });
      toast({ title: "Request updated successfully" });
      setEditReq(null);
    },
    onError: (e: Error) => toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/admin/requests/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/all"] });
      toast({ title: "Request deleted" });
      setDeleteReq(null);
    },
    onError: (e: Error) => toast({ title: "Delete failed", description: e.message, variant: "destructive" }),
  });

  const filtered = requests.filter(r => {
    const matchSearch = !search ||
      r.patientName.toLowerCase().includes(search.toLowerCase()) ||
      r.hospital.toLowerCase().includes(search.toLowerCase()) ||
      r.city.toLowerCase().includes(search.toLowerCase()) ||
      r.bloodGroup.toLowerCase().includes(search.toLowerCase()) ||
      ((r as any).contactName || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" ||
      (statusFilter === "accepted" ? ["accepted", "approved", "donor_found"].includes(r.status || "") : r.status === statusFilter);
    return matchSearch && matchStatus;
  });

  const counts = {
    all: requests.length,
    pending: requests.filter(r => r.status === "pending").length,
    accepted: requests.filter(r => ["accepted", "approved", "donor_found"].includes(r.status || "")).length,
    fulfilled: requests.filter(r => r.status === "fulfilled").length,
    rejected: requests.filter(r => r.status === "rejected").length,
    cancelled: requests.filter(r => r.status === "cancelled").length,
  };

  const timeSince = (date: string | Date) => {
    const d = new Date(date);
    const secs = Math.floor((Date.now() - d.getTime()) / 1000);
    if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
    if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
    return `${Math.floor(secs / 86400)}d ago`;
  };

  const filterTabs = [
    { key: "all",       label: "All",       count: counts.all },
    { key: "pending",   label: "Pending",   count: counts.pending },
    { key: "accepted",  label: "Accepted",  count: counts.accepted },
    { key: "fulfilled", label: "Completed", count: counts.fulfilled },
    { key: "rejected",  label: "Rejected",  count: counts.rejected },
    { key: "cancelled", label: "Cancelled", count: counts.cancelled },
  ];

  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-2xl font-black">Blood Requests</h1>
        <p className="text-sm text-muted-foreground">{requests.length} total requests</p>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {filterTabs.map(({ key, label, count }) => (
          <button
            key={key}
            onClick={() => setStatusFilter(key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${statusFilter === key ? "border-primary bg-primary/5 text-primary" : "border-border bg-card hover:bg-muted/30 text-muted-foreground"}`}
            data-testid={`filter-${key}`}
          >
            {label} <span className="ml-1 font-bold">{count}</span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by patient, hospital, city, blood group, contact..."
          className="pl-9"
          data-testid="input-search-requests"
        />
      </div>

      {/* Request cards */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-36 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Droplets className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No requests found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(req => {
            const r = req as any;
            const isEmergency = req.urgency === "emergency";
            const isUrgent = req.urgency === "urgent";
            return (
              <Card
                key={req.id}
                data-testid={`request-card-${req.id}`}
                className={`overflow-hidden ${isEmergency ? "border-red-300 dark:border-red-700" : isUrgent ? "border-orange-200 dark:border-orange-800" : ""}`}
              >
                {isEmergency && (
                  <div className={`text-white px-3 py-1 flex items-center gap-1.5 text-xs font-semibold ${r.requestType === "emergency_alert" ? "bg-red-700" : "bg-red-600"}`}>
                    <AlertTriangle className="w-3 h-3" />
                    {r.requestType === "emergency_alert" ? "🚨 EMERGENCY BLOOD ALERT — 50 DONORS NOTIFIED" : "EMERGENCY REQUEST"}
                  </div>
                )}
                {isUrgent && !isEmergency && (
                  <div className="bg-orange-500 text-white px-3 py-1 flex items-center gap-1.5 text-xs font-semibold">
                    <AlertTriangle className="w-3 h-3" /> URGENT
                  </div>
                )}
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      {/* Header row */}
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-semibold text-sm" data-testid={`text-patient-${req.id}`}>{req.patientName}</p>
                            <BloodGroupBadge group={req.bloodGroup} size="sm" />
                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${urgencyColor(req.urgency || "normal")}`}>
                              {(req.urgency || "normal").toUpperCase()}
                            </span>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${statusColor(req.status || "pending")}`} data-testid={`status-request-${req.id}`}>
                              {statusLabel(req.status || "pending")}
                            </span>
                            {r.requestType === "user_to_admin" && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 flex items-center gap-0.5">
                                <Shield className="w-2.5 h-2.5" /> Admin Review
                              </span>
                            )}
                            {r.requestType === "emergency_alert" && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 flex items-center gap-0.5">
                                🚨 Emergency Alert
                              </span>
                            )}
                            {(r.requestType === "user_to_donor" || !r.requestType) && r.requestType !== "emergency_alert" && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 flex items-center gap-0.5">
                                <Users className="w-2.5 h-2.5" /> Donor Network
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-muted-foreground mt-0.5">{timeSince(req.createdAt!)}</p>
                        </div>
                      </div>

                      {/* Details grid */}
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground mb-3">
                        <div className="flex items-center gap-1.5">
                          <Hospital className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">{req.hospital}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">
                            {req.city}{r.district ? `, ${r.district}` : ""}{req.state ? `, ${req.state}` : ""}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3 h-3 flex-shrink-0" />
                          <span>{req.unitsNeeded} unit{req.unitsNeeded > 1 ? "s" : ""}</span>
                        </div>
                        {r.requiredByDate && (
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3 h-3 flex-shrink-0 text-orange-500" />
                            <span>{new Date(r.requiredByDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1.5">
                          <User className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">{r.contactName || "—"}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3 h-3 flex-shrink-0" />
                          <span>{req.contactPhone}</span>
                        </div>
                      </div>

                      {/* Donor info if assigned */}
                      {req.donorId && (() => {
                        const donor = getUserById(req.donorId);
                        return (
                          <div className="flex items-center gap-2 text-xs bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-lg px-2.5 py-1.5 mb-2">
                            <UserCheck className="w-3.5 h-3.5 text-blue-600 flex-shrink-0" />
                            {donor ? (
                              <span className="text-blue-700 dark:text-blue-300">
                                <strong>Donor:</strong> {donor.fullName}
                                {donor.phone && (
                                  <> · <a href={`tel:${donor.phone}`} className="underline">{donor.phone}</a></>
                                )}
                                {donor.bloodGroup && <> · {donor.bloodGroup}</>}
                              </span>
                            ) : (
                              <span className="text-blue-600 dark:text-blue-400">Donor assigned (ID: {req.donorId.slice(0, 8)}…)</span>
                            )}
                          </div>
                        );
                      })()}

                      {req.notes && (
                        <p className="text-xs italic text-muted-foreground bg-muted rounded px-2 py-1 mb-3 truncate">
                          "{req.notes}"
                        </p>
                      )}

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {req.status === "pending" && (
                          <Button
                            size="sm"
                            className="h-7 px-2.5 text-xs bg-green-600 hover:bg-green-700 text-white"
                            onClick={() => quickStatusMutation.mutate({ id: req.id, status: "accepted" })}
                            disabled={quickStatusMutation.isPending}
                            data-testid={`button-accept-${req.id}`}
                          >
                            <ThumbsUp className="w-3 h-3 mr-1" /> Accept
                          </Button>
                        )}
                        {["pending", "accepted", "approved", "donor_found"].includes(req.status || "") && (
                          <Button
                            size="sm"
                            className="h-7 px-2.5 text-xs bg-blue-600 hover:bg-blue-700 text-white"
                            onClick={() => quickStatusMutation.mutate({ id: req.id, status: "fulfilled" })}
                            disabled={quickStatusMutation.isPending}
                            data-testid={`button-complete-${req.id}`}
                          >
                            <CheckCircle className="w-3 h-3 mr-1" /> Complete
                          </Button>
                        )}
                        {req.status === "pending" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs text-red-600 border-red-200 hover:bg-red-50"
                            onClick={() => quickStatusMutation.mutate({ id: req.id, status: "rejected" })}
                            disabled={quickStatusMutation.isPending}
                            data-testid={`button-reject-${req.id}`}
                          >
                            <XCircle className="w-3 h-3 mr-1" /> Reject
                          </Button>
                        )}
                        {r.requisitionForm && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2.5 text-xs text-blue-600 border-blue-200 hover:bg-blue-50"
                            onClick={() => setViewFileReq(req)}
                            data-testid={`button-view-file-${req.id}`}
                          >
                            {r.requisitionFormType === "pdf" ? <FileText className="w-3 h-3 mr-1" /> : <ImageIcon className="w-3 h-3 mr-1" />}
                            View Form
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 w-7 p-0 text-blue-600 border-blue-200 hover:bg-blue-50"
                          onClick={() => openEdit(req)}
                          data-testid={`button-edit-request-${req.id}`}
                          title="Edit"
                        >
                          <Pencil className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 w-7 p-0 text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => setDeleteReq(req)}
                          data-testid={`button-delete-request-${req.id}`}
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* View Requisition Form Dialog */}
      <Dialog open={!!viewFileReq} onOpenChange={open => !open && setViewFileReq(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {(viewFileReq as any)?.requisitionFormType === "pdf" ? (
                <FileText className="w-5 h-5 text-red-600" />
              ) : (
                <ImageIcon className="w-5 h-5 text-blue-600" />
              )}
              Hospital Requisition Form
            </DialogTitle>
            <DialogDescription>
              Submitted by {viewFileReq?.patientName} for {viewFileReq?.bloodGroup} blood at {viewFileReq?.hospital}
            </DialogDescription>
          </DialogHeader>
          {viewFileReq && (viewFileReq as any).requisitionFormType === "image" ? (
            <img
              src={(viewFileReq as any).requisitionForm}
              alt="Requisition form"
              className="w-full rounded-lg border"
            />
          ) : viewFileReq && (viewFileReq as any).requisitionFormType === "pdf" ? (
            <div className="text-center py-8">
              <FileText className="w-16 h-16 mx-auto mb-3 text-red-600" />
              <p className="font-semibold mb-2">PDF Document</p>
              <a
                href={(viewFileReq as any).requisitionForm}
                download={`requisition-${viewFileReq.id}.pdf`}
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700 transition-colors"
              >
                <FileText className="w-4 h-4" /> Download PDF
              </a>
            </div>
          ) : null}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewFileReq(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Request Dialog */}
      <Dialog open={!!editReq} onOpenChange={open => !open && setEditReq(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Blood Request</DialogTitle>
            <DialogDescription>
              Update the details of this blood request.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(data => editMutation.mutate(data))} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="patientName"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Patient Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Patient full name" data-testid="input-edit-patient-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="bloodGroup"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blood Group</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-blood-group">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {BLOOD_GROUPS.map(bg => <SelectItem key={bg} value={bg}>{bg}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="unitsNeeded"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Units Needed</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min={1} max={20} data-testid="input-edit-units" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="hospital"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Hospital</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Hospital name" data-testid="input-edit-hospital" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City / Block</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="City" data-testid="input-edit-city" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="district"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>District</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="District" data-testid="input-edit-district" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="State" data-testid="input-edit-state" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="contactName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Person</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Contact name" data-testid="input-edit-contact-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Phone</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="+91 XXXXX XXXXX" data-testid="input-edit-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="urgency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Urgency</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-urgency">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {URGENCY_LEVELS.map(u => (
                            <SelectItem key={u} value={u}>{u.charAt(0).toUpperCase() + u.slice(1)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Status</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {STATUS_OPTIONS.map(s => (
                            <SelectItem key={s} value={s}>{statusLabel(s)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="requestType"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Request Type</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-request-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="user_to_donor">Send to Donors</SelectItem>
                          <SelectItem value="user_to_admin">Admin Review</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Notes (optional)</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Additional notes..." rows={2} data-testid="textarea-edit-notes" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setEditReq(null)}>Cancel</Button>
                <Button type="submit" disabled={editMutation.isPending} data-testid="button-save-request">
                  {editMutation.isPending ? "Saving…" : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteReq} onOpenChange={open => !open && setDeleteReq(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" /> Delete Request
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the blood request for <strong>{deleteReq?.patientName}</strong>?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteReq(null)} data-testid="button-cancel-delete">
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteReq && deleteMutation.mutate(deleteReq.id)}
              disabled={deleteMutation.isPending}
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete Request"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
