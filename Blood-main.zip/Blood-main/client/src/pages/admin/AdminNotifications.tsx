import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Bell, Send, Globe, CheckCircle } from "lucide-react";

export default function AdminNotifications() {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  const broadcastMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/notifications/broadcast", { title, message });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Notification broadcast sent to all users!" });
      setSent(true);
      setTimeout(() => {
        setSent(false);
        setTitle("");
        setMessage("");
      }, 3000);
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const handleSend = () => {
    if (!title || !message) return toast({ title: "Please fill all fields", variant: "destructive" });
    broadcastMutation.mutate();
  };

  const templates = [
    { title: "Blood Camp Reminder", message: "Don't forget! A blood donation camp is scheduled in your area. Your donation saves lives." },
    { title: "Emergency Blood Need", message: "URGENT: Emergency blood needed in your city. Please check the app for blood requests near you." },
    { title: "Thank You!", message: "Thank you to all our donors for saving lives. Every drop counts. Keep donating!" },
    { title: "New Feature Update", message: "We've added new features to the LifeFlow app. Update now to get the best experience." },
  ];

  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-2xl font-black">Push Notifications</h1>
        <p className="text-sm text-muted-foreground">Broadcast notifications to all users</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Compose */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Bell className="w-4 h-4 text-primary" /> Compose Notification
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Notification Title</Label>
              <Input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Emergency Blood Need"
                className="mt-1"
                data-testid="input-notif-title"
              />
            </div>
            <div>
              <Label>Message</Label>
              <Textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Write your notification message..."
                className="mt-1 resize-none"
                rows={4}
                data-testid="textarea-notif-message"
              />
              <p className="text-xs text-muted-foreground mt-1">{message.length}/500 characters</p>
            </div>

            <div className="flex items-center gap-2 p-3 bg-muted rounded-md">
              <Globe className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-xs font-medium">Global Broadcast</p>
                <p className="text-xs text-muted-foreground">Will be sent to all registered users</p>
              </div>
            </div>

            {sent ? (
              <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-md">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <p className="text-sm text-green-700 dark:text-green-300 font-medium">Notification sent successfully!</p>
              </div>
            ) : (
              <Button onClick={handleSend} disabled={broadcastMutation.isPending} className="w-full" data-testid="button-send-notification">
                <Send className="w-4 h-4 mr-2" />
                {broadcastMutation.isPending ? "Sending..." : "Send to All Users"}
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Templates */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Quick Templates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {templates.map(t => (
                <button
                  key={t.title}
                  onClick={() => { setTitle(t.title); setMessage(t.message); }}
                  className="w-full text-left p-3 rounded-lg border border-border hover-elevate transition-colors"
                  data-testid={`template-${t.title.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <p className="font-medium text-sm">{t.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{t.message}</p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
