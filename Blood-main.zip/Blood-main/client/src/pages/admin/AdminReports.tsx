import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, Users, Droplets, Heart, Award, Activity, Target } from "lucide-react";
import type { BloodRequest, Donation, User } from "@shared/schema";

interface Stats {
  totalUsers: number;
  totalDonations: number;
  totalRequests: number;
  pendingRequests: number;
  totalCamps: number;
  bloodGroupStats: Record<string, number>;
}

const BG_COLORS = ["#dc2626", "#ea580c", "#7c3aed", "#0284c7", "#16a34a", "#ca8a04", "#db2777", "#0891b2"];

export default function AdminReports() {
  const { data: stats, isLoading } = useQuery<Stats>({ queryKey: ["/api/admin/stats"] });
  const { data: donations = [] } = useQuery<Donation[]>({ queryKey: ["/api/donations/all"] });
  const { data: requests = [] } = useQuery<BloodRequest[]>({ queryKey: ["/api/requests/all"] });
  const { data: users = [] } = useQuery<Omit<User, "password">[]>({ queryKey: ["/api/users"] });

  const bloodGroupData = stats?.bloodGroupStats
    ? Object.entries(stats.bloodGroupStats).map(([name, value]) => ({ name, value }))
    : [];

  // User registration by month (simulated from createdAt)
  const usersByMonth: Record<string, number> = {};
  users.forEach(u => {
    if (u.createdAt) {
      const month = new Date(u.createdAt).toLocaleString("default", { month: "short" });
      usersByMonth[month] = (usersByMonth[month] || 0) + 1;
    }
  });
  const userMonthData = Object.entries(usersByMonth).map(([month, count]) => ({ month, count }));

  // Donation fulfillment rate
  const fulfilled = requests.filter(r => r.status === "fulfilled").length;
  const fulfillmentRate = requests.length > 0 ? Math.round((fulfilled / requests.length) * 100) : 0;

  const topDonors = [...users]
    .sort((a, b) => (b.totalDonations || 0) - (a.totalDonations || 0))
    .slice(0, 5);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-black">Analytics & Reports</h1>
        <p className="text-sm text-muted-foreground">Platform performance and statistics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Users, label: "Total Users", value: stats?.totalUsers || 0, sub: "Registered", color: "text-blue-600", bg: "bg-blue-100 dark:bg-blue-900/30" },
          { icon: Heart, label: "Donations", value: stats?.totalDonations || 0, sub: "Total units", color: "text-pink-600", bg: "bg-pink-100 dark:bg-pink-900/30" },
          { icon: Droplets, label: "Requests", value: stats?.totalRequests || 0, sub: "Submitted", color: "text-red-600", bg: "bg-red-100 dark:bg-red-900/30" },
          { icon: Target, label: "Fulfillment", value: `${fulfillmentRate}%`, sub: "Success rate", color: "text-green-600", bg: "bg-green-100 dark:bg-green-900/30" },
        ].map(({ icon: Icon, label, value, sub, color, bg }) => (
          <Card key={label}>
            <CardContent className="p-4">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center mb-2`}>
                <Icon className={`w-4.5 h-4.5 ${color}`} />
              </div>
              {isLoading ? <Skeleton className="h-7 w-16 mb-1" /> : (
                <p className="text-2xl font-black">{value}</p>
              )}
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-[10px] text-muted-foreground">{sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Droplets className="w-4 h-4 text-primary" /> Donations by Blood Group
            </CardTitle>
          </CardHeader>
          <CardContent>
            {bloodGroupData.length === 0 ? (
              <div className="flex items-center justify-center h-40 text-muted-foreground">
                <div className="text-center">
                  <Droplets className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-xs">No donation data yet</p>
                </div>
              </div>
            ) : (
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bloodGroupData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "6px", fontSize: "12px" }} />
                    <Bar dataKey="value" radius={[3, 3, 0, 0]}>
                      {bloodGroupData.map((_, i) => <Cell key={i} fill={BG_COLORS[i % BG_COLORS.length]} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" /> New Users by Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            {userMonthData.length === 0 ? (
              <div className="flex items-center justify-center h-40 text-muted-foreground">
                <div className="text-center">
                  <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-xs">No user data yet</p>
                </div>
              </div>
            ) : (
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={userMonthData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "6px", fontSize: "12px" }} />
                    <Line type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Top Donors */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Award className="w-4 h-4 text-yellow-500" /> Top Donors
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topDonors.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Heart className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-xs">No donors yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {topDonors.map((donor, i) => {
                const initials = donor.fullName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
                return (
                  <div key={donor.id} className="flex items-center gap-3" data-testid={`top-donor-${donor.id}`}>
                    <span className={`text-sm font-black w-5 text-center ${i === 0 ? "text-yellow-500" : i === 1 ? "text-gray-400" : i === 2 ? "text-amber-700" : "text-muted-foreground"}`}>
                      {i + 1}
                    </span>
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold flex-shrink-0">
                      {initials}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{donor.fullName}</p>
                      <p className="text-xs text-muted-foreground">{donor.city || "Unknown location"}</p>
                    </div>
                    <BloodGroupBadge group={donor.bloodGroup} size="sm" />
                    <div className="text-right">
                      <p className="font-bold text-sm">{donor.totalDonations || 0}</p>
                      <p className="text-xs text-muted-foreground">donations</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
