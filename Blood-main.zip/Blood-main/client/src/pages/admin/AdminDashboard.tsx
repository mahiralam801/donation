import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getStoredAdmin } from "@/lib/auth";
import {
  Users, Droplets, Heart, Calendar, TrendingUp, Activity, Award,
  AlertCircle
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from "recharts";

interface Stats {
  totalUsers: number;
  totalDonations: number;
  totalRequests: number;
  pendingRequests: number;
  totalCamps: number;
  bloodGroupStats: Record<string, number>;
}

const BG_COLORS = ["#dc2626", "#ea580c", "#7c3aed", "#0284c7", "#16a34a", "#ca8a04", "#db2777", "#0891b2"];

export default function AdminDashboard() {
  const admin = getStoredAdmin();

  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["/api/admin/stats"],
  });

  const bloodGroupData = stats?.bloodGroupStats
    ? Object.entries(stats.bloodGroupStats).map(([name, value]) => ({ name, value }))
    : [];

  const statCards = [
    { icon: Users, label: "Total Users", value: stats?.totalUsers || 0, color: "text-blue-600", bg: "bg-blue-100 dark:bg-blue-900/30" },
    { icon: Heart, label: "Total Donations", value: stats?.totalDonations || 0, color: "text-pink-600", bg: "bg-pink-100 dark:bg-pink-900/30" },
    { icon: Droplets, label: "Blood Requests", value: stats?.totalRequests || 0, color: "text-red-600", bg: "bg-red-100 dark:bg-red-900/30" },
    { icon: AlertCircle, label: "Pending Requests", value: stats?.pendingRequests || 0, color: "text-orange-600", bg: "bg-orange-100 dark:bg-orange-900/30" },
    { icon: Calendar, label: "Blood Camps", value: stats?.totalCamps || 0, color: "text-green-600", bg: "bg-green-100 dark:bg-green-900/30" },
    { icon: Activity, label: "Active Today", value: Math.floor((stats?.totalDonations || 0) * 0.1), color: "text-purple-600", bg: "bg-purple-100 dark:bg-purple-900/30" },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-2xl font-black">Dashboard</h1>
        <p className="text-muted-foreground text-sm">Welcome back, {admin?.fullName}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map(({ icon: Icon, label, value, color, bg }) => (
          <Card key={label} data-testid={`stat-card-${label.toLowerCase().replace(/\s/g, "-")}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}>
                  <Icon className={`w-4.5 h-4.5 ${color}`} />
                </div>
              </div>
              {isLoading ? (
                <Skeleton className="h-7 w-16 mb-1" />
              ) : (
                <p className="text-2xl font-black">{value.toLocaleString()}</p>
              )}
              <p className="text-xs text-muted-foreground">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Blood Group Distribution */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Droplets className="w-4 h-4 text-primary" /> Donations by Blood Group
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading || bloodGroupData.length === 0 ? (
              <div className="flex items-center justify-center h-48 text-muted-foreground">
                <div className="text-center">
                  {isLoading ? <Skeleton className="h-48 w-full" /> : (
                    <>
                      <Droplets className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      <p className="text-xs">No donation data yet</p>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bloodGroupData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{
                        background: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                        fontSize: "12px",
                      }}
                    />
                    <Bar dataKey="value" fill="hsl(var(--primary))" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pie chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" /> Blood Group Spread
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading || bloodGroupData.length === 0 ? (
              <div className="flex items-center justify-center h-48 text-muted-foreground">
                {isLoading ? <Skeleton className="h-48 w-full" /> : (
                  <div className="text-center">
                    <Activity className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-xs">No data yet</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-48 flex items-center gap-4">
                <ResponsiveContainer width="60%" height="100%">
                  <PieChart>
                    <Pie data={bloodGroupData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={2} dataKey="value">
                      {bloodGroupData.map((_, i) => (
                        <Cell key={i} fill={BG_COLORS[i % BG_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                        fontSize: "12px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1.5">
                  {bloodGroupData.map((item, i) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: BG_COLORS[i % BG_COLORS.length] }} />
                      <span className="text-xs">{item.name}: <strong>{item.value}</strong></span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
