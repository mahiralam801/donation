import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { COUNTRIES } from "@/lib/countries";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { MapPin, Plus, Pencil, Trash2, Globe, Map, Building2, Home } from "lucide-react";
import type { Location } from "@shared/schema";

const EMPTY_FORM = { country: "", state: "", city: "", address: "", isActive: true };

export default function AdminLocations() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [filterCountry, setFilterCountry] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [editLoc, setEditLoc] = useState<Location | null>(null);
  const [deleteLoc, setDeleteLoc] = useState<Location | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);

  const { data: locations = [], isLoading } = useQuery<Location[]>({
    queryKey: ["/api/admin/locations"],
  });

  const addMutation = useMutation({
    mutationFn: async (data: typeof EMPTY_FORM) => {
      const res = await apiRequest("POST", "/api/admin/locations", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/locations"] });
      toast({ title: "Location added" });
      setAddOpen(false);
      setForm(EMPTY_FORM);
    },
    onError: (e: any) => toast({ title: e.message, variant: "destructive" }),
  });

  const editMutation = useMutation({
    mutationFn: async (data: typeof EMPTY_FORM & { id: number }) => {
      const { id, ...rest } = data;
      const res = await apiRequest("PUT", `/api/admin/locations/${id}`, rest);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/locations"] });
      toast({ title: "Location updated" });
      setEditLoc(null);
    },
    onError: (e: any) => toast({ title: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/locations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/locations"] });
      toast({ title: "Location deleted" });
      setDeleteLoc(null);
    },
    onError: (e: any) => toast({ title: e.message, variant: "destructive" }),
  });

  const openEdit = (loc: Location) => {
    setEditLoc(loc);
    setForm({
      country: loc.country,
      state: loc.state || "",
      city: loc.city || "",
      address: loc.address || "",
      isActive: loc.isActive ?? true,
    });
  };

  const countries = [...new Set(locations.map(l => l.country))].sort();

  const filtered = locations.filter(l => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      l.country.toLowerCase().includes(q) ||
      (l.state || "").toLowerCase().includes(q) ||
      (l.city || "").toLowerCase().includes(q) ||
      (l.address || "").toLowerCase().includes(q);
    const matchCountry = filterCountry === "all" || l.country === filterCountry;
    return matchSearch && matchCountry;
  });

  const totalActive = locations.filter(l => l.isActive).length;
  const uniqueCountries = new Set(locations.map(l => l.country)).size;
  const uniqueCities = new Set(locations.filter(l => l.city).map(l => l.city)).size;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black">Locations</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {locations.length} location{locations.length !== 1 ? "s" : ""} registered
          </p>
        </div>
        <Button onClick={() => { setForm(EMPTY_FORM); setAddOpen(true); }} data-testid="button-add-location">
          <Plus className="w-4 h-4 mr-1.5" /> Add Location
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total", value: locations.length, icon: MapPin, color: "text-blue-600" },
          { label: "Active", value: totalActive, icon: MapPin, color: "text-green-600" },
          { label: "Countries", value: uniqueCountries, icon: Globe, color: "text-purple-600" },
          { label: "Cities", value: uniqueCities, icon: Building2, color: "text-orange-600" },
        ].map(s => (
          <div key={s.label} className="bg-card border rounded-xl p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg bg-muted flex items-center justify-center ${s.color}`}>
              <s.icon className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-xl font-black">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Input
          placeholder="Search by country, state, city..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="max-w-xs"
          data-testid="input-location-search"
        />
        <select
          value={filterCountry}
          onChange={e => setFilterCountry(e.target.value)}
          className="border rounded-md px-3 py-2 text-sm bg-background"
          data-testid="select-filter-country"
        >
          <option value="all">All Countries</option>
          {countries.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-card border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/40">
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Country</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">State / Region</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">City</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Address</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Status</th>
                <th className="text-right px-4 py-3 font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Loading...</td></tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12">
                    <MapPin className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
                    <p className="text-muted-foreground text-sm">No locations found</p>
                  </td>
                </tr>
              ) : filtered.map((loc) => (
                <tr key={loc.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors" data-testid={`row-location-${loc.id}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Globe className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="font-medium">{loc.country}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {loc.state ? (
                      <div className="flex items-center gap-2">
                        <Map className="w-3.5 h-3.5 text-muted-foreground" />
                        <span>{loc.state}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground/50 text-xs">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {loc.city ? (
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-muted-foreground" />
                        <span>{loc.city}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground/50 text-xs">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 max-w-[200px]">
                    {loc.address ? (
                      <div className="flex items-start gap-2">
                        <Home className="w-3.5 h-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <span className="truncate text-xs text-muted-foreground">{loc.address}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground/50 text-xs">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <Badge
                      variant={loc.isActive ? "default" : "secondary"}
                      className={loc.isActive ? "bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300" : ""}
                      data-testid={`status-location-${loc.id}`}
                    >
                      {loc.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-blue-600"
                        onClick={() => openEdit(loc)}
                        data-testid={`button-edit-location-${loc.id}`}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-red-500"
                        onClick={() => setDeleteLoc(loc)}
                        data-testid={`button-delete-location-${loc.id}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Location</DialogTitle>
          </DialogHeader>
          <LocationForm form={form} setForm={setForm} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button
              onClick={() => addMutation.mutate(form)}
              disabled={addMutation.isPending || !form.country.trim()}
              data-testid="button-save-add-location"
            >
              {addMutation.isPending ? "Adding..." : "Add Location"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editLoc} onOpenChange={v => !v && setEditLoc(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Location</DialogTitle>
          </DialogHeader>
          <LocationForm form={form} setForm={setForm} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditLoc(null)}>Cancel</Button>
            <Button
              onClick={() => editLoc && editMutation.mutate({ id: editLoc.id, ...form })}
              disabled={editMutation.isPending || !form.country.trim()}
              data-testid="button-save-edit-location"
            >
              {editMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteLoc} onOpenChange={v => !v && setDeleteLoc(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Location?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove <strong>{deleteLoc?.country}{deleteLoc?.state ? `, ${deleteLoc.state}` : ""}{deleteLoc?.city ? `, ${deleteLoc.city}` : ""}</strong>. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={() => deleteLoc && deleteMutation.mutate(deleteLoc.id)}
              data-testid="button-confirm-delete-location"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function LocationForm({
  form,
  setForm,
}: {
  form: { country: string; state: string; city: string; address: string; isActive: boolean };
  setForm: (f: any) => void;
}) {
  const upd = (k: string, v: any) => setForm((prev: any) => ({ ...prev, [k]: v }));
  return (
    <div className="space-y-4 py-1">
      <div className="space-y-1.5">
        <Label>Country <span className="text-red-500">*</span></Label>
        <select
          value={form.country}
          onChange={e => upd("country", e.target.value)}
          data-testid="input-loc-country"
          className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="">Select a country...</option>
          {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>State / Region</Label>
          <Input
            value={form.state}
            onChange={e => upd("state", e.target.value)}
            placeholder="e.g. West Bengal"
            data-testid="input-loc-state"
          />
        </div>
        <div className="space-y-1.5">
          <Label>City</Label>
          <Input
            value={form.city}
            onChange={e => upd("city", e.target.value)}
            placeholder="e.g. Kolkata"
            data-testid="input-loc-city"
          />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Address</Label>
        <Input
          value={form.address}
          onChange={e => upd("address", e.target.value)}
          placeholder="Full street address (optional)"
          data-testid="input-loc-address"
        />
      </div>
      <div className="flex items-center gap-3">
        <Switch
          checked={form.isActive}
          onCheckedChange={v => upd("isActive", v)}
          id="loc-active"
          data-testid="switch-loc-active"
        />
        <Label htmlFor="loc-active" className="cursor-pointer">Active</Label>
      </div>
    </div>
  );
}
