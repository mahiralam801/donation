import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Droplets, Plus, Pencil, Trash2, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import type { BloodGroup } from "@shared/schema";

const COLOR_OPTIONS = [
  { value: "bg-red-500", label: "Red", preview: "bg-red-500" },
  { value: "bg-red-600", label: "Dark Red", preview: "bg-red-600" },
  { value: "bg-orange-500", label: "Orange", preview: "bg-orange-500" },
  { value: "bg-orange-600", label: "Dark Orange", preview: "bg-orange-600" },
  { value: "bg-purple-500", label: "Purple", preview: "bg-purple-500" },
  { value: "bg-purple-600", label: "Dark Purple", preview: "bg-purple-600" },
  { value: "bg-green-500", label: "Green", preview: "bg-green-500" },
  { value: "bg-green-600", label: "Dark Green", preview: "bg-green-600" },
  { value: "bg-blue-500", label: "Blue", preview: "bg-blue-500" },
  { value: "bg-pink-500", label: "Pink", preview: "bg-pink-500" },
];

const groupSchema = z.object({
  name: z.string().min(1, "Name is required").max(10, "Max 10 characters"),
  description: z.string().optional(),
  color: z.string().min(1, "Color is required"),
  isRare: z.boolean(),
  isActive: z.boolean(),
});
type GroupFormValues = z.infer<typeof groupSchema>;

export default function AdminBloodGroups() {
  const { toast } = useToast();
  const [editGroup, setEditGroup] = useState<BloodGroup | null>(null);
  const [deleteGroup, setDeleteGroup] = useState<BloodGroup | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  const { data: groups = [], isLoading } = useQuery<BloodGroup[]>({
    queryKey: ["/api/blood-groups"],
  });

  const defaultValues: GroupFormValues = {
    name: "", description: "", color: "bg-red-500", isRare: false, isActive: true,
  };

  const form = useForm<GroupFormValues>({
    resolver: zodResolver(groupSchema),
    defaultValues,
  });

  const openAdd = () => {
    form.reset(defaultValues);
    setAddOpen(true);
  };

  const openEdit = (group: BloodGroup) => {
    setEditGroup(group);
    form.reset({
      name: group.name,
      description: group.description || "",
      color: group.color || "bg-red-500",
      isRare: group.isRare ?? false,
      isActive: group.isActive ?? true,
    });
  };

  const addMutation = useMutation({
    mutationFn: async (data: GroupFormValues) => {
      const res = await apiRequest("POST", "/api/admin/blood-groups", data);
      if (!res.ok) { const e = await res.json(); throw new Error(e.message); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-groups"] });
      toast({ title: "Blood group added" });
      setAddOpen(false);
      form.reset(defaultValues);
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const editMutation = useMutation({
    mutationFn: async (data: GroupFormValues) => {
      const res = await apiRequest("PUT", `/api/admin/blood-groups/${editGroup!.id}`, data);
      if (!res.ok) { const e = await res.json(); throw new Error(e.message); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-groups"] });
      toast({ title: "Blood group updated" });
      setEditGroup(null);
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/blood-groups/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-groups"] });
      toast({ title: "Blood group deleted" });
      setDeleteGroup(null);
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const isDialogOpen = addOpen || !!editGroup;
  const isAdd = addOpen && !editGroup;

  const GroupForm = () => (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(data => isAdd ? addMutation.mutate(data) : editMutation.mutate(data))}
        className="space-y-4"
      >
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Blood Group Name</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="e.g. A+, O-, AB+" data-testid="input-group-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="color"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Badge Color</FormLabel>
                <Select value={field.value} onValueChange={field.onChange}>
                  <FormControl>
                    <SelectTrigger data-testid="select-group-color">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${field.value}`} />
                        <SelectValue />
                      </div>
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {COLOR_OPTIONS.map(c => (
                      <SelectItem key={c.value} value={c.value}>
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${c.preview}`} />
                          {c.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem className="col-span-2">
                <FormLabel>Description (optional)</FormLabel>
                <FormControl>
                  <Textarea {...field} placeholder="Describe this blood group..." rows={2} data-testid="textarea-group-desc" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isRare"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Rarity</FormLabel>
                <Select value={field.value ? "rare" : "common"} onValueChange={v => field.onChange(v === "rare")}>
                  <FormControl>
                    <SelectTrigger data-testid="select-group-rare">
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="common">Common</SelectItem>
                    <SelectItem value="rare">Rare</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select value={field.value ? "active" : "inactive"} onValueChange={v => field.onChange(v === "active")}>
                  <FormControl>
                    <SelectTrigger data-testid="select-group-status">
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => isAdd ? setAddOpen(false) : setEditGroup(null)}>
            Cancel
          </Button>
          <Button type="submit" disabled={addMutation.isPending || editMutation.isPending} data-testid="button-save-group">
            {(addMutation.isPending || editMutation.isPending) ? "Saving…" : isAdd ? "Add Group" : "Save Changes"}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black">Blood Groups</h1>
          <p className="text-sm text-muted-foreground">{groups.length} blood groups registered</p>
        </div>
        <Button onClick={openAdd} className="flex items-center gap-2" data-testid="button-add-group">
          <Plus className="w-4 h-4" /> Add Blood Group
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total", value: groups.length, color: "text-primary" },
          { label: "Active", value: groups.filter(g => g.isActive).length, color: "text-green-600" },
          { label: "Rare Types", value: groups.filter(g => g.isRare).length, color: "text-orange-500" },
        ].map(({ label, value, color }) => (
          <Card key={label}>
            <CardContent className="p-3 text-center">
              <p className={`text-2xl font-black ${color}`}>{value}</p>
              <p className="text-xs text-muted-foreground">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : groups.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Droplets className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No blood groups added yet</p>
              <Button variant="outline" size="sm" className="mt-3" onClick={openAdd}>
                Add First Group
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    <th className="text-left p-3 text-xs font-semibold text-muted-foreground">Blood Group</th>
                    <th className="text-left p-3 text-xs font-semibold text-muted-foreground">Description</th>
                    <th className="text-left p-3 text-xs font-semibold text-muted-foreground">Rarity</th>
                    <th className="text-left p-3 text-xs font-semibold text-muted-foreground">Status</th>
                    <th className="text-left p-3 text-xs font-semibold text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {groups.map(group => (
                    <tr key={group.id} className="hover:bg-muted/20 transition-colors" data-testid={`group-row-${group.id}`}>
                      <td className="p-3">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-9 h-9 rounded-lg ${group.color || "bg-red-500"} flex items-center justify-center shadow-sm`}>
                            <span className="text-white text-xs font-black">{group.name}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-3">
                        <p className="text-xs text-muted-foreground max-w-xs truncate">{group.description || "—"}</p>
                      </td>
                      <td className="p-3">
                        {group.isRare ? (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300 font-medium">
                            Rare
                          </span>
                        ) : (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 font-medium">
                            Common
                          </span>
                        )}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1">
                          {group.isActive ? (
                            <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                          ) : (
                            <XCircle className="w-3.5 h-3.5 text-red-400" />
                          )}
                          <span className={`text-xs font-medium ${group.isActive ? "text-green-600" : "text-red-500"}`}>
                            {group.isActive ? "Active" : "Inactive"}
                          </span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 w-7 p-0 text-blue-600 border-blue-200 hover:bg-blue-50"
                            onClick={() => openEdit(group)}
                            title="Edit blood group"
                            data-testid={`button-edit-group-${group.id}`}
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 w-7 p-0 text-red-600 border-red-200 hover:bg-red-50"
                            onClick={() => setDeleteGroup(group)}
                            title="Delete blood group"
                            data-testid={`button-delete-group-${group.id}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Dialog */}
      <Dialog open={addOpen} onOpenChange={open => { if (!open) setAddOpen(false); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Droplets className="w-5 h-5 text-primary" /> Add Blood Group
            </DialogTitle>
            <DialogDescription>
              Register a new blood group type in the system.
            </DialogDescription>
          </DialogHeader>
          <GroupForm />
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editGroup} onOpenChange={open => { if (!open) setEditGroup(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-4 h-4" /> Edit Blood Group — {editGroup?.name}
            </DialogTitle>
            <DialogDescription>
              Update the details for this blood group type.
            </DialogDescription>
          </DialogHeader>
          <GroupForm />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={!!deleteGroup} onOpenChange={open => { if (!open) setDeleteGroup(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" /> Delete Blood Group
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete blood group <strong>{deleteGroup?.name}</strong>?
              This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteGroup(null)} data-testid="button-cancel-delete">
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteGroup && deleteMutation.mutate(deleteGroup.id)}
              disabled={deleteMutation.isPending}
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
