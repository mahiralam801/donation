import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { setToken, setStoredAdmin } from "@/lib/auth";
import { Shield, Droplets } from "lucide-react";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/admin/auth/login", { username, password });
      const data = await res.json();
      setToken(data.token);
      setStoredAdmin(data.admin);
      setLocation("/admin/dashboard");
    } catch (e: any) {
      toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-red-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary mb-4">
            <Droplets className="w-9 h-9 text-white" />
          </div>
          <h1 className="text-2xl font-black text-white">LifeFlow Admin</h1>
          <p className="text-gray-400 text-sm mt-1">Blood Donation Management</p>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="w-4 h-4 text-primary" /> Admin Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label>Username</Label>
                <Input value={username} onChange={e => setUsername(e.target.value)} placeholder="admin" className="mt-1" data-testid="input-admin-login-username" />
              </div>
              <div>
                <Label>Password</Label>
                <Input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="mt-1" data-testid="input-admin-login-password" />
              </div>
              <Button type="submit" className="w-full" disabled={loading} data-testid="button-admin-login-submit">
                {loading ? "Signing In..." : "Sign In to Admin"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
