import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Save, Eye, ExternalLink, FileText, Info, Phone, Shield, FileCheck, AlertTriangle } from "lucide-react";

const PAGE_TYPES = [
  { type: "about_us", label: "About Us", icon: Info, slug: "about", description: "Tell users about your organization and mission" },
  { type: "contact_us", label: "Contact Us", icon: Phone, slug: "contact", description: "Provide contact information for users to reach you" },
  { type: "privacy_policy", label: "Privacy Policy", icon: Shield, slug: "privacy", description: "Explain how user data is collected and used" },
  { type: "terms_of_use", label: "Terms of Use", icon: FileCheck, slug: "terms", description: "Define the rules and conditions for using the platform" },
  { type: "disclaimer", label: "Disclaimer", icon: AlertTriangle, slug: "disclaimer", description: "Limit liability and clarify the scope of the service" },
];

const DEFAULT_CONTENT: Record<string, { title: string; content: string }> = {
  about_us: {
    title: "About Us",
    content: `<h2>Welcome to LifeFlow</h2>
<p>LifeFlow is a blood donation platform dedicated to connecting donors with recipients in need. Our mission is to make blood donation simple, accessible, and impactful.</p>
<h3>Our Mission</h3>
<p>We believe every life matters. By bridging the gap between willing donors and those in critical need, LifeFlow aims to save lives and build a healthier community.</p>
<h3>How It Works</h3>
<ul>
  <li>Register as a donor and set your availability</li>
  <li>Post or respond to blood requests</li>
  <li>Attend blood donation camps near you</li>
  <li>Earn rewards for every donation</li>
</ul>
<h3>Contact Us</h3>
<p>Have questions? Reach out at <a href="mailto:hello@lifeflow.app">hello@lifeflow.app</a></p>`,
  },
  contact_us: {
    title: "Contact Us",
    content: `<h2>Get in Touch</h2>
<p>We'd love to hear from you. Whether you have a question, feedback, or need support, our team is here to help.</p>
<h3>Email</h3>
<p><a href="mailto:hello@lifeflow.app">hello@lifeflow.app</a></p>
<h3>Phone</h3>
<p>+1 (800) LIFEFLOW</p>
<h3>Address</h3>
<p>LifeFlow HQ<br/>123 Donor Street<br/>New York, NY 10001</p>
<h3>Support Hours</h3>
<p>Monday – Friday: 9 AM – 6 PM (EST)<br/>Saturday: 10 AM – 2 PM (EST)</p>`,
  },
  privacy_policy: {
    title: "Privacy Policy",
    content: `<h2>Privacy Policy</h2>
<p><strong>Effective Date:</strong> January 1, 2025</p>
<p>LifeFlow ("we", "us", or "our") is committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard your data.</p>
<h3>Information We Collect</h3>
<ul>
  <li>Personal information (name, email, phone number, blood group)</li>
  <li>Medical information related to blood donation eligibility</li>
  <li>Usage data and app activity</li>
</ul>
<h3>How We Use Your Information</h3>
<ul>
  <li>To connect donors with recipients</li>
  <li>To send notifications about blood requests and camps</li>
  <li>To improve our services</li>
</ul>
<h3>Data Security</h3>
<p>We use industry-standard encryption and security measures to protect your data. We do not sell your personal information to third parties.</p>
<h3>Contact</h3>
<p>For privacy concerns, email: <a href="mailto:privacy@lifeflow.app">privacy@lifeflow.app</a></p>`,
  },
  terms_of_use: {
    title: "Terms of Use",
    content: `<h2>Terms of Use</h2>
<p><strong>Effective Date:</strong> January 1, 2025</p>
<p>By using LifeFlow, you agree to the following terms and conditions. Please read them carefully.</p>
<h3>Eligibility</h3>
<p>You must be at least 18 years old to register as a blood donor. You confirm that all information provided is accurate and truthful.</p>
<h3>User Responsibilities</h3>
<ul>
  <li>Provide accurate blood group and health information</li>
  <li>Only accept donation requests when medically eligible</li>
  <li>Treat all users with respect and dignity</li>
</ul>
<h3>Prohibited Activities</h3>
<ul>
  <li>Misrepresenting your identity or medical status</li>
  <li>Using the platform for commercial purposes</li>
  <li>Harassing or threatening other users</li>
</ul>
<h3>Termination</h3>
<p>We reserve the right to suspend or terminate accounts that violate these terms.</p>`,
  },
  disclaimer: {
    title: "Disclaimer",
    content: `<h2>Disclaimer</h2>
<p>The information provided on LifeFlow is for general informational purposes only. While we strive to keep information accurate and up-to-date, we make no warranties about the completeness, accuracy, or reliability of this platform.</p>
<h3>Medical Disclaimer</h3>
<p>LifeFlow is not a medical service provider. The platform facilitates connections between donors and recipients but does not provide medical advice, diagnosis, or treatment. Always consult a qualified medical professional before making health decisions.</p>
<h3>No Liability</h3>
<p>LifeFlow shall not be held liable for any direct, indirect, incidental, or consequential damages arising from the use of this platform, including but not limited to adverse health outcomes, missed donations, or data inaccuracies.</p>
<h3>Third-Party Links</h3>
<p>Our platform may contain links to third-party websites. We are not responsible for the content or privacy practices of those sites.</p>`,
  },
};

export default function AdminPages() {
  const { toast } = useToast();
  const [activePage, setActivePage] = useState("about_us");
  const [forms, setForms] = useState<Record<string, { title: string; content: string; isPublished: boolean }>>({});
  const [showPreview, setShowPreview] = useState(false);

  const { data: pages = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/pages"],
  });

  useEffect(() => {
    if (Object.keys(forms).length > 0) return;
    const init: Record<string, any> = {};
    PAGE_TYPES.forEach(pt => {
      const found = pages.find((p: any) => p.pageType === pt.type);
      init[pt.type] = found
        ? { title: found.title, content: found.content, isPublished: found.isPublished }
        : { ...DEFAULT_CONTENT[pt.type], isPublished: true };
    });
    setForms(init);
  }, [pages]);

  const savePage = useMutation({
    mutationFn: async (type: string) => {
      const payload = forms[type] || { ...DEFAULT_CONTENT[type], isPublished: true };
      const res = await apiRequest("PUT", `/api/admin/pages/${type}`, payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pages"] });
      toast({ title: "Page saved successfully!" });
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const active = PAGE_TYPES.find(p => p.type === activePage)!;
  const form = forms[activePage] || { ...DEFAULT_CONTENT[activePage], isPublished: true };

  const setForm = (patch: Partial<typeof form>) =>
    setForms(prev => ({ ...prev, [activePage]: { ...form, ...patch } }));

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black">Page Management</h1>
        <p className="text-muted-foreground text-sm mt-1">Edit and publish content for static pages on LifeFlow</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="space-y-1.5">
          {PAGE_TYPES.map(pt => {
            const found = pages.find((p: any) => p.pageType === pt.type);
            const published = found?.isPublished ?? true;
            return (
              <button
                key={pt.type}
                onClick={() => { setActivePage(pt.type); setShowPreview(false); }}
                data-testid={`page-nav-${pt.type}`}
                className={`w-full text-left px-3 py-2.5 rounded-lg border transition-all text-sm ${
                  activePage === pt.type
                    ? "border-primary bg-primary/5 text-foreground font-semibold"
                    : "border-transparent hover:border-border hover:bg-muted/50 text-muted-foreground"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <pt.icon className="w-3.5 h-3.5 flex-shrink-0" />
                    <span className="truncate">{pt.label}</span>
                  </div>
                  <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${published ? "bg-green-500" : "bg-muted-foreground/40"}`} />
                </div>
              </button>
            );
          })}
        </div>

        <div className="lg:col-span-3 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <active.icon className="w-4 h-4 text-primary" />
                    {active.label}
                  </CardTitle>
                  <CardDescription className="mt-0.5">{active.description}</CardDescription>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <a
                    href={`/pages/${active.slug}`}
                    target="_blank"
                    rel="noreferrer"
                    data-testid={`link-view-page-${active.type}`}
                  >
                    <Button variant="outline" size="sm">
                      <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                      View
                    </Button>
                  </a>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoading ? (
                <div className="space-y-3">
                  {[1,2,3].map(i => <Skeleton key={i} className="h-10 w-full" />)}
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="text-sm font-semibold">Published</p>
                      <p className="text-xs text-muted-foreground">When disabled, the page is hidden from users</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={form.isPublished ? "default" : "secondary"} data-testid={`badge-published-${activePage}`}>
                        {form.isPublished ? "Live" : "Hidden"}
                      </Badge>
                      <Switch
                        checked={form.isPublished}
                        onCheckedChange={v => setForm({ isPublished: v })}
                        data-testid={`switch-published-${activePage}`}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Page Title</Label>
                    <Input
                      value={form.title}
                      onChange={e => setForm({ title: e.target.value })}
                      className="mt-1"
                      data-testid={`input-page-title-${activePage}`}
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <Label>Content <span className="text-muted-foreground font-normal text-xs">(HTML supported)</span></Label>
                      <button
                        onClick={() => setShowPreview(v => !v)}
                        className="text-xs text-primary hover:underline flex items-center gap-1"
                        data-testid={`button-toggle-preview-${activePage}`}
                      >
                        <Eye className="w-3.5 h-3.5" />
                        {showPreview ? "Edit" : "Preview"}
                      </button>
                    </div>
                    {showPreview ? (
                      <div
                        className="min-h-[280px] p-4 rounded-lg border bg-background overflow-auto prose prose-sm max-w-none dark:prose-invert"
                        dangerouslySetInnerHTML={{ __html: form.content }}
                        data-testid={`preview-content-${activePage}`}
                      />
                    ) : (
                      <Textarea
                        value={form.content}
                        onChange={e => setForm({ content: e.target.value })}
                        className="font-mono text-xs resize-y min-h-[280px]"
                        data-testid={`textarea-content-${activePage}`}
                      />
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      Tip: Use HTML tags like &lt;h2&gt;, &lt;p&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;a&gt; to format content
                    </p>
                  </div>

                  <Button
                    onClick={() => savePage.mutate(activePage)}
                    disabled={savePage.isPending}
                    className="w-full"
                    data-testid={`button-save-page-${activePage}`}
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {savePage.isPending ? "Saving..." : `Save ${active.label}`}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardContent className="pt-4 pb-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Public URL</p>
              <div className="flex items-center gap-2">
                <code className="text-xs bg-background border rounded px-2 py-1 flex-1 truncate" data-testid={`code-page-url-${activePage}`}>
                  {typeof window !== "undefined" ? window.location.origin : "https://yourapp.replit.app"}/pages/{active.slug}
                </code>
                <a href={`/pages/${active.slug}`} target="_blank" rel="noreferrer">
                  <Button variant="ghost" size="sm">
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
