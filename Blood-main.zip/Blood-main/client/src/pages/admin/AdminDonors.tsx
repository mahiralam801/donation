import { useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import {
  Search, Heart, MapPin, Star, CheckCircle, User, Clock,
  Camera, ToggleLeft, ToggleRight, UserPlus, Trash2, LayoutDashboard, Users,
  Eye, EyeOff,
} from "lucide-react";
import { isEligibleToDonate, daysUntilEligible } from "@/lib/eligibility";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User as UserType } from "@shared/schema";

type Tab = "all" | "featured";

export default function AdminDonors() {
  const [search, setSearch] = useState("");
  const [bgFilter, setBgFilter] = useState("all");
  const [tab, setTab] = useState<Tab>("all");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const { data: users = [], isLoading } = useQuery<Omit<UserType, "password">[]>({
    queryKey: ["/api/users"],
  });

  const donors = users.filter(u => u.isDonor);
  const featuredDonors = donors
    .filter(u => u.isActive && u.isAvailable)
    .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
    .slice(0, 12);

  const baseList = tab === "featured" ? featuredDonors : donors;
  const filtered = baseList.filter(u => {
    const matchSearch = !search ||
      u.fullName.toLowerCase().includes(search.toLowerCase()) ||
      u.city?.toLowerCase().includes(search.toLowerCase());
    const matchBg = bgFilter === "all" || u.bloodGroup === bgFilter;
    return matchSearch && matchBg;
  });

  const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
  const bgCounts: Record<string, number> = {};
  donors.forEach(d => { bgCounts[d.bloodGroup] = (bgCounts[d.bloodGroup] || 0) + 1; });

  const isFeatured = (donor: Omit<UserType, "password">) =>
    donor.isActive && donor.isAvailable && featuredDonors.some(f => f.id === donor.id);

  const toggleMutation = useMutation({
    mutationFn: ({ id, field, value }: { id: string; field: string; value: boolean }) =>
      apiRequest("PATCH", `/api/admin/users/${id}`, { [field]: value }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/public/donors/featured"] });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const photoMutation = useMutation({
    mutationFn: ({ id, photo }: { id: string; photo: string }) =>
      apiRequest("PATCH", `/api/admin/users/${id}`, { profilePhoto: photo }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/public/donors/featured"] });
      toast({ title: "Photo updated", description: "Donor photo uploaded successfully." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/admin/users/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/public/donors/featured"] });
      toast({ title: "Deleted", description: "Donor removed." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const handlePhotoChange = (donorId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Max photo size is 5MB.", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => photoMutation.mutate({ id: donorId, photo: reader.result as string });
    reader.readAsDataURL(file);
  };

  const activeCnt = donors.filter(d => d.isActive).length;
  const availCnt = donors.filter(d => d.isAvailable).length;
  const featuredCnt = donors.filter(d => d.isActive && d.isAvailable).length;

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black">Donors</h1>
          <p className="text-sm text-muted-foreground">
            {donors.length} registered · {activeCnt} active · {availCnt} available
          </p>
        </div>
        <Button size="sm" onClick={() => setLocation("/admin/users")} data-testid="button-add-donor">
          <UserPlus className="w-4 h-4 mr-1.5" /> Add Donor
        </Button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Total", value: donors.length, color: "text-foreground" },
          { label: "Active", value: activeCnt, color: "text-green-600" },
          { label: "Available", value: availCnt, color: "text-blue-600" },
          { label: "On Dashboard", value: Math.min(featuredCnt, 12), color: "text-purple-600" },
        ].map(s => (
          <Card key={s.label}>
            <CardContent className="p-3 text-center">
              <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tab switcher */}
      <div className="flex gap-2 p-1 bg-muted rounded-lg">
        <button
          onClick={() => setTab("all")}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-semibold transition-colors ${
            tab === "all" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"
          }`}
          data-testid="tab-all-donors"
        >
          <Users className="w-3.5 h-3.5" /> All Donors ({donors.length})
        </button>
        <button
          onClick={() => setTab("featured")}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-semibold transition-colors ${
            tab === "featured" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"
          }`}
          data-testid="tab-featured-donors"
        >
          <LayoutDashboard className="w-3.5 h-3.5" /> Dashboard Donors ({Math.min(featuredCnt, 12)})
        </button>
      </div>

      {/* Description banner for featured tab */}
      {tab === "featured" && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
          <LayoutDashboard className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-blue-700 dark:text-blue-300">
            <p className="font-semibold mb-0.5">These donors are currently shown on the home dashboard.</p>
            <p className="text-blue-600/80 dark:text-blue-400">
              Donors appear here when both <strong>Active</strong> and <strong>Available</strong> are ON. Up to 12 donors show on the dashboard.
              Deactivate or set unavailable to remove a donor from the dashboard.
            </p>
          </div>
        </div>
      )}

      {/* Blood group filter (only for All tab) */}
      {tab === "all" && (
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setBgFilter("all")}
            className={`text-xs px-3 py-1.5 rounded-md font-medium border transition-colors ${bgFilter === "all" ? "bg-primary text-primary-foreground border-primary" : "border-border bg-background"}`}
          >
            All ({donors.length})
          </button>
          {BLOOD_GROUPS.map(bg => (
            <button
              key={bg}
              onClick={() => setBgFilter(bg)}
              className={`text-xs px-3 py-1.5 rounded-md font-medium border transition-colors ${bgFilter === bg ? "bg-primary text-primary-foreground border-primary" : "border-border bg-background"}`}
              data-testid={`filter-bg-${bg}`}
            >
              {bg} ({bgCounts[bg] || 0})
            </button>
          ))}
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={tab === "featured" ? "Search dashboard donors..." : "Search all donors..."}
          className="pl-9"
          data-testid="input-search-donors"
        />
      </div>

      {/* Donor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading && [1, 2, 3, 4, 5, 6].map(i => (
          <Card key={i}><CardContent className="p-4"><Skeleton className="h-48 w-full" /></CardContent></Card>
        ))}

        {!isLoading && filtered.length === 0 && (
          <div className="col-span-3 text-center py-12 text-muted-foreground">
            <Heart className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">
              {tab === "featured"
                ? "No donors on dashboard — activate donors and mark them available to show here."
                : "No donors found"}
            </p>
          </div>
        )}

        {filtered.map(donor => {
          const initials = donor.fullName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
          const onDashboard = isFeatured(donor);

          return (
            <Card
              key={donor.id}
              className={`hover-elevate transition-all ${onDashboard ? "border-blue-300 dark:border-blue-700" : ""}`}
              data-testid={`donor-card-${donor.id}`}
            >
              <CardContent className="p-4 space-y-3">
                {/* Dashboard badge */}
                {onDashboard && (
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded-md -mx-0.5">
                    <LayoutDashboard className="w-3 h-3" />
                    Showing on Home Dashboard
                  </div>
                )}

                {/* Photo + info */}
                <div className="flex items-center gap-3">
                  <div className="relative flex-shrink-0">
                    {donor.profilePhoto ? (
                      <img
                        src={donor.profilePhoto}
                        alt={donor.fullName}
                        className="w-14 h-14 rounded-full object-cover border-2 border-primary/20"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-base border-2 border-primary/20">
                        {initials}
                      </div>
                    )}
                    {donor.isAvailable && donor.isActive && (
                      <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-background" />
                    )}
                    {/* Photo upload */}
                    <button
                      className="absolute -bottom-1 -left-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center shadow hover:bg-primary/80 transition-colors"
                      onClick={() => fileInputRefs.current[donor.id]?.click()}
                      title="Upload photo"
                      data-testid={`button-upload-photo-${donor.id}`}
                    >
                      <Camera className="w-2.5 h-2.5 text-white" />
                    </button>
                    <input
                      ref={el => { fileInputRefs.current[donor.id] = el; }}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={e => handlePhotoChange(donor.id, e)}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold text-sm truncate">{donor.fullName}</p>
                      {donor.isVerified && <Star className="w-3 h-3 text-yellow-500 fill-yellow-500 flex-shrink-0" />}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{donor.email}</p>
                    {donor.city && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                        <MapPin className="w-3 h-3" />
                        <span className="truncate">{donor.city}{donor.state ? `, ${donor.state}` : ""}</span>
                      </div>
                    )}
                  </div>
                  <BloodGroupBadge group={donor.bloodGroup} size="sm" />
                </div>

                {/* Status badges */}
                <div className="flex flex-wrap gap-1.5">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${donor.isActive ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300" : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"}`}>
                    {donor.isActive ? "● Active" : "● Inactive"}
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${donor.isAvailable ? "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"}`}>
                    {donor.isAvailable ? "● Available" : "● Unavailable"}
                  </span>
                  {(() => {
                    const eligible = isEligibleToDonate(donor.lastDonationDate);
                    const days = daysUntilEligible(donor.lastDonationDate);
                    return eligible ? (
                      <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300 flex items-center gap-0.5">
                        <CheckCircle className="w-2.5 h-2.5" /> Eligible
                      </span>
                    ) : (
                      <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 flex items-center gap-0.5">
                        <Clock className="w-2.5 h-2.5" /> {days}d left
                      </span>
                    );
                  })()}
                </div>

                {/* Toggle Controls */}
                <div className="border-t pt-3 space-y-2">
                  <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Dashboard Visibility Controls</p>
                  <div className="grid grid-cols-2 gap-1.5">
                    {/* Active toggle */}
                    <button
                      onClick={() => toggleMutation.mutate({ id: donor.id, field: "isActive", value: !donor.isActive })}
                      disabled={toggleMutation.isPending}
                      className={`flex items-center justify-center gap-1 py-2 px-2 rounded-lg text-[11px] font-semibold transition-all border-2 ${
                        donor.isActive
                          ? "bg-green-50 border-green-300 text-green-700 dark:bg-green-900/20 dark:border-green-700 dark:text-green-300"
                          : "bg-gray-50 border-gray-200 text-gray-500 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400"
                      }`}
                      data-testid={`button-toggle-active-${donor.id}`}
                    >
                      {donor.isActive ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                      {donor.isActive ? "Active" : "Inactive"}
                    </button>

                    {/* Available toggle */}
                    <button
                      onClick={() => toggleMutation.mutate({ id: donor.id, field: "isAvailable", value: !donor.isAvailable })}
                      disabled={toggleMutation.isPending}
                      className={`flex items-center justify-center gap-1 py-2 px-2 rounded-lg text-[11px] font-semibold transition-all border-2 ${
                        donor.isAvailable
                          ? "bg-blue-50 border-blue-300 text-blue-700 dark:bg-blue-900/20 dark:border-blue-700 dark:text-blue-300"
                          : "bg-gray-50 border-gray-200 text-gray-500 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400"
                      }`}
                      data-testid={`button-toggle-available-${donor.id}`}
                    >
                      {donor.isAvailable ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      {donor.isAvailable ? "Available" : "Unavailable"}
                    </button>
                  </div>
                  {!donor.isActive || !donor.isAvailable ? (
                    <p className="text-[10px] text-muted-foreground text-center">
                      {!donor.isActive ? "Activate to show on dashboard" : "Set available to show on dashboard"}
                    </p>
                  ) : null}
                </div>

                {/* Secondary actions */}
                <div className="flex gap-1.5">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 h-7 text-[11px]"
                    onClick={() => setLocation(`/admin/donors/${donor.id}`)}
                    data-testid={`button-view-donor-${donor.id}`}
                  >
                    <User className="w-3 h-3 mr-1" /> Profile
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-[11px] text-destructive hover:text-destructive"
                    onClick={() => {
                      if (confirm(`Delete ${donor.fullName}? This cannot be undone.`)) {
                        deleteMutation.mutate(donor.id);
                      }
                    }}
                    disabled={deleteMutation.isPending}
                    data-testid={`button-delete-donor-${donor.id}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
