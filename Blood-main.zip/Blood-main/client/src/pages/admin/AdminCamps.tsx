import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Search, Calendar, Plus, MapPin, Users, Trash2 } from "lucide-react";
import type { BloodCamp } from "@shared/schema";

const EMPTY_FORM = {
  title: "", description: "", organizer: "", venue: "", city: "", state: "",
  startDate: "", endDate: "", startTime: "", endTime: "",
  targetUnits: "100", maxParticipants: "200", contactPhone: "", contactEmail: "",
};

export default function AdminCamps() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);

  const { data: camps = [], isLoading } = useQuery<BloodCamp[]>({ queryKey: ["/api/camps/all"] });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/camps", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/camps/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/camps"] });
      toast({ title: "Blood camp created!" });
      setOpen(false);
      setForm(EMPTY_FORM);
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const res = await apiRequest("PATCH", `/api/camps/${id}`, { isActive });
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/camps/all"] }),
  });

  const handleCreate = () => {
    if (!form.title || !form.organizer || !form.venue || !form.city || !form.startDate || !form.endDate) {
      return toast({ title: "Please fill required fields", variant: "destructive" });
    }
    createMutation.mutate({
      ...form,
      targetUnits: parseInt(form.targetUnits),
      maxParticipants: parseInt(form.maxParticipants),
      isActive: true,
    });
  };

  const filtered = camps.filter(c =>
    !search || c.title.toLowerCase().includes(search.toLowerCase()) || c.city.toLowerCase().includes(search.toLowerCase())
  );

  const u = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-black">Blood Camps</h1>
          <p className="text-sm text-muted-foreground">{camps.length} total camps</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-camp">
              <Plus className="w-4 h-4 mr-2" /> Create Camp
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Blood Camp</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 pt-2">
              <div><Label className="text-xs">Camp Title *</Label><Input value={form.title} onChange={e => u("title", e.target.value)} className="mt-1" data-testid="input-camp-title" /></div>
              <div><Label className="text-xs">Organizer *</Label><Input value={form.organizer} onChange={e => u("organizer", e.target.value)} className="mt-1" /></div>
              <div><Label className="text-xs">Description</Label><Textarea value={form.description} onChange={e => u("description", e.target.value)} className="mt-1 resize-none" rows={2} /></div>
              <div><Label className="text-xs">Venue *</Label><Input value={form.venue} onChange={e => u("venue", e.target.value)} className="mt-1" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">City *</Label><Input value={form.city} onChange={e => u("city", e.target.value)} className="mt-1" /></div>
                <div><Label className="text-xs">State</Label><Input value={form.state} onChange={e => u("state", e.target.value)} className="mt-1" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Start Date *</Label><Input type="date" value={form.startDate} onChange={e => u("startDate", e.target.value)} className="mt-1" /></div>
                <div><Label className="text-xs">End Date *</Label><Input type="date" value={form.endDate} onChange={e => u("endDate", e.target.value)} className="mt-1" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Start Time</Label><Input type="time" value={form.startTime} onChange={e => u("startTime", e.target.value)} className="mt-1" /></div>
                <div><Label className="text-xs">End Time</Label><Input type="time" value={form.endTime} onChange={e => u("endTime", e.target.value)} className="mt-1" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Target Units</Label><Input type="number" value={form.targetUnits} onChange={e => u("targetUnits", e.target.value)} className="mt-1" /></div>
                <div><Label className="text-xs">Max Participants</Label><Input type="number" value={form.maxParticipants} onChange={e => u("maxParticipants", e.target.value)} className="mt-1" /></div>
              </div>
              <div><Label className="text-xs">Contact Phone</Label><Input value={form.contactPhone} onChange={e => u("contactPhone", e.target.value)} className="mt-1" /></div>
              <Button onClick={handleCreate} className="w-full" disabled={createMutation.isPending} data-testid="button-submit-camp">
                {createMutation.isPending ? "Creating..." : "Create Camp"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search camps..." className="pl-9" data-testid="input-search-camps" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {isLoading && [1, 2, 3].map(i => <Card key={i}><CardContent className="p-4"><Skeleton className="h-32 w-full" /></CardContent></Card>)}
        {!isLoading && filtered.length === 0 && (
          <div className="col-span-2 text-center py-12 text-muted-foreground">
            <Calendar className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No camps found</p>
          </div>
        )}
        {filtered.map(camp => (
          <Card key={camp.id} data-testid={`admin-camp-${camp.id}`}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex-1">
                  <p className="font-bold text-sm">{camp.title}</p>
                  <p className="text-xs text-muted-foreground">{camp.organizer}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded font-medium ${camp.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                  {camp.isActive ? "Active" : "Inactive"}
                </span>
              </div>
              <div className="space-y-1 text-xs text-muted-foreground mb-3">
                <div className="flex items-center gap-1"><MapPin className="w-3 h-3" />{camp.venue}, {camp.city}</div>
                <div className="flex items-center gap-1"><Calendar className="w-3 h-3" />{camp.startDate} — {camp.endDate}</div>
                <div className="flex items-center gap-1"><Users className="w-3 h-3" />{camp.registeredCount || 0}/{camp.maxParticipants} registered</div>
              </div>
              <Progress value={camp.maxParticipants ? ((camp.registeredCount || 0) / camp.maxParticipants) * 100 : 0} className="h-1.5 mb-3" />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => toggleMutation.mutate({ id: camp.id, isActive: !camp.isActive })}
                  className="h-7 px-3 text-xs flex-1"
                  data-testid={`button-toggle-camp-${camp.id}`}
                >
                  {camp.isActive ? "Deactivate" : "Activate"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
