import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Plus, Trash2, Save, Droplets, Link2, Shield, Phone,
  Mail, MapPin, AlertTriangle, Globe,
} from "lucide-react";

interface FooterLink { label: string; href: string }

interface FooterFormData {
  brandName: string;
  brandTagline: string;
  brandDescription: string;
  showBloodTypes: boolean;
  quickLinks: FooterLink[];
  legalLinks: FooterLink[];
  contactEmail: string;
  contactPhone: string;
  contactAddress: string;
  showEmergencyBanner: boolean;
  emergencyTitle: string;
  emergencyText: string;
  copyrightText: string;
}

const DEFAULTS: FooterFormData = {
  brandName: "LifeFlow",
  brandTagline: "Blood Donation Network",
  brandDescription: "Connecting donors with patients in need. Every drop counts — be the reason someone smiles today.",
  showBloodTypes: true,
  quickLinks: [
    { label: "Home", href: "/" },
    { label: "Register", href: "/register" },
    { label: "About Us", href: "/pages/about" },
    { label: "Contact Us", href: "/pages/contact" },
  ],
  legalLinks: [
    { label: "Privacy Policy", href: "/pages/privacy" },
    { label: "Terms of Use", href: "/pages/terms" },
    { label: "Disclaimer", href: "/pages/disclaimer" },
  ],
  contactEmail: "support@lifeflow.app",
  contactPhone: "+1 (800) LIFEFLOW",
  contactAddress: "Available Worldwide",
  showEmergencyBanner: true,
  emergencyTitle: "Need Blood Urgently?",
  emergencyText: "Post an emergency request — donors respond within minutes.",
  copyrightText: "LifeFlow Blood Donation Network. All rights reserved.",
};

function parseLinks(val: unknown): FooterLink[] {
  if (Array.isArray(val)) return val;
  try { return JSON.parse(val as string); } catch { return []; }
}

export default function AdminFooter() {
  const { toast } = useToast();
  const [initialized, setInitialized] = useState(false);

  const { data: settings, isLoading } = useQuery<any>({
    queryKey: ["/api/admin/footer"],
  });

  const form = useForm<FooterFormData>({ defaultValues: DEFAULTS });
  const { register, control, handleSubmit, setValue, watch, reset } = form;

  const quickLinksField = useFieldArray({ control, name: "quickLinks" });
  const legalLinksField = useFieldArray({ control, name: "legalLinks" });

  useEffect(() => {
    if (settings && !initialized && Object.keys(settings).length > 0) {
      reset({
        brandName: settings.brandName ?? DEFAULTS.brandName,
        brandTagline: settings.brandTagline ?? DEFAULTS.brandTagline,
        brandDescription: settings.brandDescription ?? DEFAULTS.brandDescription,
        showBloodTypes: settings.showBloodTypes ?? true,
        quickLinks: parseLinks(settings.quickLinks).length ? parseLinks(settings.quickLinks) : DEFAULTS.quickLinks,
        legalLinks: parseLinks(settings.legalLinks).length ? parseLinks(settings.legalLinks) : DEFAULTS.legalLinks,
        contactEmail: settings.contactEmail ?? DEFAULTS.contactEmail,
        contactPhone: settings.contactPhone ?? DEFAULTS.contactPhone,
        contactAddress: settings.contactAddress ?? DEFAULTS.contactAddress,
        showEmergencyBanner: settings.showEmergencyBanner ?? true,
        emergencyTitle: settings.emergencyTitle ?? DEFAULTS.emergencyTitle,
        emergencyText: settings.emergencyText ?? DEFAULTS.emergencyText,
        copyrightText: settings.copyrightText ?? DEFAULTS.copyrightText,
      });
      setInitialized(true);
    }
  }, [settings, initialized, reset]);

  const mutation = useMutation({
    mutationFn: (data: FooterFormData) =>
      apiRequest("PUT", "/api/admin/footer", {
        ...data,
        quickLinks: JSON.stringify(data.quickLinks),
        legalLinks: JSON.stringify(data.legalLinks),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/footer"] });
      queryClient.invalidateQueries({ queryKey: ["/api/public/footer"] });
      toast({ title: "Saved", description: "Footer settings updated successfully." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const onSubmit = (data: FooterFormData) => mutation.mutate(data);

  const showBloodTypes = watch("showBloodTypes");
  const showEmergencyBanner = watch("showEmergencyBanner");

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center h-48">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Footer Manager</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Customize all sections of the site footer</p>
        </div>
        <Button
          onClick={handleSubmit(onSubmit)}
          disabled={mutation.isPending}
          data-testid="button-save-footer"
          size="sm"
        >
          <Save className="w-4 h-4 mr-2" />
          {mutation.isPending ? "Saving…" : "Save Changes"}
        </Button>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">

        {/* Column 1 — Brand */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Droplets className="w-4 h-4 text-primary" /> Column 1 — Brand
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="brandName">Brand Name</Label>
                <Input id="brandName" {...register("brandName")} data-testid="input-brand-name" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="brandTagline">Tagline</Label>
                <Input id="brandTagline" {...register("brandTagline")} data-testid="input-brand-tagline" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="brandDescription">Description</Label>
              <Textarea id="brandDescription" rows={2} {...register("brandDescription")} data-testid="input-brand-description" />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">Show Blood Types</p>
                <p className="text-xs text-muted-foreground">Display all 8 blood type badges below the description</p>
              </div>
              <Switch
                checked={showBloodTypes}
                onCheckedChange={(v) => setValue("showBloodTypes", v)}
                data-testid="switch-show-blood-types"
              />
            </div>
          </CardContent>
        </Card>

        {/* Column 2 — Quick Links */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Link2 className="w-4 h-4 text-primary" /> Column 2 — Quick Links
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickLinksField.fields.map((field, idx) => (
              <div key={field.id} className="flex gap-2 items-center">
                <Input
                  placeholder="Label"
                  {...register(`quickLinks.${idx}.label`)}
                  className="flex-1"
                  data-testid={`input-quick-link-label-${idx}`}
                />
                <Input
                  placeholder="URL (e.g. /about)"
                  {...register(`quickLinks.${idx}.href`)}
                  className="flex-1"
                  data-testid={`input-quick-link-href-${idx}`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => quickLinksField.remove(idx)}
                  data-testid={`button-remove-quick-link-${idx}`}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => quickLinksField.append({ label: "", href: "" })}
              data-testid="button-add-quick-link"
            >
              <Plus className="w-3.5 h-3.5 mr-1.5" /> Add Link
            </Button>
          </CardContent>
        </Card>

        {/* Column 3 — Legal Links */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-primary" /> Column 3 — Legal Links
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {legalLinksField.fields.map((field, idx) => (
              <div key={field.id} className="flex gap-2 items-center">
                <Input
                  placeholder="Label"
                  {...register(`legalLinks.${idx}.label`)}
                  className="flex-1"
                  data-testid={`input-legal-link-label-${idx}`}
                />
                <Input
                  placeholder="URL"
                  {...register(`legalLinks.${idx}.href`)}
                  className="flex-1"
                  data-testid={`input-legal-link-href-${idx}`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => legalLinksField.remove(idx)}
                  data-testid={`button-remove-legal-link-${idx}`}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => legalLinksField.append({ label: "", href: "" })}
              data-testid="button-add-legal-link"
            >
              <Plus className="w-3.5 h-3.5 mr-1.5" /> Add Link
            </Button>
          </CardContent>
        </Card>

        {/* Column 4 — Contact */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Phone className="w-4 h-4 text-primary" /> Column 4 — Contact Info
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="contactEmail" className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" /> Email
              </Label>
              <Input id="contactEmail" {...register("contactEmail")} data-testid="input-contact-email" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="contactPhone" className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5" /> Phone
              </Label>
              <Input id="contactPhone" {...register("contactPhone")} data-testid="input-contact-phone" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="contactAddress" className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" /> Address / Location
              </Label>
              <Input id="contactAddress" {...register("contactAddress")} data-testid="input-contact-address" />
            </div>

            <Separator />

            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">Emergency Banner</p>
                <p className="text-xs text-muted-foreground">Show the emergency blood request card</p>
              </div>
              <Switch
                checked={showEmergencyBanner}
                onCheckedChange={(v) => setValue("showEmergencyBanner", v)}
                data-testid="switch-show-emergency"
              />
            </div>

            {showEmergencyBanner && (
              <div className="space-y-3 pl-1">
                <div className="space-y-1.5">
                  <Label htmlFor="emergencyTitle" className="flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-primary" /> Banner Title
                  </Label>
                  <Input id="emergencyTitle" {...register("emergencyTitle")} data-testid="input-emergency-title" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="emergencyText">Banner Text</Label>
                  <Textarea id="emergencyText" rows={2} {...register("emergencyText")} data-testid="input-emergency-text" />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bottom Bar */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Globe className="w-4 h-4 text-primary" /> Bottom Bar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1.5">
              <Label htmlFor="copyrightText">Copyright Text</Label>
              <Input id="copyrightText" {...register("copyrightText")} data-testid="input-copyright-text" />
              <p className="text-xs text-muted-foreground">The year is prepended automatically (e.g. © 2026)</p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end pb-6">
          <Button type="submit" disabled={mutation.isPending} data-testid="button-save-footer-bottom">
            <Save className="w-4 h-4 mr-2" />
            {mutation.isPending ? "Saving…" : "Save All Changes"}
          </Button>
        </div>
      </form>
    </div>
  );
}
