import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Mail, Server, FileText, Send, Eye, Save, ShieldCheck } from "lucide-react";

const TEMPLATE_TYPES = [
  { value: "verification", label: "Email Verification", description: "Sent when a new user registers" },
  { value: "password_reset", label: "Password Reset", description: "Sent when user requests password reset" },
];

const DEFAULT_TEMPLATES: Record<string, { subject: string; bodyHtml: string }> = {
  verification: {
    subject: "Verify your LifeFlow account",
    bodyHtml: `<h2 style="color:#111;font-size:20px;margin:0 0 8px;">Verify your email, {{first_name}}!</h2>
<p style="color:#555;font-size:14px;margin:0 0 24px;line-height:1.6;">
  Thank you for joining LifeFlow. Enter the code below to verify your email address and activate your account.
</p>
<div style="background:#fef2f2;border:2px dashed #D32F2F;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px;">
  <p style="color:#888;font-size:12px;margin:0 0 8px;text-transform:uppercase;letter-spacing:1px;">Verification code</p>
  <p style="color:#D32F2F;font-size:40px;font-weight:900;letter-spacing:12px;margin:0;">{{otp}}</p>
  <p style="color:#999;font-size:11px;margin:8px 0 0;">Expires in 15 minutes</p>
</div>
<p style="color:#999;font-size:12px;text-align:center;margin:0;">If you didn't create an account, ignore this email.</p>`,
  },
  password_reset: {
    subject: "Reset your LifeFlow password",
    bodyHtml: `<h2 style="color:#111;font-size:20px;margin:0 0 8px;">Password Reset Request</h2>
<p style="color:#555;font-size:14px;margin:0 0 24px;line-height:1.6;">
  Hi {{first_name}}, use the code below to reset your password.
</p>
<div style="background:#fef2f2;border:2px dashed #D32F2F;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px;">
  <p style="color:#888;font-size:12px;margin:0 0 8px;text-transform:uppercase;letter-spacing:1px;">Reset code</p>
  <p style="color:#D32F2F;font-size:40px;font-weight:900;letter-spacing:12px;margin:0;">{{otp}}</p>
  <p style="color:#999;font-size:11px;margin:8px 0 0;">Expires in 15 minutes</p>
</div>
<p style="color:#999;font-size:12px;text-align:center;margin:0;">If you didn't request a reset, ignore this email.</p>`,
  },
};

export default function AdminEmailSettings() {
  const { toast } = useToast();
  const [testEmail, setTestEmail] = useState("");
  const [smtpForm, setSmtpForm] = useState<any>(null);
  const [activeTemplate, setActiveTemplate] = useState("verification");
  const [tplForms, setTplForms] = useState<Record<string, { subject: string; bodyHtml: string; logoUrl: string }>>({});
  const [previewHtml, setPreviewHtml] = useState<string | null>(null);

  const { data: smtp, isLoading: smtpLoading } = useQuery<any>({
    queryKey: ["/api/admin/smtp"],
  });

  const { data: emailSettingsData } = useQuery<{ emailVerificationEnabled: boolean }>({
    queryKey: ["/api/admin/email-settings"],
  });

  const { data: templates = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/email-templates"],
  });

  // Sync SMTP data into local form state once loaded
  if (smtp && !smtpForm) {
    setTimeout(() => setSmtpForm(smtp), 0);
  }

  // Sync template data into local form state once loaded
  if (templates.length > 0 && Object.keys(tplForms).length === 0) {
    const forms: Record<string, any> = {};
    TEMPLATE_TYPES.forEach(t => {
      const found = templates.find((d: any) => d.emailType === t.value);
      forms[t.value] = found
        ? { subject: found.subject, bodyHtml: found.bodyHtml, logoUrl: found.logoUrl || "" }
        : { ...DEFAULT_TEMPLATES[t.value], logoUrl: "" };
    });
    setTimeout(() => setTplForms(forms), 0);
  }

  const saveSmtp = useMutation({
    mutationFn: async (data: any) => { const r = await apiRequest("PUT", "/api/admin/smtp", data); return r.json(); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/smtp"] }); toast({ title: "SMTP settings saved!" }); },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const testSmtp = useMutation({
    mutationFn: async () => { const r = await apiRequest("POST", "/api/admin/smtp/test", { testEmail }); return r.json(); },
    onSuccess: (data: any) => toast({ title: data.message }),
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const saveTpl = useMutation({
    mutationFn: async ({ type, data }: { type: string; data: any }) => {
      const r = await apiRequest("PUT", `/api/admin/email-templates/${type}`, data);
      return r.json();
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/email-templates"] }); toast({ title: "Template saved!" }); },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const saveEmailSettings = useMutation({
    mutationFn: async (enabled: boolean) => { const r = await apiRequest("PUT", "/api/admin/email-settings", { emailVerificationEnabled: enabled }); return r.json(); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/admin/email-settings"] }); toast({ title: "Email verification setting updated!" }); },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const form = smtpForm || smtp || {};
  const tplForm = tplForms[activeTemplate] || DEFAULT_TEMPLATES[activeTemplate] || { subject: "", bodyHtml: "", logoUrl: "" };

  const handlePreview = () => {
    const body = tplForm.bodyHtml.replace("{{otp}}", "123456").replace("{{first_name}}", "John").replace("{{name}}", "John Doe");
    const logoHtml = tplForm.logoUrl
      ? `<img src="${tplForm.logoUrl}" alt="LifeFlow" style="height:40px;margin-bottom:8px;" />`
      : `<span style="font-size:22px;font-weight:900;color:#fff;font-family:Arial,sans-serif;">LifeFlow</span>`;
    setPreviewHtml(`
      <div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #f0f0f0;">
        <div style="background:linear-gradient(135deg,#B71C1C,#D32F2F);padding:28px 24px;text-align:center;">${logoHtml}</div>
        <div style="padding:32px 24px;">${body}</div>
      </div>`);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black">Email Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">Configure SMTP, email templates, and verification controls</p>
      </div>

      <Tabs defaultValue="smtp">
        <TabsList className="grid grid-cols-3 w-full max-w-lg">
          <TabsTrigger value="smtp" data-testid="tab-smtp"><Server className="w-3.5 h-3.5 mr-1.5" />SMTP</TabsTrigger>
          <TabsTrigger value="templates" data-testid="tab-templates"><FileText className="w-3.5 h-3.5 mr-1.5" />Templates</TabsTrigger>
          <TabsTrigger value="controls" data-testid="tab-controls"><ShieldCheck className="w-3.5 h-3.5 mr-1.5" />Controls</TabsTrigger>
        </TabsList>

        {/* ─── SMTP TAB ─── */}
        <TabsContent value="smtp" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Server className="w-4 h-4 text-primary" />SMTP Configuration</CardTitle>
              <CardDescription>Mail server settings used to send all emails from LifeFlow</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {smtpLoading ? <Skeleton className="h-48 w-full" /> : (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 sm:col-span-1">
                      <Label>SMTP Host</Label>
                      <Input
                        value={form.smtpHost || ""}
                        onChange={e => setSmtpForm((p: any) => ({ ...p, smtpHost: e.target.value }))}
                        placeholder="smtp.gmail.com"
                        className="mt-1"
                        data-testid="input-smtp-host"
                      />
                    </div>
                    <div>
                      <Label>SMTP Port</Label>
                      <Input
                        type="number"
                        value={form.smtpPort || 587}
                        onChange={e => setSmtpForm((p: any) => ({ ...p, smtpPort: parseInt(e.target.value) }))}
                        className="mt-1"
                        data-testid="input-smtp-port"
                      />
                    </div>
                    <div>
                      <Label>SMTP Username</Label>
                      <Input
                        value={form.smtpUsername || ""}
                        onChange={e => setSmtpForm((p: any) => ({ ...p, smtpUsername: e.target.value }))}
                        placeholder="your@email.com"
                        className="mt-1"
                        data-testid="input-smtp-username"
                      />
                    </div>
                    <div>
                      <Label>SMTP Password</Label>
                      <Input
                        type="password"
                        value={form.smtpPassword || ""}
                        onChange={e => setSmtpForm((p: any) => ({ ...p, smtpPassword: e.target.value }))}
                        placeholder="App password"
                        className="mt-1"
                        data-testid="input-smtp-password"
                      />
                    </div>
                    <div>
                      <Label>Encryption</Label>
                      <Select
                        value={form.smtpEncryption || "tls"}
                        onValueChange={v => setSmtpForm((p: any) => ({ ...p, smtpEncryption: v }))}
                      >
                        <SelectTrigger className="mt-1" data-testid="select-smtp-encryption">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="tls">TLS (Recommended)</SelectItem>
                          <SelectItem value="ssl">SSL</SelectItem>
                          <SelectItem value="none">None</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>From Name</Label>
                      <Input
                        value={form.fromName || "LifeFlow"}
                        onChange={e => setSmtpForm((p: any) => ({ ...p, fromName: e.target.value }))}
                        className="mt-1"
                        data-testid="input-smtp-from-name"
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>From Email</Label>
                      <Input
                        value={form.fromEmail || ""}
                        onChange={e => setSmtpForm((p: any) => ({ ...p, fromEmail: e.target.value }))}
                        placeholder="noreply@yourdomain.com"
                        className="mt-1"
                        data-testid="input-smtp-from-email"
                      />
                    </div>
                  </div>
                  <Button
                    onClick={() => saveSmtp.mutate(smtpForm)}
                    disabled={saveSmtp.isPending}
                    data-testid="button-save-smtp"
                    className="w-full"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {saveSmtp.isPending ? "Saving..." : "Save SMTP Settings"}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Send className="w-4 h-4 text-primary" />Test Email</CardTitle>
              <CardDescription>Send a test email to verify your SMTP configuration</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-3">
                <Input
                  type="email"
                  value={testEmail}
                  onChange={e => setTestEmail(e.target.value)}
                  placeholder="test@example.com"
                  data-testid="input-test-email"
                  className="flex-1"
                />
                <Button
                  onClick={() => testSmtp.mutate()}
                  disabled={testSmtp.isPending || !testEmail}
                  variant="outline"
                  data-testid="button-test-smtp"
                >
                  {testSmtp.isPending ? "Sending..." : "Send Test"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── TEMPLATES TAB ─── */}
        <TabsContent value="templates" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2">
            {TEMPLATE_TYPES.map(t => (
              <button
                key={t.value}
                onClick={() => setActiveTemplate(t.value)}
                data-testid={`tab-template-${t.value}`}
                className={`text-left p-3 rounded-lg border transition-colors ${activeTemplate === t.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}
              >
                <p className="text-sm font-semibold">{t.label}</p>
                <p className="text-xs text-muted-foreground">{t.description}</p>
              </button>
            ))}
          </div>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" />
                {TEMPLATE_TYPES.find(t => t.value === activeTemplate)?.label} Template
              </CardTitle>
              <CardDescription>Use <code className="bg-muted px-1 rounded text-xs">{"{{otp}}"}</code>, <code className="bg-muted px-1 rounded text-xs">{"{{name}}"}</code>, <code className="bg-muted px-1 rounded text-xs">{"{{first_name}}"}</code> as placeholders</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Email Subject</Label>
                <Input
                  value={tplForm.subject}
                  onChange={e => setTplForms(p => ({ ...p, [activeTemplate]: { ...tplForm, subject: e.target.value } }))}
                  className="mt-1"
                  data-testid="input-template-subject"
                />
              </div>
              <div>
                <Label>Logo URL <span className="text-muted-foreground font-normal">(optional)</span></Label>
                <Input
                  value={tplForm.logoUrl || ""}
                  onChange={e => setTplForms(p => ({ ...p, [activeTemplate]: { ...tplForm, logoUrl: e.target.value } }))}
                  placeholder="https://yoursite.com/logo.png"
                  className="mt-1"
                  data-testid="input-template-logo"
                />
              </div>
              <div>
                <Label>Email Body (HTML)</Label>
                <Textarea
                  value={tplForm.bodyHtml}
                  onChange={e => setTplForms(p => ({ ...p, [activeTemplate]: { ...tplForm, bodyHtml: e.target.value } }))}
                  className="mt-1 font-mono text-xs resize-y"
                  rows={12}
                  data-testid="textarea-template-body"
                />
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handlePreview}
                  data-testid="button-preview-template"
                >
                  <Eye className="w-4 h-4 mr-2" /> Preview
                </Button>
                <Button
                  onClick={() => saveTpl.mutate({ type: activeTemplate, data: tplForms[activeTemplate] })}
                  disabled={saveTpl.isPending}
                  data-testid="button-save-template"
                  className="flex-1"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {saveTpl.isPending ? "Saving..." : "Save Template"}
                </Button>
              </div>
              {previewHtml && (
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Preview</p>
                    <button onClick={() => setPreviewHtml(null)} className="text-xs text-muted-foreground hover:text-foreground">Close</button>
                  </div>
                  <div className="border rounded-lg overflow-hidden">
                    <iframe
                      srcDoc={previewHtml}
                      className="w-full"
                      style={{ height: 380 }}
                      title="Email preview"
                      data-testid="iframe-email-preview"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── CONTROLS TAB ─── */}
        <TabsContent value="controls" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-primary" />Email Verification</CardTitle>
              <CardDescription>Control whether new users must verify their email before logging in</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                <div>
                  <p className="text-sm font-semibold">Require Email Verification</p>
                  <p className="text-xs text-muted-foreground mt-0.5">When enabled, new registrations must verify their email via OTP before logging in</p>
                </div>
                <Switch
                  checked={emailSettingsData?.emailVerificationEnabled ?? true}
                  onCheckedChange={v => saveEmailSettings.mutate(v)}
                  disabled={saveEmailSettings.isPending}
                  data-testid="switch-email-verification"
                />
              </div>

              <div className="p-4 rounded-lg border border-dashed space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Current Status</p>
                <div className="flex items-center gap-2">
                  <Badge variant={emailSettingsData?.emailVerificationEnabled ? "default" : "secondary"} data-testid="badge-verification-status">
                    {emailSettingsData?.emailVerificationEnabled ? "Verification ENABLED" : "Verification DISABLED"}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {emailSettingsData?.emailVerificationEnabled
                    ? "New users will receive an email with a 6-digit OTP and must verify before their account is active."
                    : "New users are immediately active after registration without email verification."}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Quick Reference</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-xs text-muted-foreground">
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "Verification OTP expires", value: "15 minutes" },
                  { label: "Resend cooldown", value: "60 seconds" },
                  { label: "OTP length", value: "6 digits" },
                  { label: "Admin bypass", value: "Always verified" },
                ].map(({ label, value }) => (
                  <div key={label} className="bg-muted/50 rounded p-2.5">
                    <p className="font-medium text-foreground">{value}</p>
                    <p>{label}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
