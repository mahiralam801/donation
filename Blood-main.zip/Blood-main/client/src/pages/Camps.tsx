import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { MobileNav } from "@/components/MobileNav";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Calendar, MapPin, Users, Clock, Building2, Phone, CheckCircle, Loader2 } from "lucide-react";
import type { BloodCamp, CampRegistration } from "@shared/schema";

export default function Camps() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: camps = [], isLoading } = useQuery<BloodCamp[]>({ queryKey: ["/api/camps"] });
  const { data: myRegs = [] } = useQuery<CampRegistration[]>({ queryKey: ["/api/my-registrations"] });

  const registeredCampIds = new Set(myRegs.map(r => r.campId));

  const registerMutation = useMutation({
    mutationFn: async (campId: string) => {
      const res = await apiRequest("POST", `/api/camps/${campId}/register`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-registrations"] });
      toast({ title: "Registered successfully!" });
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const today = new Date().toISOString().split("T")[0];
  const upcoming = camps.filter(c => c.startDate >= today);
  const past = camps.filter(c => c.startDate < today);

  function CampCard({ camp }: { camp: BloodCamp }) {
    const isRegistered = registeredCampIds.has(camp.id);
    const regPercent = camp.maxParticipants ? Math.round(((camp.registeredCount || 0) / camp.maxParticipants) * 100) : 0;
    const isFull = (camp.registeredCount || 0) >= (camp.maxParticipants || Infinity);
    const isUpcoming = camp.startDate >= today;

    return (
      <Card className="hover-elevate" data-testid={`camp-card-${camp.id}`}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-2 mb-3">
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm" data-testid={`camp-title-${camp.id}`}>{camp.title}</h3>
              <p className="text-xs text-muted-foreground">{camp.organizer}</p>
            </div>
            {isRegistered ? (
              <Badge className="bg-green-100 text-green-700 border-green-200 flex-shrink-0 text-xs">
                <CheckCircle className="w-3 h-3 mr-1" /> Registered
              </Badge>
            ) : isUpcoming ? (
              <Badge variant="secondary" className="flex-shrink-0 text-xs">Upcoming</Badge>
            ) : (
              <Badge variant="outline" className="flex-shrink-0 text-xs text-muted-foreground">Past</Badge>
            )}
          </div>

          <div className="space-y-1.5 text-xs text-muted-foreground mb-3">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{camp.venue}, {camp.city}{camp.state ? `, ${camp.state}` : ""}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3 h-3 flex-shrink-0" />
              <span>{camp.startDate}{camp.endDate !== camp.startDate ? ` - ${camp.endDate}` : ""}</span>
            </div>
            {camp.startTime && (
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3 flex-shrink-0" />
                <span>{camp.startTime}{camp.endTime ? ` - ${camp.endTime}` : ""}</span>
              </div>
            )}
            {camp.contactPhone && (
              <div className="flex items-center gap-1.5">
                <Phone className="w-3 h-3 flex-shrink-0" />
                <span>{camp.contactPhone}</span>
              </div>
            )}
          </div>

          {camp.description && (
            <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{camp.description}</p>
          )}

          <div className="mb-3">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground flex items-center gap-1"><Users className="w-3 h-3" /> Participants</span>
              <span className="font-medium">{camp.registeredCount || 0} / {camp.maxParticipants || "∞"}</span>
            </div>
            <Progress value={regPercent} className="h-1.5" />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex gap-3 text-xs">
              <span className="text-muted-foreground">Target: <strong>{camp.targetUnits}</strong> units</span>
              {camp.collectedUnits ? <span className="text-green-600">Collected: <strong>{camp.collectedUnits}</strong></span> : null}
            </div>
            {isUpcoming && !isRegistered && !isFull && (
              <Button
                size="sm"
                onClick={() => registerMutation.mutate(camp.id)}
                disabled={registerMutation.isPending}
                data-testid={`button-register-camp-${camp.id}`}
              >
                {registerMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Register"}
              </Button>
            )}
            {isFull && !isRegistered && (
              <span className="text-xs text-muted-foreground font-medium">Full</span>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 pt-10 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-green-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-5 h-5" />
            <h1 className="text-xl font-black">Blood Camps</h1>
          </div>
          <p className="text-green-200 text-xs">{upcoming.length} upcoming events</p>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto space-y-5">
        {isLoading && (
          <div className="space-y-3">
            {[1, 2].map(i => <Card key={i}><CardContent className="p-4"><Skeleton className="h-32 w-full" /></CardContent></Card>)}
          </div>
        )}

        {!isLoading && camps.length === 0 && (
          <div className="text-center py-16">
            <Calendar className="w-16 h-16 mx-auto mb-3 text-muted-foreground opacity-30" />
            <p className="font-semibold text-sm">No blood camps scheduled</p>
            <p className="text-xs text-muted-foreground mt-1">Check back later for upcoming events</p>
          </div>
        )}

        {upcoming.length > 0 && (
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Upcoming Camps</h3>
            <div className="space-y-3">
              {upcoming.map(camp => <CampCard key={camp.id} camp={camp} />)}
            </div>
          </section>
        )}

        {past.length > 0 && (
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Past Events</h3>
            <div className="space-y-3">
              {past.map(camp => <CampCard key={camp.id} camp={camp} />)}
            </div>
          </section>
        )}
      </div>
      <MobileNav />
    </div>
  );
}
