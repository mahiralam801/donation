import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { MobileNav } from "@/components/MobileNav";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getStoredUser, BLOOD_GROUPS, statusColor } from "@/lib/auth";
import { ArrowLeft, Heart, Plus, Award, Download, Calendar, Building2, CheckCircle } from "lucide-react";
import type { Donation } from "@shared/schema";

function downloadCertificate(donation: Donation, donorName: string) {
  const certDate = donation.donationDate
    ? new Date(donation.donationDate).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
    : "N/A";

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>Blood Donation Certificate – ${donation.certificateId}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Lato:wght@300;400;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}

  body{
    background:#f0f0f0;
    display:flex;flex-direction:column;align-items:center;justify-content:flex-start;
    min-height:100vh;padding:30px 20px 20px;gap:24px;
    font-family:'Lato',sans-serif;
  }

  /* ── A4 LANDSCAPE CERTIFICATE ── */
  .cert{
    width:297mm;min-height:210mm;
    background:#fff;
    position:relative;
    box-shadow:0 8px 40px rgba(0,0,0,0.18);
    display:flex;flex-direction:column;
    overflow:hidden;
  }

  /* Outer decorative border */
  .cert-border{
    position:absolute;inset:10mm;
    border:2.5px solid #D32F2F;
    pointer-events:none;z-index:2;
  }
  .cert-border::before{
    content:'';position:absolute;inset:4px;
    border:0.8px solid #D32F2F;opacity:0.4;
  }

  /* Corner ornaments */
  .corner{position:absolute;width:14mm;height:14mm;z-index:3;}
  .corner svg{width:100%;height:100%;}
  .corner-tl{top:9mm;left:9mm;}
  .corner-tr{top:9mm;right:9mm;transform:scaleX(-1);}
  .corner-bl{bottom:9mm;left:9mm;transform:scaleY(-1);}
  .corner-br{bottom:9mm;right:9mm;transform:scale(-1);}

  /* Watermark */
  .watermark{
    position:absolute;top:50%;left:50%;
    transform:translate(-50%,-50%);
    opacity:0.035;z-index:1;
    pointer-events:none;
  }
  .watermark svg{width:160mm;height:160mm;}

  /* Red top bar */
  .top-bar{
    background:linear-gradient(135deg,#B71C1C 0%,#D32F2F 45%,#E53935 100%);
    padding:5mm 18mm 4mm;
    display:flex;align-items:center;justify-content:center;gap:5mm;
    position:relative;overflow:hidden;flex-shrink:0;
  }
  .top-bar::after{
    content:'';position:absolute;bottom:0;left:0;right:0;height:3px;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.4),transparent);
  }
  /* heartbeat line across top bar */
  .heartbeat-line{
    position:absolute;bottom:0;left:0;right:0;height:100%;opacity:0.08;
  }
  .org-logo-wrap{display:flex;align-items:center;gap:3mm;}
  .org-icon{width:12mm;height:12mm;background:rgba(255,255,255,0.18);border-radius:3mm;
    display:flex;align-items:center;justify-content:center;flex-shrink:0;}
  .org-icon svg{width:7mm;height:7mm;}
  .org-text-block{text-align:left;}
  .org-name{font-family:'Cinzel',serif;font-size:7mm;font-weight:700;color:#fff;letter-spacing:0.5mm;line-height:1;}
  .org-tagline{font-size:2.8mm;color:rgba(255,255,255,0.75);letter-spacing:1.5mm;text-transform:uppercase;margin-top:0.5mm;}

  /* Divider with cross */
  .title-divider{
    display:flex;align-items:center;gap:4mm;
    margin:0 18mm;padding:3.5mm 0 2mm;position:relative;z-index:2;flex-shrink:0;
  }
  .divider-line{flex:1;height:1px;background:linear-gradient(90deg,transparent,#D32F2F,transparent);}
  .cross-icon{flex-shrink:0;}

  /* Certificate title */
  .cert-title{
    text-align:center;position:relative;z-index:2;flex-shrink:0;
    padding:0 18mm;
  }
  .cert-title-main{
    font-family:'Cinzel',serif;font-size:9mm;font-weight:700;
    color:#B71C1C;letter-spacing:1.5mm;text-transform:uppercase;
    line-height:1.1;
  }
  .cert-title-sub{
    font-size:3mm;color:#555;letter-spacing:3mm;text-transform:uppercase;
    margin-top:1.5mm;
  }

  /* Body area */
  .cert-body{
    flex:1;padding:4mm 20mm 3mm;
    display:flex;flex-direction:column;align-items:center;
    position:relative;z-index:2;
    justify-content:space-between;
  }

  .presented-to{
    text-align:center;
    font-size:3.8mm;color:#444;letter-spacing:0.5mm;margin-bottom:1mm;font-style:italic;
  }

  .donor-name{
    font-family:'Cinzel',serif;
    font-size:13mm;font-weight:700;
    color:#1a1a1a;
    text-align:center;
    line-height:1;
    padding:1.5mm 8mm;
    position:relative;
    margin-bottom:1mm;
  }
  .donor-name::before,.donor-name::after{
    content:'—';color:#D32F2F;font-size:8mm;margin:0 3mm;font-family:'Lato',sans-serif;font-weight:300;
  }

  .appreciation{
    text-align:center;
    font-size:3.4mm;color:#555;line-height:1.65;
    max-width:160mm;margin:0 auto;
    margin-bottom:2.5mm;
  }

  /* Details row */
  .details-row{
    display:flex;gap:6mm;justify-content:center;width:100%;
    margin-bottom:3mm;
  }
  .detail-box{
    flex:1;max-width:60mm;
    border:1px solid #FFCDD2;
    border-top:3px solid #D32F2F;
    border-radius:1.5mm;
    padding:2.5mm 3.5mm;
    background:linear-gradient(180deg,#FFF5F5 0%,#fff 100%);
    display:flex;flex-direction:column;gap:0.8mm;
  }
  .detail-icon-label{display:flex;align-items:center;gap:1.5mm;}
  .detail-icon-label svg{width:3.5mm;height:3.5mm;flex-shrink:0;}
  .detail-label{font-size:2.4mm;color:#D32F2F;font-weight:700;letter-spacing:0.8mm;text-transform:uppercase;}
  .detail-value{font-size:3.8mm;font-weight:700;color:#1a1a1a;margin-top:0.5mm;}

  /* Signature section */
  .sig-row{
    display:flex;align-items:flex-end;justify-content:space-between;
    width:100%;padding:0 4mm;
    margin-bottom:0.5mm;
  }
  .sig-block{text-align:center;width:55mm;}
  .sig-line{border-top:1.5px solid #333;margin-bottom:1.5mm;}
  .sig-title{font-size:3mm;font-weight:700;color:#333;letter-spacing:0.3mm;}
  .sig-subtitle{font-size:2.5mm;color:#777;}

  .cert-seal{
    width:22mm;height:22mm;border-radius:50%;
    border:2px dashed #D32F2F;
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    color:#D32F2F;gap:0.5mm;
    opacity:0.65;
  }
  .cert-seal svg{width:6mm;height:6mm;}
  .cert-seal-text{font-size:2mm;font-weight:700;letter-spacing:0.5mm;text-transform:uppercase;text-align:center;line-height:1.3;}

  /* Footer */
  .cert-footer{
    background:#1a1a1a;
    padding:2mm 18mm;
    display:flex;align-items:center;justify-content:space-between;
    flex-shrink:0;position:relative;z-index:2;
  }
  .foot-left{display:flex;flex-direction:column;gap:0.3mm;}
  .foot-label{font-size:2mm;color:#777;letter-spacing:1mm;text-transform:uppercase;}
  .foot-id{font-size:2.8mm;font-family:monospace;color:#e0e0e0;letter-spacing:0.8mm;}
  .foot-center{display:flex;align-items:center;gap:2mm;}
  .foot-drop-icon{width:6mm;height:6mm;background:#D32F2F;border-radius:1.5mm;
    display:flex;align-items:center;justify-content:center;}
  .foot-drop-icon svg{width:4mm;height:4mm;}
  .foot-brand-name{font-family:'Cinzel',serif;font-size:4mm;color:#fff;font-weight:700;}
  .foot-right{font-size:2mm;color:#555;text-align:right;letter-spacing:0.3mm;}

  /* Print controls */
  .controls{display:flex;gap:12px;align-items:center;}
  .btn{padding:10px 22px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;border:none;font-family:'Lato',sans-serif;}
  .btn-primary{background:#D32F2F;color:#fff;}
  .btn-secondary{background:#e0e0e0;color:#333;}

  @media print{
    body{background:#fff;padding:0;gap:0;}
    .controls{display:none;}
    @page{size:A4 landscape;margin:0;}
    .cert{width:297mm;min-height:210mm;box-shadow:none;}
  }
</style>
</head>
<body>

<div class="cert">
  <!-- Watermark blood drop -->
  <div class="watermark">
    <svg viewBox="0 0 100 100" fill="#D32F2F">
      <path d="M50 5 C50 5 10 45 10 65 a40 40 0 0 0 80 0 C90 45 50 5 50 5 Z"/>
    </svg>
  </div>

  <!-- Decorative border frame -->
  <div class="cert-border"></div>

  <!-- Corner ornaments -->
  <div class="corner corner-tl">
    <svg viewBox="0 0 60 60" fill="none" stroke="#D32F2F" stroke-width="2">
      <path d="M2 30 L2 2 L30 2"/>
      <path d="M8 30 L8 8 L30 8"/>
      <circle cx="4" cy="4" r="2" fill="#D32F2F"/>
    </svg>
  </div>
  <div class="corner corner-tr">
    <svg viewBox="0 0 60 60" fill="none" stroke="#D32F2F" stroke-width="2">
      <path d="M2 30 L2 2 L30 2"/>
      <path d="M8 30 L8 8 L30 8"/>
      <circle cx="4" cy="4" r="2" fill="#D32F2F"/>
    </svg>
  </div>
  <div class="corner corner-bl">
    <svg viewBox="0 0 60 60" fill="none" stroke="#D32F2F" stroke-width="2">
      <path d="M2 30 L2 2 L30 2"/>
      <path d="M8 30 L8 8 L30 8"/>
      <circle cx="4" cy="4" r="2" fill="#D32F2F"/>
    </svg>
  </div>
  <div class="corner corner-br">
    <svg viewBox="0 0 60 60" fill="none" stroke="#D32F2F" stroke-width="2">
      <path d="M2 30 L2 2 L30 2"/>
      <path d="M8 30 L8 8 L30 8"/>
      <circle cx="4" cy="4" r="2" fill="#D32F2F"/>
    </svg>
  </div>

  <!-- Top red header bar -->
  <div class="top-bar">
    <!-- Heartbeat SVG line decoration -->
    <svg class="heartbeat-line" viewBox="0 0 1200 80" preserveAspectRatio="none" fill="none" stroke="white" stroke-width="3">
      <polyline points="0,40 200,40 230,10 255,70 280,15 305,65 330,40 500,40 530,40 560,5 590,75 620,20 650,60 680,40 1200,40"/>
    </svg>
    <div class="org-logo-wrap">
      <div class="org-icon">
        <svg viewBox="0 0 24 24" fill="white">
          <path d="M12 2C12 2 4 10 4 15a8 8 0 0016 0C20 10 12 2 12 2Z"/>
        </svg>
      </div>
      <div class="org-text-block">
        <div class="org-name">LifeFlow</div>
        <div class="org-tagline">Blood Donation Network</div>
      </div>
    </div>
  </div>

  <!-- Title divider with cross -->
  <div class="title-divider">
    <div class="divider-line"></div>
    <div class="cross-icon">
      <svg width="6mm" height="6mm" viewBox="0 0 24 24" fill="none" stroke="#D32F2F" stroke-width="2.5" stroke-linecap="round">
        <line x1="12" y1="2" x2="12" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/>
      </svg>
    </div>
    <div class="divider-line"></div>
  </div>

  <!-- Certificate Title -->
  <div class="cert-title">
    <div class="cert-title-main">Certificate of Blood Donation</div>
    <div class="cert-title-sub">This certificate is proudly presented to</div>
  </div>

  <!-- Main Body -->
  <div class="cert-body">

    <!-- Donor name -->
    <div style="text-align:center;width:100%;">
      <div class="donor-name">${donorName}</div>
    </div>

    <!-- Appreciation text -->
    <p class="appreciation">
      In recognition of your generous act of donating blood and helping save lives.<br/>
      Your selfless contribution is highly appreciated and valued by the entire community.<br/>
      <em style="color:#D32F2F;font-size:3mm;">"Every drop counts — you are a true hero."</em>
    </p>

    <!-- Details -->
    <div class="details-row">
      <div class="detail-box">
        <div class="detail-icon-label">
          <svg viewBox="0 0 24 24" fill="#D32F2F"><path d="M12 2C12 2 4 10 4 15a8 8 0 0016 0C20 10 12 2 12 2Z"/></svg>
          <span class="detail-label">Blood Group</span>
        </div>
        <div class="detail-value">${donation.bloodGroup}</div>
      </div>
      <div class="detail-box">
        <div class="detail-icon-label">
          <svg viewBox="0 0 24 24" fill="none" stroke="#D32F2F" stroke-width="2" stroke-linecap="round">
            <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
          <span class="detail-label">Date of Donation</span>
        </div>
        <div class="detail-value">${certDate}</div>
      </div>
      <div class="detail-box">
        <div class="detail-icon-label">
          <svg viewBox="0 0 24 24" fill="none" stroke="#D32F2F" stroke-width="2" stroke-linecap="round">
            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
            <polyline points="9 22 9 12 15 12 15 22"/>
          </svg>
          <span class="detail-label">Donation Camp / Location</span>
        </div>
        <div class="detail-value">${donation.hospital || "—"}${donation.city ? `, ${donation.city}` : ""}</div>
      </div>
    </div>

    <!-- Signatures -->
    <div class="sig-row">
      <div class="sig-block">
        <div style="height:10mm;display:flex;align-items:flex-end;justify-content:center;margin-bottom:1.5mm;">
          <svg width="30mm" height="8mm" viewBox="0 0 120 32" fill="none" stroke="#555" stroke-width="1.5" stroke-linecap="round">
            <path d="M5 24 Q20 8 35 20 Q50 32 65 16 Q80 2 95 18 Q105 28 115 14"/>
          </svg>
        </div>
        <div class="sig-line"></div>
        <div class="sig-title">Dr. Medical Officer</div>
        <div class="sig-subtitle">Chief Medical Officer</div>
      </div>

      <div class="cert-seal">
        <svg viewBox="0 0 24 24" fill="#D32F2F">
          <path d="M12 2C12 2 4 10 4 15a8 8 0 0016 0C20 10 12 2 12 2Z"/>
        </svg>
        <div class="cert-seal-text">OFFICIAL<br/>SEAL</div>
      </div>

      <div class="sig-block">
        <div style="height:10mm;display:flex;align-items:flex-end;justify-content:center;margin-bottom:1.5mm;">
          <svg width="30mm" height="8mm" viewBox="0 0 120 32" fill="none" stroke="#555" stroke-width="1.5" stroke-linecap="round">
            <path d="M5 20 Q15 4 30 22 Q45 38 60 12 Q75 -4 90 20 Q100 32 115 10"/>
          </svg>
        </div>
        <div class="sig-line"></div>
        <div class="sig-title">Camp Organizer</div>
        <div class="sig-subtitle">LifeFlow Blood Donation Network</div>
      </div>
    </div>

  </div>

  <!-- Footer bar -->
  <div class="cert-footer">
    <div class="foot-left">
      <div class="foot-label">Certificate ID</div>
      <div class="foot-id">${donation.certificateId}</div>
    </div>
    <div class="foot-center">
      <div class="foot-drop-icon">
        <svg viewBox="0 0 24 24" fill="white"><path d="M12 2C12 2 5 9.5 5 14a7 7 0 0014 0C19 9.5 12 2 12 2Z"/></svg>
      </div>
      <div class="foot-brand-name">LifeFlow</div>
    </div>
    <div class="foot-right">
      Issued on ${new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"})}<br/>
      lifeflow.app
    </div>
  </div>
</div>

<div class="controls">
  <button class="btn btn-primary" onclick="window.print()">&#x1F4E5; Print / Save as PDF</button>
  <button class="btn btn-secondary" onclick="window.close()">Close</button>
</div>

<script>setTimeout(()=>window.print(),600)</script>
</body>
</html>`;

  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const win = window.open(url, "_blank");
  if (!win) {
    const a = document.createElement("a");
    a.href = url;
    a.download = `LifeFlow-Certificate-${donation.certificateId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

export default function Donations() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const user = getStoredUser();
  const [open, setOpen] = useState(false);

  const [form, setForm] = useState({
    bloodGroup: user?.bloodGroup || "",
    units: "1",
    hospital: "",
    city: user?.city || "",
    donationDate: new Date().toISOString().split("T")[0],
    notes: "",
  });

  const { data: donations = [], isLoading } = useQuery<Donation[]>({ queryKey: ["/api/donations"] });

  const addMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/donations", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Donation recorded! +100 reward points" });
      setOpen(false);
      setForm({ bloodGroup: user?.bloodGroup || "", units: "1", hospital: "", city: user?.city || "", donationDate: new Date().toISOString().split("T")[0], notes: "" });
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const handleSubmit = () => {
    if (!form.bloodGroup || !form.hospital || !form.donationDate) {
      return toast({ title: "Please fill required fields", variant: "destructive" });
    }
    addMutation.mutate({ ...form, units: parseInt(form.units), donorId: user?.id, status: "completed" });
  };

  const totalUnits = donations.reduce((sum, d) => sum + (d.units || 1), 0);

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-gradient-to-r from-pink-600 to-rose-700 text-white px-4 pt-10 pb-6">
        <div className="max-w-md mx-auto">
          <button onClick={() => setLocation("/dashboard")} className="mb-3 flex items-center gap-1 text-pink-100 text-sm">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </button>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Heart className="w-5 h-5" />
                <h1 className="text-xl font-black">Donation History</h1>
              </div>
              <p className="text-pink-200 text-xs">{donations.length} total donations • {totalUnits} units</p>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="bg-white/10 border-white/30 text-white" data-testid="button-add-donation">
                  <Plus className="w-4 h-4 mr-1" /> Log
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Log Donation</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 pt-2">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">Blood Group *</Label>
                      <Select value={form.bloodGroup} onValueChange={v => setForm(p => ({ ...p, bloodGroup: v }))}>
                        <SelectTrigger className="mt-1" data-testid="select-donation-blood-group">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {BLOOD_GROUPS.map(bg => <SelectItem key={bg} value={bg}>{bg}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs">Units</Label>
                      <Select value={form.units} onValueChange={v => setForm(p => ({ ...p, units: v }))}>
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Hospital *</Label>
                    <Input value={form.hospital} onChange={e => setForm(p => ({ ...p, hospital: e.target.value }))} placeholder="Hospital name" className="mt-1" data-testid="input-donation-hospital" />
                  </div>
                  <div>
                    <Label className="text-xs">City</Label>
                    <Input value={form.city} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} placeholder="City" className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">Donation Date *</Label>
                    <Input type="date" value={form.donationDate} onChange={e => setForm(p => ({ ...p, donationDate: e.target.value }))} className="mt-1" data-testid="input-donation-date" />
                  </div>
                  <div>
                    <Label className="text-xs">Notes</Label>
                    <Textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} placeholder="Optional notes" className="mt-1 resize-none" rows={2} />
                  </div>
                  <Button onClick={handleSubmit} className="w-full" disabled={addMutation.isPending} data-testid="button-submit-donation">
                    {addMutation.isPending ? "Saving..." : "Record Donation"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="px-4 py-5 max-w-md mx-auto space-y-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: Heart, label: "Donations", value: donations.length, color: "text-pink-600" },
            { icon: Award, label: "Points", value: user?.rewardPoints || 0, color: "text-yellow-600" },
            { icon: CheckCircle, label: "Units", value: totalUnits, color: "text-green-600" },
          ].map(({ icon: Icon, label, value, color }) => (
            <Card key={label}>
              <CardContent className="p-3 text-center">
                <Icon className={`w-5 h-5 mx-auto mb-1 ${color}`} />
                <p className="text-lg font-black" data-testid={`stat-${label.toLowerCase()}`}>{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {isLoading && (
          <div className="space-y-3">
            {[1, 2].map(i => <Card key={i}><CardContent className="p-4"><Skeleton className="h-20 w-full" /></CardContent></Card>)}
          </div>
        )}

        {!isLoading && donations.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-pink-100 dark:bg-pink-900/20 flex items-center justify-center mx-auto mb-3">
              <Heart className="w-8 h-8 text-pink-600" />
            </div>
            <p className="font-semibold text-sm">No donations recorded</p>
            <p className="text-xs text-muted-foreground mt-1 mb-4">Log your first blood donation</p>
            <Button onClick={() => setOpen(true)} data-testid="button-log-first-donation">
              <Plus className="w-4 h-4 mr-2" /> Log Donation
            </Button>
          </div>
        )}

        {donations.map(donation => (
          <Card key={donation.id} className="hover-elevate" data-testid={`donation-${donation.id}`}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <BloodGroupBadge group={donation.bloodGroup} size="sm" />
                    <span className={`text-xs px-2 py-0.5 rounded font-medium ${statusColor(donation.status || "completed")}`}>
                      {(donation.status || "completed").charAt(0).toUpperCase() + (donation.status || "completed").slice(1)}
                    </span>
                  </div>
                </div>
                <span className="text-xs text-green-600 font-medium">+{donation.pointsEarned || 100} pts</span>
              </div>

              <div className="space-y-1 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Building2 className="w-3 h-3" />
                  <span>{donation.hospital || "Hospital"}{donation.city ? `, ${donation.city}` : ""}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3 h-3" />
                  <span>{donation.donationDate}</span>
                </div>
              </div>

              {donation.certificateId && (
                <div className="mt-3 flex items-center justify-between p-2 bg-muted rounded-md">
                  <div>
                    <p className="text-xs font-medium">Certificate</p>
                    <p className="text-[10px] text-muted-foreground font-mono">{donation.certificateId}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 px-2"
                    data-testid={`button-download-cert-${donation.id}`}
                    onClick={() => downloadCertificate(donation, user?.fullName || user?.email || "Donor")}
                  >
                    <Download className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
      <MobileNav />
    </div>
  );
}
