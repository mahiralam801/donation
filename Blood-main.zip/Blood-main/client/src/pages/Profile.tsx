import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { MobileNav } from "@/components/MobileNav";
import { BloodGroupBadge } from "@/components/BloodGroupBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getStoredUser, setStoredUser, removeToken, BLOOD_GROUPS } from "@/lib/auth";
import { ArrowLeft, User, Settings, LogOut, Heart, Award, Star, Edit2, Save, X, Camera } from "lucide-react";
import { COUNTRIES } from "@/lib/countries";
import type { User as UserType, Badge, UserBadge } from "@shared/schema";

export default function Profile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const storedUser = getStoredUser();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<Partial<UserType>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const { data: user, isLoading } = useQuery<Omit<UserType, "password">>({
    queryKey: ["/api/auth/me"],
    onSuccess: (data: any) => {
      setStoredUser(data as any);
    },
  } as any);

  const { data: myBadges = [] } = useQuery<(UserBadge & { badge: Badge })[]>({
    queryKey: ["/api/my-badges"],
  });

  const updateMutation = useMutation({
    mutationFn: async (data: Partial<UserType>) => {
      const res = await apiRequest("PATCH", `/api/users/${user?.id}`, data);
      return res.json();
    },
    onSuccess: (data: any) => {
      setStoredUser(data);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Profile updated!" });
      setEditing(false);
    },
    onError: (e: any) => toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" }),
  });

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Please choose an image under 2MB", variant: "destructive" });
      return;
    }
    setUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const res = await apiRequest("PATCH", `/api/users/${user.id}`, { profileImage: base64 });
        const updated = await res.json();
        setStoredUser(updated);
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        toast({ title: "Profile picture updated!" });
      } catch {
        toast({ title: "Upload failed", variant: "destructive" });
      } finally {
        setUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLogout = () => {
    removeToken();
    setLocation("/");
  };

  const startEdit = () => {
    setForm({
      fullName: user?.fullName,
      phone: user?.phone,
      city: user?.city,
      state: user?.state,
      country: user?.country,
      address: user?.address,
      bloodGroup: user?.bloodGroup,
      isAvailable: user?.isAvailable,
      isDonor: user?.isDonor,
    });
    setEditing(true);
  };

  const currentUser = user || storedUser;
  const initials = currentUser?.fullName?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?";

  const badgeLevelColors: Record<string, string> = {
    bronze: "bg-amber-700",
    silver: "bg-gray-400",
    gold: "bg-yellow-500",
    platinum: "bg-purple-600",
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary via-red-700 to-red-800 text-white px-4 pt-10 pb-16">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-6">
            <button onClick={() => setLocation("/dashboard")} className="text-red-100">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="font-bold">Profile</h1>
            <button onClick={handleLogout} className="text-red-100" data-testid="button-logout">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-4 max-w-md mx-auto -mt-10 space-y-4">
        {/* Profile Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="relative group">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                  data-testid="input-avatar-upload"
                />
                {currentUser?.profileImage ? (
                  <img src={currentUser.profileImage} alt="Profile" className="w-16 h-16 rounded-full object-cover" />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xl font-black">
                    {initials}
                  </div>
                )}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                  title="Change profile picture"
                  data-testid="button-change-avatar"
                >
                  {uploading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Camera className="w-4 h-4 text-white" />
                  )}
                </button>
                {currentUser?.isVerified && (
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                    <Star className="w-3 h-3 text-white fill-white" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h2 className="font-black text-lg leading-tight" data-testid="text-profile-name">{currentUser?.fullName}</h2>
                <p className="text-xs text-muted-foreground">{currentUser?.email}</p>
                <div className="flex items-center gap-2 mt-1.5">
                  <BloodGroupBadge group={currentUser?.bloodGroup || "O+"} size="sm" />
                  {currentUser?.isDonor && (
                    <span className="text-[10px] bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300 px-1.5 py-0.5 rounded font-medium">
                      Donor
                    </span>
                  )}
                </div>
              </div>
              <Button size="sm" variant="outline" onClick={editing ? () => setEditing(false) : startEdit} data-testid="button-edit-profile">
                {editing ? <X className="w-3.5 h-3.5" /> : <Edit2 className="w-3.5 h-3.5" />}
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-border">
              {[
                { icon: Heart, label: "Donations", value: currentUser?.totalDonations || 0 },
                { icon: Award, label: "Points", value: currentUser?.rewardPoints || 0 },
                { icon: Star, label: "Badges", value: myBadges.length },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="text-center">
                  <p className="text-lg font-black">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Edit Form */}
        {editing && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Edit Profile</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs">Full Name</Label>
                <Input value={form.fullName || ""} onChange={e => setForm(p => ({ ...p, fullName: e.target.value }))} className="mt-1" data-testid="input-edit-name" />
              </div>
              <div>
                <Label className="text-xs">Phone</Label>
                <Input value={form.phone || ""} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} className="mt-1" data-testid="input-edit-phone" />
              </div>
              <div>
                <Label className="text-xs">Blood Group</Label>
                <Select value={form.bloodGroup || ""} onValueChange={v => setForm(p => ({ ...p, bloodGroup: v as any }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {BLOOD_GROUPS.map(bg => <SelectItem key={bg} value={bg}>{bg}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Country</Label>
                <Select value={form.country || "India"} onValueChange={v => setForm(p => ({ ...p, country: v }))}>
                  <SelectTrigger className="mt-1" data-testid="select-profile-country">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent className="max-h-52 overflow-y-auto">
                    {COUNTRIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">State / Region</Label>
                  <Input value={form.state || ""} onChange={e => setForm(p => ({ ...p, state: e.target.value }))} className="mt-1" placeholder="Your state" />
                </div>
                <div>
                  <Label className="text-xs">City</Label>
                  <Input value={form.city || ""} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} className="mt-1" placeholder="Your city" />
                </div>
              </div>
              <div className="flex items-center justify-between py-1">
                <div>
                  <p className="text-xs font-medium">Available as Donor</p>
                  <p className="text-[10px] text-muted-foreground">Toggle to show/hide from donor search</p>
                </div>
                <Switch
                  checked={form.isAvailable ?? true}
                  onCheckedChange={v => setForm(p => ({ ...p, isAvailable: v }))}
                  data-testid="switch-available"
                />
              </div>
              <Button onClick={() => updateMutation.mutate(form)} disabled={updateMutation.isPending} className="w-full" data-testid="button-save-profile">
                <Save className="w-4 h-4 mr-2" />
                {updateMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Info Card */}
        <Card>
          <CardContent className="p-4 space-y-3">
            {[
              { label: "Email", value: currentUser?.email },
              { label: "Phone", value: currentUser?.phone },
              { label: "Country", value: (currentUser as any)?.country || "Not set" },
              { label: "City", value: currentUser?.city || "Not set" },
              { label: "Last Donation", value: currentUser?.lastDonationDate || "Never" },
            ].map(({ label, value }) => (
              <div key={label} className="flex items-center justify-between py-1 border-b border-border last:border-0">
                <span className="text-xs text-muted-foreground">{label}</span>
                <span className="text-xs font-medium">{value}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Badges */}
        {myBadges.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Award className="w-4 h-4 text-yellow-500" /> My Badges
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {myBadges.map(ub => (
                  <div
                    key={ub.id}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md ${badgeLevelColors[ub.badge.level || "bronze"]} text-white`}
                    title={ub.badge.description || ""}
                    data-testid={`badge-${ub.badge.id}`}
                  >
                    <span className="text-sm">{ub.badge.icon}</span>
                    <span className="text-xs font-medium">{ub.badge.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Danger Zone */}
        <Button variant="outline" className="w-full text-destructive border-destructive/30" onClick={handleLogout} data-testid="button-logout-bottom">
          <LogOut className="w-4 h-4 mr-2" /> Sign Out
        </Button>
      </div>
      <MobileNav />
    </div>
  );
}
