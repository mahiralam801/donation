import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getStoredUser } from "@/lib/auth";
import { ArrowLeft, Send, MessageCircle } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import type { ChatMessage, User } from "@shared/schema";

export default function DirectChat() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/direct-chat/:userId");
  const otherUserId = params?.userId;
  const user = getStoredUser();
  const [message, setMessage] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/direct-chat", otherUserId],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/direct-chat/${otherUserId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to load messages");
      return res.json();
    },
    refetchInterval: 3000,
    enabled: !!otherUserId,
  });

  const { data: otherUser } = useQuery<Omit<User, "password">>({
    queryKey: ["/api/users", otherUserId],
    queryFn: async () => {
      const token = localStorage.getItem("blood_token");
      const res = await fetch(`/api/users/${otherUserId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
    enabled: !!otherUserId,
  });

  useEffect(() => {
    if (otherUserId && messages.length > 0) {
      apiRequest("POST", `/api/direct-chat/${otherUserId}/read`, {});
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    }
  }, [otherUserId, messages.length]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMutation = useMutation({
    mutationFn: async (msg: string) => {
      if (!otherUserId) throw new Error("No recipient");
      const res = await apiRequest("POST", "/api/direct-chat", {
        receiverId: otherUserId,
        message: msg,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/direct-chat", otherUserId] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setMessage("");
    },
  });

  const handleSend = () => {
    if (!message.trim()) return;
    sendMutation.mutate(message.trim());
  };

  const getInitials = (name?: string) =>
    name?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?";

  const grouped = messages.reduce((acc, msg) => {
    const date = new Date(msg.createdAt!).toLocaleDateString();
    if (!acc[date]) acc[date] = [];
    acc[date].push(msg);
    return acc;
  }, {} as Record<string, ChatMessage[]>);

  return (
    <div className="flex flex-col h-screen bg-background max-w-md mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-red-700 text-white px-4 pt-10 pb-3 flex-shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setLocation("/chat")}
            className="text-red-100"
            data-testid="button-back-chat"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="relative flex-shrink-0">
            {otherUser?.profileImage ? (
              <img
                src={otherUser.profileImage}
                className="w-9 h-9 rounded-full object-cover"
                alt={otherUser.fullName}
              />
            ) : (
              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-sm font-bold">
                {getInitials(otherUser?.fullName)}
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-sm truncate" data-testid="text-chat-recipient-name">
              {otherUser?.fullName || "Donor"}
            </p>
            <div className="flex items-center gap-1">
              <span className="text-red-200 text-xs">
                {otherUser?.bloodGroup && `${otherUser.bloodGroup} • `}Direct Message
              </span>
            </div>
          </div>
          {otherUser?.phone ? (
            <button
              onClick={() => {
                const phone = otherUser.phone!.replace(/[^0-9]/g, "");
                const text = encodeURIComponent(
                  `Hi ${otherUser.fullName}, continuing our conversation from LifeFlow blood donation app.`
                );
                window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
              }}
              className="w-8 h-8 rounded-full bg-green-500/90 hover:bg-green-500 flex items-center justify-center transition-colors"
              data-testid="button-whatsapp-direct-chat"
              title="Chat on WhatsApp"
            >
              <SiWhatsapp className="w-4 h-4 text-white" />
            </button>
          ) : (
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
              <MessageCircle className="w-4 h-4 text-red-200" />
            </div>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-12 w-3/4" />
            ))}
          </div>
        )}

        {!isLoading && messages.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <MessageCircle className="w-7 h-7 text-primary" />
            </div>
            <p className="text-sm font-medium">Start the conversation</p>
            <p className="text-xs mt-1 text-muted-foreground">
              You can coordinate blood donation directly with {otherUser?.fullName || "this donor"}.
            </p>
          </div>
        )}

        {Object.entries(grouped).map(([date, msgs]) => (
          <div key={date}>
            <div className="flex items-center gap-2 my-3">
              <div className="flex-1 h-px bg-border" />
              <span className="text-[10px] text-muted-foreground px-2">{date}</span>
              <div className="flex-1 h-px bg-border" />
            </div>
            <div className="space-y-2">
              {msgs.map(msg => {
                const isMe = msg.senderId === user?.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                    data-testid={`message-${msg.id}`}
                  >
                    <div
                      className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${
                        isMe
                          ? "bg-primary text-primary-foreground rounded-br-sm"
                          : "bg-muted text-foreground rounded-bl-sm"
                      }`}
                    >
                      <p className="leading-snug">{msg.message}</p>
                      <p
                        className={`text-[10px] mt-1 ${
                          isMe
                            ? "text-primary-foreground/70 text-right"
                            : "text-muted-foreground"
                        }`}
                      >
                        {new Date(msg.createdAt!).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                        {isMe && (
                          <span className="ml-1">{msg.isRead ? "✓✓" : "✓"}</span>
                        )}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex-shrink-0 px-4 py-3 border-t border-border bg-background">
        <div className="flex items-center gap-2">
          <Input
            value={message}
            onChange={e => setMessage(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder="Type a message..."
            className="flex-1"
            data-testid="input-direct-chat-message"
          />
          <Button
            size="icon"
            onClick={handleSend}
            disabled={!message.trim() || sendMutation.isPending}
            data-testid="button-send-direct-message"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
