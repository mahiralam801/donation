import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { setToken, setStoredUser } from "@/lib/auth";
import { Droplets, Mail, RefreshCw, ArrowLeft } from "lucide-react";

export default function VerifyEmail() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const params = new URLSearchParams(window.location.search);
  const email = decodeURIComponent(params.get("email") || "");

  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (!email) setLocation("/");
    inputs.current[0]?.focus();
  }, []);

  useEffect(() => {
    if (countdown <= 0) return;
    const t = setTimeout(() => setCountdown(c => c - 1), 1000);
    return () => clearTimeout(t);
  }, [countdown]);

  const handleChange = (i: number, val: string) => {
    if (!/^\d*$/.test(val)) return;
    const next = [...otp];
    next[i] = val.slice(-1);
    setOtp(next);
    if (val && i < 5) inputs.current[i + 1]?.focus();
    if (next.every(d => d) && next.join("").length === 6) {
      setTimeout(() => handleVerify(next.join("")), 100);
    }
  };

  const handleKeyDown = (i: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[i] && i > 0) {
      inputs.current[i - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const text = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (text.length === 6) {
      setOtp(text.split(""));
      setTimeout(() => handleVerify(text), 100);
    }
  };

  const handleVerify = async (code?: string) => {
    const finalOtp = code || otp.join("");
    if (finalOtp.length !== 6) return toast({ title: "Please enter all 6 digits", variant: "destructive" });
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/auth/verify-email", { email, otp: finalOtp });
      const data = await res.json();
      setToken(data.token);
      setStoredUser(data.user);
      toast({ title: "Email verified! Welcome to LifeFlow." });
      setLocation("/dashboard");
    } catch (e: any) {
      toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" });
      setOtp(["", "", "", "", "", ""]);
      inputs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (countdown > 0) return;
    setResending(true);
    try {
      await apiRequest("POST", "/api/auth/resend-verification", { email });
      toast({ title: "New verification code sent to your email!" });
      setCountdown(60);
      setOtp(["", "", "", "", "", ""]);
      inputs.current[0]?.focus();
    } catch (e: any) {
      toast({ title: e.message?.replace(/^\d+: /, ""), variant: "destructive" });
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="relative overflow-hidden bg-gradient-to-br from-primary via-red-700 to-red-900 text-white px-6 pt-10 pb-10 text-center">
        <div className="flex justify-center mb-4">
          <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center">
            <Droplets className="w-8 h-8 text-white" />
          </div>
        </div>
        <h1 className="text-2xl font-black">LifeFlow</h1>
        <p className="text-red-200 text-xs mt-1">Blood Donation Network</p>
      </div>

      <div className="flex-1 px-4 py-8 max-w-md mx-auto w-full">
        <Card>
          <CardHeader className="pb-2 text-center">
            <div className="flex justify-center mb-3">
              <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                <Mail className="w-6 h-6 text-primary" />
              </div>
            </div>
            <CardTitle className="text-xl">Verify your email</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              We sent a 6-digit code to<br />
              <span className="font-medium text-foreground" data-testid="text-verify-email">{email}</span>
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex gap-2 justify-center" onPaste={handlePaste}>
              {otp.map((digit, i) => (
                <input
                  key={i}
                  ref={el => { inputs.current[i] = el; }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={e => handleChange(i, e.target.value)}
                  onKeyDown={e => handleKeyDown(i, e)}
                  data-testid={`input-otp-${i}`}
                  className="w-11 h-12 text-center text-xl font-bold border-2 rounded-lg bg-background focus:border-primary focus:outline-none transition-colors"
                />
              ))}
            </div>

            <Button
              onClick={() => handleVerify()}
              className="w-full"
              disabled={loading || otp.join("").length !== 6}
              data-testid="button-verify-email"
            >
              {loading ? "Verifying..." : "Verify Email"}
            </Button>

            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">Didn't receive the code?</p>
              <button
                onClick={handleResend}
                disabled={resending || countdown > 0}
                className="flex items-center gap-1.5 mx-auto text-sm text-primary font-medium disabled:text-muted-foreground"
                data-testid="button-resend-otp"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                {countdown > 0 ? `Resend in ${countdown}s` : resending ? "Sending..." : "Resend Code"}
              </button>
            </div>

            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-1 text-sm text-muted-foreground mx-auto"
              data-testid="link-back-to-login-verify"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Login
            </button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
