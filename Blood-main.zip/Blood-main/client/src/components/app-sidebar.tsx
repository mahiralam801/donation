import { useRef, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter
} from "@/components/ui/sidebar";
import { Link } from "wouter";
import {
  LayoutDashboard, Users, Droplets, Calendar, Bell, BarChart3,
  LogOut, Heart, Camera, MapPin, Mail, Settings, FileText, PanelBottomOpen,
} from "lucide-react";
import { removeToken, getStoredAdmin, setStoredAdmin } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const navItems = [
  { href: "/admin/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/admin/users", icon: Users, label: "Manage Users" },
  { href: "/admin/requests", icon: Droplets, label: "Blood Requests" },
  { href: "/admin/donors", icon: Heart, label: "Donors" },
  { href: "/admin/camps", icon: Calendar, label: "Blood Camps" },
  { href: "/admin/blood-groups", icon: Droplets, label: "Blood Groups" },
  { href: "/admin/locations", icon: MapPin, label: "Locations" },
  { href: "/admin/notifications", icon: Bell, label: "Notifications" },
  { href: "/admin/reports", icon: BarChart3, label: "Reports" },
  { href: "/admin/email-settings", icon: Mail, label: "Email Settings" },
  { href: "/admin/pages", icon: FileText, label: "Page Manager" },
  { href: "/admin/footer", icon: PanelBottomOpen, label: "Footer Manager" },
];

export function AppSidebar() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const storedAdmin = getStoredAdmin();

  const { data: adminProfile } = useQuery<any>({
    queryKey: ["/api/admin/profile"],
  });

  const admin = adminProfile || storedAdmin;
  const initials = admin?.fullName?.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2) || "A";

  const updateProfileMutation = useMutation({
    mutationFn: async (profileImage: string) => {
      const res = await apiRequest("PATCH", "/api/admin/profile", { profileImage });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/profile"] });
      if (storedAdmin) setStoredAdmin({ ...storedAdmin, ...data });
      toast({ title: "Profile picture updated!" });
    },
    onError: () => toast({ title: "Upload failed", variant: "destructive" }),
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 2MB", variant: "destructive" });
      return;
    }
    setUploading(true);
    const reader = new FileReader();
    reader.onload = () => {
      updateProfileMutation.mutate(reader.result as string);
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleLogout = () => {
    removeToken();
    setLocation("/");
  };

  return (
    <Sidebar>
      <SidebarHeader className="px-4 py-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Droplets className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="font-black text-sm text-sidebar-foreground">LifeFlow</p>
            <p className="text-xs text-sidebar-foreground/50">Admin Panel</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map(({ href, icon: Icon, label }) => {
                const isActive = location === href || location.startsWith(href + "/");
                return (
                  <SidebarMenuItem key={href}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      data-testid={`nav-admin-${label.toLowerCase().replace(/\s/g, "-")}`}
                    >
                      <Link href={href}>
                        <Icon className="w-4 h-4" />
                        <span>{label}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="px-4 py-3 border-t border-sidebar-border space-y-1">
        <div className="flex items-center gap-3 mb-2">
          <div className="relative group flex-shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleAvatarChange}
              data-testid="input-admin-avatar"
            />
            {admin?.profileImage ? (
              <img
                src={admin.profileImage}
                alt="Admin"
                className="w-9 h-9 rounded-full object-cover border-2 border-sidebar-border"
              />
            ) : (
              <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary text-sm font-black">
                {initials}
              </div>
            )}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading || updateProfileMutation.isPending}
              className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
              title="Change profile picture"
              data-testid="button-admin-change-avatar"
            >
              {uploading || updateProfileMutation.isPending ? (
                <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Camera className="w-3 h-3 text-white" />
              )}
            </button>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-sidebar-foreground truncate">{admin?.fullName || "Admin"}</p>
            <p className="text-[10px] text-sidebar-foreground/50 truncate">{admin?.email || ""}</p>
          </div>
        </div>
        <Link href="/admin/profile">
          <button
            className="flex items-center gap-2 text-xs text-sidebar-foreground/60 hover:text-sidebar-foreground px-2 py-1.5 rounded-md w-full transition-colors"
            data-testid="link-admin-profile"
          >
            <Settings className="w-3.5 h-3.5" />
            Account Settings
          </button>
        </Link>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 text-xs text-sidebar-foreground/60 hover:text-sidebar-foreground px-2 py-1.5 rounded-md w-full transition-colors"
          data-testid="button-admin-logout"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </SidebarFooter>
    </Sidebar>
  );
}
