import { Button } from "@/components/ui/button";
import { BloodGroupBadge } from "./BloodGroupBadge";
import { MapPin, Phone, Calendar, User, MessageCircle, CheckCircle, XCircle, Star, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { isEligibleToDonate, daysUntilEligible, nextEligibleDate } from "@/lib/eligibility";
import type { User as UserType } from "@shared/schema";

interface Props {
  donor: Omit<UserType, "password">;
  onContact?: () => void;
  onMessage?: () => void;
  onDirectChat?: () => void;
  onViewProfile?: () => void;
  compact?: boolean;
}

export function DonorCard({ donor, onContact, onMessage, onDirectChat, onViewProfile, compact }: Props) {
  const initials = donor.fullName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const eligible = isEligibleToDonate(donor.lastDonationDate);
  const daysLeft = daysUntilEligible(donor.lastDonationDate);
  const eligibleOn = nextEligibleDate(donor.lastDonationDate);

  const formatDate = (date: string | null | undefined) => {
    if (!date) return null;
    try {
      return new Date(date).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
    } catch {
      return date;
    }
  };

  return (
    <div
      className={cn(
        "bg-card rounded-2xl border border-border shadow-sm overflow-hidden",
        !compact && "hover:shadow-md transition-shadow duration-200"
      )}
      data-testid={`card-donor-${donor.id}`}
    >
      {/* Top strip with eligibility color */}
      <div className={cn(
        "h-1 w-full",
        eligible ? "bg-gradient-to-r from-green-400 to-emerald-500" : "bg-gradient-to-r from-orange-300 to-amber-400"
      )} />

      <div className={cn("p-4", compact && "p-3")}>
        {/* Header row: photo + name + blood group */}
        <div className="flex items-start gap-3">
          {/* Profile Photo */}
          <div className="relative flex-shrink-0">
            {donor.profileImage ? (
              <img
                src={donor.profileImage}
                alt={donor.fullName}
                className={cn(
                  "rounded-full object-cover ring-2",
                  eligible ? "ring-green-400" : "ring-orange-300",
                  compact ? "w-12 h-12" : "w-16 h-16"
                )}
              />
            ) : (
              <div className={cn(
                "rounded-full flex items-center justify-center font-black text-white ring-2",
                eligible
                  ? "ring-green-400 bg-gradient-to-br from-primary to-red-700"
                  : "ring-orange-300 bg-gradient-to-br from-orange-400 to-amber-500",
                compact ? "w-12 h-12 text-sm" : "w-16 h-16 text-lg"
              )}>
                {initials}
              </div>
            )}
          </div>

          {/* Name + badges */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className={cn(
                    "font-bold truncate",
                    compact ? "text-sm" : "text-base"
                  )} data-testid={`text-donor-name-${donor.id}`}>
                    {donor.fullName}
                  </p>
                  {donor.isVerified && (
                    <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500 flex-shrink-0" />
                  )}
                </div>
                {/* Eligibility badge */}
                <div className={cn(
                  "inline-flex items-center gap-1 mt-0.5 px-2 py-0.5 rounded-full text-[10px] font-semibold",
                  eligible
                    ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                    : "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400"
                )} data-testid={`status-donor-${donor.id}`}>
                  {eligible
                    ? <><CheckCircle className="w-2.5 h-2.5" /> Eligible to Donate</>
                    : <><Clock className="w-2.5 h-2.5" /> {daysLeft}d until eligible</>
                  }
                </div>
              </div>
              <BloodGroupBadge group={donor.bloodGroup} size={compact ? "sm" : "md"} />
            </div>
          </div>
        </div>

        {/* Info rows */}
        <div className="mt-3 space-y-1.5">
          {(donor.city || donor.state) && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <MapPin className="w-3.5 h-3.5 text-primary flex-shrink-0" />
              <span className="truncate">
                {[donor.city, donor.state].filter(Boolean).join(", ")}
              </span>
            </div>
          )}

          {donor.phone && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Phone className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
              <span className="font-mono tracking-wide" data-testid={`text-donor-phone-${donor.id}`}>{donor.phone}</span>
            </div>
          )}

          {donor.lastDonationDate && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Calendar className="w-3.5 h-3.5 text-orange-500 flex-shrink-0" />
              <span>Last donated: <span className="font-medium text-foreground">{formatDate(donor.lastDonationDate)}</span></span>
            </div>
          )}

          {!eligible && eligibleOn && (
            <div className="flex items-center gap-2 text-xs">
              <Clock className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
              <span className="text-amber-600 dark:text-amber-400">
                Eligible again: <span className="font-semibold">{formatDate(eligibleOn.toISOString())}</span>
              </span>
            </div>
          )}

          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3.5 h-3.5 flex-shrink-0 flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-primary/30 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              </div>
            </div>
            <span>{donor.totalDonations || 0} donation{(donor.totalDonations || 0) !== 1 ? "s" : ""}</span>
          </div>
        </div>

        {/* Action buttons */}
        {(onContact || onMessage || onDirectChat || onViewProfile) && (
          <div className="flex gap-2 mt-3 pt-3 border-t border-border">
            {onViewProfile && (
              <Button
                size="sm"
                variant="ghost"
                className="flex-1 h-8 text-xs text-muted-foreground"
                onClick={onViewProfile}
                data-testid={`button-view-profile-${donor.id}`}
              >
                <User className="w-3.5 h-3.5 mr-1" /> Profile
              </Button>
            )}
            {onContact && (
              <Button
                size="sm"
                variant="outline"
                className="flex-1 h-8 text-xs border-blue-200 text-blue-600 hover:bg-blue-50 dark:border-blue-800 dark:text-blue-400"
                onClick={onContact}
                data-testid={`button-contact-donor-${donor.id}`}
              >
                <Phone className="w-3.5 h-3.5 mr-1" /> Call
              </Button>
            )}
            {onDirectChat && (
              <Button
                size="sm"
                variant="outline"
                className="flex-1 h-8 text-xs border-primary/30 text-primary hover:bg-primary/5"
                onClick={onDirectChat}
                data-testid={`button-direct-chat-${donor.id}`}
              >
                <MessageCircle className="w-3.5 h-3.5 mr-1" /> Chat
              </Button>
            )}
            {onMessage && (
              <Button
                size="sm"
                className="flex-1 h-8 text-xs"
                onClick={onMessage}
                data-testid={`button-message-donor-${donor.id}`}
              >
                Request
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
