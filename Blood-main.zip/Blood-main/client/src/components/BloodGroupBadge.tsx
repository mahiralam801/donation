import { cn } from "@/lib/utils";

const BG_COLORS: Record<string, string> = {
  "A+":  "bg-red-600 text-white",
  "A-":  "bg-red-800 text-white",
  "B+":  "bg-orange-500 text-white",
  "B-":  "bg-orange-700 text-white",
  "AB+": "bg-purple-600 text-white",
  "AB-": "bg-purple-800 text-white",
  "O+":  "bg-sky-600 text-white",
  "O-":  "bg-sky-800 text-white",
};

interface Props {
  group: string;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

export function BloodGroupBadge({ group, size = "md", className }: Props) {
  const sizes = {
    sm:  "text-xs px-1.5 py-0.5 rounded",
    md:  "text-sm px-2 py-1 rounded-md font-semibold",
    lg:  "text-lg px-3 py-1.5 rounded-md font-bold",
    xl:  "text-2xl px-4 py-2 rounded-lg font-black",
  };
  return (
    <span
      data-testid={`badge-blood-group-${group}`}
      className={cn(
        "inline-flex items-center justify-center leading-none",
        BG_COLORS[group] || "bg-red-600 text-white",
        sizes[size],
        className
      )}
    >
      {group}
    </span>
  );
}
