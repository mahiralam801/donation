const DONATION_COOLDOWN_DAYS = 90;

export function isEligibleToDonate(lastDonationDate: string | null | undefined): boolean {
  if (!lastDonationDate) return true;
  const last = new Date(lastDonationDate);
  if (isNaN(last.getTime())) return true;
  const today = new Date();
  const daysDiff = Math.floor((today.getTime() - last.getTime()) / (1000 * 60 * 60 * 24));
  return daysDiff >= DONATION_COOLDOWN_DAYS;
}

export function daysUntilEligible(lastDonationDate: string | null | undefined): number {
  if (!lastDonationDate) return 0;
  const last = new Date(lastDonationDate);
  if (isNaN(last.getTime())) return 0;
  const today = new Date();
  const daysDiff = Math.floor((today.getTime() - last.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, DONATION_COOLDOWN_DAYS - daysDiff);
}

export function nextEligibleDate(lastDonationDate: string | null | undefined): Date | null {
  if (!lastDonationDate) return null;
  const last = new Date(lastDonationDate);
  if (isNaN(last.getTime())) return null;
  const eligible = new Date(last);
  eligible.setDate(eligible.getDate() + DONATION_COOLDOWN_DAYS);
  return eligible;
}

export function eligibilityLabel(lastDonationDate: string | null | undefined): string {
  if (isEligibleToDonate(lastDonationDate)) return "Eligible to Donate";
  const days = daysUntilEligible(lastDonationDate);
  return `Not Eligible (${days}d remaining)`;
}
