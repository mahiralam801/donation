export interface AuthUser {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  bloodGroup: string;
  city?: string;
  state?: string;
  address?: string;
  isAvailable?: boolean;
  isDonor?: boolean;
  totalDonations?: number;
  rewardPoints?: number;
  profileImage?: string;
  lastDonationDate?: string;
  isVerified?: boolean;
}

export function getToken(): string | null {
  return localStorage.getItem("blood_token");
}

export function setToken(token: string): void {
  localStorage.setItem("blood_token", token);
}

export function removeToken(): void {
  localStorage.removeItem("blood_token");
  localStorage.removeItem("blood_user");
  localStorage.removeItem("blood_admin");
}

export function getStoredUser(): AuthUser | null {
  const u = localStorage.getItem("blood_user");
  return u ? JSON.parse(u) : null;
}

export function setStoredUser(user: AuthUser): void {
  localStorage.setItem("blood_user", JSON.stringify(user));
}

export function getStoredAdmin(): { id: string; fullName: string; email: string; username: string } | null {
  const a = localStorage.getItem("blood_admin");
  return a ? JSON.parse(a) : null;
}

export function setStoredAdmin(admin: any): void {
  localStorage.setItem("blood_admin", JSON.stringify(admin));
}

export function isLoggedIn(): boolean {
  return !!getToken() && !!getStoredUser();
}

export function isAdminLoggedIn(): boolean {
  return !!getToken() && !!getStoredAdmin();
}

export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] as const;

export function bloodGroupColor(bg: string): string {
  const colors: Record<string, string> = {
    "A+": "#dc2626", "A-": "#b91c1c",
    "B+": "#ea580c", "B-": "#c2410c",
    "AB+": "#7c3aed", "AB-": "#6d28d9",
    "O+": "#0284c7", "O-": "#0369a1",
  };
  return colors[bg] || "#dc2626";
}

export function urgencyColor(urgency: string): string {
  const colors: Record<string, string> = {
    normal: "bg-secondary text-secondary-foreground",
    urgent: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
    emergency: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
  };
  return colors[urgency] || colors.normal;
}

export function statusColor(status: string): string {
  const colors: Record<string, string> = {
    pending:    "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300",
    accepted:   "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
    approved:   "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
    donor_found:"bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
    rejected:   "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
    fulfilled:  "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
    completed:  "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
    cancelled:  "bg-gray-100 text-gray-600 dark:bg-gray-900/30 dark:text-gray-400",
    scheduled:  "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  };
  return colors[status] || colors.pending;
}

export function statusLabel(status: string): string {
  const labels: Record<string, string> = {
    pending:    "Pending",
    accepted:   "Accepted",
    approved:   "Accepted",
    donor_found:"Accepted",
    rejected:   "Rejected",
    fulfilled:  "Completed",
    completed:  "Completed",
    cancelled:  "Cancelled",
    scheduled:  "Scheduled",
  };
  return labels[status] || status.charAt(0).toUpperCase() + status.slice(1);
}

export function timeSince(date: string | Date): string {
  const d = new Date(date);
  const now = new Date();
  const secs = Math.floor((now.getTime() - d.getTime()) / 1000);
  if (secs < 60) return "just now";
  if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
  if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
  if (secs < 604800) return `${Math.floor(secs / 86400)}d ago`;
  return d.toLocaleDateString();
}
