import { Switch, Route, useLocation, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { isLoggedIn, isAdminLoggedIn } from "@/lib/auth";

// User pages
import Landing from "@/pages/Landing";
import Register from "@/pages/Register";
import VerifyEmail from "@/pages/VerifyEmail";
import Dashboard from "@/pages/Dashboard";
import FindDonors from "@/pages/FindDonors";
import RequestBlood from "@/pages/RequestBlood";
import MyRequests from "@/pages/MyRequests";
import Donations from "@/pages/Donations";
import Camps from "@/pages/Camps";
import Chat from "@/pages/Chat";
import ChatRoom from "@/pages/ChatRoom";
import DirectChat from "@/pages/DirectChat";
import Profile from "@/pages/Profile";
import Notifications from "@/pages/Notifications";
import Rewards from "@/pages/Rewards";
import DonorProfile from "@/pages/DonorProfile";
import OpenRequests from "@/pages/OpenRequests";
import EmergencyAlert from "@/pages/EmergencyAlert";
import NotFound from "@/pages/not-found";

// Admin pages
import AdminLogin from "@/pages/admin/AdminLogin";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminUsers from "@/pages/admin/AdminUsers";
import AdminRequests from "@/pages/admin/AdminRequests";
import AdminDonors from "@/pages/admin/AdminDonors";
import AdminCamps from "@/pages/admin/AdminCamps";
import AdminNotifications from "@/pages/admin/AdminNotifications";
import AdminReports from "@/pages/admin/AdminReports";
import AdminBloodGroups from "@/pages/admin/AdminBloodGroups";
import AdminLocations from "@/pages/admin/AdminLocations";
import AdminEmailSettings from "@/pages/admin/AdminEmailSettings";
import AdminProfile from "@/pages/admin/AdminProfile";
import AdminPages from "@/pages/admin/AdminPages";
import AdminFooter from "@/pages/admin/AdminFooter";
import StaticPage from "@/pages/StaticPage";

function ProtectedRoute({ component: Component }: { component: () => JSX.Element }) {
  if (!isLoggedIn()) return <Redirect to="/" />;
  return <Component />;
}

function AdminProtectedRoute({ component: Component }: { component: () => JSX.Element }) {
  if (!isAdminLoggedIn()) return <Redirect to="/admin" />;
  return <Component />;
}

function AdminLayout({ children }: { children: React.ReactNode }) {
  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center gap-3 px-4 py-3 border-b border-border bg-background sticky top-0 z-40">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span className="text-sm font-semibold text-muted-foreground">LifeFlow Admin</span>
            </div>
          </header>
          <main className="flex-1 overflow-y-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function AdminRouter() {
  return (
    <Switch>
      <Route path="/admin" component={AdminLogin} />
      <Route path="/admin/dashboard">
        <AdminLayout>
          <AdminProtectedRoute component={AdminDashboard} />
        </AdminLayout>
      </Route>
      <Route path="/admin/users">
        <AdminLayout>
          <AdminProtectedRoute component={AdminUsers} />
        </AdminLayout>
      </Route>
      <Route path="/admin/requests">
        <AdminLayout>
          <AdminProtectedRoute component={AdminRequests} />
        </AdminLayout>
      </Route>
      <Route path="/admin/donors">
        <AdminLayout>
          <AdminProtectedRoute component={AdminDonors} />
        </AdminLayout>
      </Route>
      <Route path="/admin/camps">
        <AdminLayout>
          <AdminProtectedRoute component={AdminCamps} />
        </AdminLayout>
      </Route>
      <Route path="/admin/notifications">
        <AdminLayout>
          <AdminProtectedRoute component={AdminNotifications} />
        </AdminLayout>
      </Route>
      <Route path="/admin/reports">
        <AdminLayout>
          <AdminProtectedRoute component={AdminReports} />
        </AdminLayout>
      </Route>
      <Route path="/admin/blood-groups">
        <AdminLayout>
          <AdminProtectedRoute component={AdminBloodGroups} />
        </AdminLayout>
      </Route>
      <Route path="/admin/locations">
        <AdminLayout>
          <AdminProtectedRoute component={AdminLocations} />
        </AdminLayout>
      </Route>
      <Route path="/admin/donors/:id">
        <AdminLayout>
          <AdminProtectedRoute component={DonorProfile} />
        </AdminLayout>
      </Route>
      <Route path="/admin/email-settings">
        <AdminLayout>
          <AdminProtectedRoute component={AdminEmailSettings} />
        </AdminLayout>
      </Route>
      <Route path="/admin/profile">
        <AdminLayout>
          <AdminProtectedRoute component={AdminProfile} />
        </AdminLayout>
      </Route>
      <Route path="/admin/pages">
        <AdminLayout>
          <AdminProtectedRoute component={AdminPages} />
        </AdminLayout>
      </Route>
      <Route path="/admin/footer">
        <AdminLayout>
          <AdminProtectedRoute component={AdminFooter} />
        </AdminLayout>
      </Route>
    </Switch>
  );
}

function UserRouter() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/register" component={Register} />
      <Route path="/verify-email" component={VerifyEmail} />
      <Route path="/dashboard">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/find-donors">
        <ProtectedRoute component={FindDonors} />
      </Route>
      <Route path="/open-requests">
        <ProtectedRoute component={OpenRequests} />
      </Route>
      <Route path="/emergency-alert">
        <ProtectedRoute component={EmergencyAlert} />
      </Route>
      <Route path="/request-blood">
        <ProtectedRoute component={RequestBlood} />
      </Route>
      <Route path="/my-requests">
        <ProtectedRoute component={MyRequests} />
      </Route>
      <Route path="/donations">
        <ProtectedRoute component={Donations} />
      </Route>
      <Route path="/camps">
        <ProtectedRoute component={Camps} />
      </Route>
      <Route path="/direct-chat/:userId">
        <ProtectedRoute component={DirectChat} />
      </Route>
      <Route path="/chat/:requestId">
        <ProtectedRoute component={ChatRoom} />
      </Route>
      <Route path="/chat">
        <ProtectedRoute component={Chat} />
      </Route>
      <Route path="/profile">
        <ProtectedRoute component={Profile} />
      </Route>
      <Route path="/notifications">
        <ProtectedRoute component={Notifications} />
      </Route>
      <Route path="/rewards">
        <ProtectedRoute component={Rewards} />
      </Route>
      <Route path="/donor/:id">
        <ProtectedRoute component={DonorProfile} />
      </Route>
      <Route path="/pages/:slug" component={StaticPage} />
    </Switch>
  );
}

function Router() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  if (isAdminRoute) {
    return <AdminRouter />;
  }
  return <UserRouter />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
