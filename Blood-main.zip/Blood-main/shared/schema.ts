import { pgTable, text, varchar, integer, boolean, timestamp, real, pgEnum, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const bloodGroupEnum = pgEnum("blood_group", ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]);
export const requestStatusEnum = pgEnum("request_status", ["pending", "approved", "accepted", "rejected", "donor_found", "fulfilled", "cancelled"]);
export const urgencyEnum = pgEnum("urgency", ["normal", "urgent", "emergency"]);
export const donationStatusEnum = pgEnum("donation_status", ["scheduled", "completed", "cancelled"]);
export const notificationTypeEnum = pgEnum("notification_type", ["request", "acceptance", "camp", "system", "reward"]);
export const badgeLevelEnum = pgEnum("badge_level", ["bronze", "silver", "gold", "platinum"]);

export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().unique(),
  password: text("password").notNull(),
  bloodGroup: bloodGroupEnum("blood_group").notNull(),
  dateOfBirth: text("date_of_birth"),
  gender: text("gender"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  country: text("country").default("India"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  isAvailable: boolean("is_available").default(true),
  isDonor: boolean("is_donor").default(true),
  totalDonations: integer("total_donations").default(0),
  rewardPoints: integer("reward_points").default(0),
  profileImage: text("profile_image"),
  lastDonationDate: text("last_donation_date"),
  isVerified: boolean("is_verified").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const adminUsers = pgTable("admin_users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  role: text("role").default("admin"),
  profileImage: text("profile_image"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bloodRequests = pgTable("blood_requests", {
  id: varchar("id", { length: 36 }).primaryKey(),
  requesterId: varchar("requester_id", { length: 36 }).notNull().references(() => users.id),
  patientName: text("patient_name").notNull(),
  bloodGroup: bloodGroupEnum("blood_group").notNull(),
  unitsNeeded: integer("units_needed").notNull(),
  hospital: text("hospital").notNull(),
  city: text("city").notNull(),
  state: text("state"),
  contactPhone: text("contact_phone").notNull(),
  contactName: text("contact_name"),
  district: text("district"),
  requestType: text("request_type").default("user_to_donor"),
  urgency: urgencyEnum("urgency").default("normal"),
  status: requestStatusEnum("status").default("pending"),
  donorId: varchar("donor_id", { length: 36 }).references(() => users.id),
  notes: text("notes"),
  requiredByDate: text("required_by_date"),
  requisitionForm: text("requisition_form"),
  requisitionFormType: text("requisition_form_type"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const donations = pgTable("donations", {
  id: varchar("id", { length: 36 }).primaryKey(),
  donorId: varchar("donor_id", { length: 36 }).notNull().references(() => users.id),
  requestId: varchar("request_id", { length: 36 }).references(() => bloodRequests.id),
  bloodGroup: bloodGroupEnum("blood_group").notNull(),
  units: integer("units").default(1),
  hospital: text("hospital"),
  city: text("city"),
  donationDate: text("donation_date").notNull(),
  status: donationStatusEnum("status").default("completed"),
  certificateId: text("certificate_id"),
  pointsEarned: integer("points_earned").default(100),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bloodCamps = pgTable("blood_camps", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  organizer: text("organizer").notNull(),
  venue: text("venue").notNull(),
  city: text("city").notNull(),
  state: text("state"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  startTime: text("start_time"),
  endTime: text("end_time"),
  targetUnits: integer("target_units").default(100),
  collectedUnits: integer("collected_units").default(0),
  maxParticipants: integer("max_participants").default(200),
  registeredCount: integer("registered_count").default(0),
  contactPhone: text("contact_phone"),
  contactEmail: text("contact_email"),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const campRegistrations = pgTable("camp_registrations", {
  id: varchar("id", { length: 36 }).primaryKey(),
  campId: varchar("camp_id", { length: 36 }).notNull().references(() => bloodCamps.id),
  userId: varchar("user_id", { length: 36 }).notNull().references(() => users.id),
  registeredAt: timestamp("registered_at").defaultNow(),
  attended: boolean("attended").default(false),
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id", { length: 36 }).primaryKey(),
  requestId: varchar("request_id", { length: 36 }),
  senderId: varchar("sender_id", { length: 36 }).notNull().references(() => users.id),
  receiverId: varchar("receiver_id", { length: 36 }).notNull().references(() => users.id),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 36 }).references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: notificationTypeEnum("type").default("system"),
  isRead: boolean("is_read").default(false),
  isGlobal: boolean("is_global").default(false),
  relatedId: varchar("related_id", { length: 36 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const badges = pgTable("badges", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon").notNull(),
  level: badgeLevelEnum("level").default("bronze"),
  pointsRequired: integer("points_required").default(100),
  donationsRequired: integer("donations_required").default(1),
});

export const userBadges = pgTable("user_badges", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 36 }).notNull().references(() => users.id),
  badgeId: varchar("badge_id", { length: 36 }).notNull().references(() => badges.id),
  earnedAt: timestamp("earned_at").defaultNow(),
});

export const bloodGroups = pgTable("blood_groups", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 10 }).notNull().unique(),
  description: text("description"),
  color: varchar("color", { length: 30 }).default("bg-red-500"),
  isRare: boolean("is_rare").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  country: text("country").notNull(),
  state: text("state"),
  city: text("city"),
  address: text("address"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, totalDonations: true, rewardPoints: true });
export const insertBloodRequestSchema = createInsertSchema(bloodRequests).omit({ id: true, createdAt: true, updatedAt: true, status: true, donorId: true, requesterId: true });
export const insertDonationSchema = createInsertSchema(donations).omit({ id: true, createdAt: true, certificateId: true });
export const insertCampSchema = createInsertSchema(bloodCamps).omit({ id: true, createdAt: true, registeredCount: true, collectedUnits: true });
export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({ id: true, createdAt: true, isRead: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true, isRead: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type AdminUser = typeof adminUsers.$inferSelect;
export type BloodRequest = typeof bloodRequests.$inferSelect;
export type InsertBloodRequest = z.infer<typeof insertBloodRequestSchema>;
export type Donation = typeof donations.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type BloodCamp = typeof bloodCamps.$inferSelect;
export type InsertCamp = z.infer<typeof insertCampSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Badge = typeof badges.$inferSelect;
export type UserBadge = typeof userBadges.$inferSelect;
export type CampRegistration = typeof campRegistrations.$inferSelect;
export type BloodGroup = typeof bloodGroups.$inferSelect;
export const insertBloodGroupSchema = createInsertSchema(bloodGroups).omit({ id: true, createdAt: true });
export type InsertBloodGroup = z.infer<typeof insertBloodGroupSchema>;

export type Location = typeof locations.$inferSelect;
export const insertLocationSchema = createInsertSchema(locations).omit({ id: true, createdAt: true });
export type InsertLocation = z.infer<typeof insertLocationSchema>;

export const emailVerifications = pgTable("email_verifications", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 36 }).notNull(),
  otp: varchar("otp", { length: 6 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export type EmailVerification = typeof emailVerifications.$inferSelect;

export const smtpSettings = pgTable("smtp_settings", {
  id: serial("id").primaryKey(),
  smtpHost: text("smtp_host").default("smtp.gmail.com"),
  smtpPort: integer("smtp_port").default(587),
  smtpUsername: text("smtp_username").default(""),
  smtpPassword: text("smtp_password").default(""),
  smtpEncryption: text("smtp_encryption").default("tls"),
  fromEmail: text("from_email").default(""),
  fromName: text("from_name").default("LifeFlow"),
  enabled: boolean("enabled").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type SmtpSettings = typeof smtpSettings.$inferSelect;

export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  emailType: text("email_type").notNull().unique(),
  subject: text("subject").notNull(),
  bodyHtml: text("body_html").notNull(),
  logoUrl: text("logo_url"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type EmailTemplate = typeof emailTemplates.$inferSelect;

export const emailSettings = pgTable("email_settings", {
  id: serial("id").primaryKey(),
  emailVerificationEnabled: boolean("email_verification_enabled").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const sitePages = pgTable("site_pages", {
  id: serial("id").primaryKey(),
  pageType: text("page_type").notNull().unique(),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  isPublished: boolean("is_published").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type SitePage = typeof sitePages.$inferSelect;

export const footerSettings = pgTable("footer_settings", {
  id: serial("id").primaryKey(),
  brandName: text("brand_name").notNull().default("LifeFlow"),
  brandTagline: text("brand_tagline").notNull().default("Blood Donation Network"),
  brandDescription: text("brand_description").notNull().default("Connecting donors with patients in need. Every drop counts — be the reason someone smiles today."),
  showBloodTypes: boolean("show_blood_types").default(true),
  quickLinks: text("quick_links").notNull().default('[{"label":"Home","href":"/"},{"label":"Register","href":"/register"},{"label":"About Us","href":"/pages/about"},{"label":"Contact Us","href":"/pages/contact"}]'),
  legalLinks: text("legal_links").notNull().default('[{"label":"Privacy Policy","href":"/pages/privacy"},{"label":"Terms of Use","href":"/pages/terms"},{"label":"Disclaimer","href":"/pages/disclaimer"}]'),
  contactEmail: text("contact_email").notNull().default("support@lifeflow.app"),
  contactPhone: text("contact_phone").notNull().default("+1 (800) LIFEFLOW"),
  contactAddress: text("contact_address").notNull().default("Available Worldwide"),
  showEmergencyBanner: boolean("show_emergency_banner").default(true),
  emergencyTitle: text("emergency_title").notNull().default("Need Blood Urgently?"),
  emergencyText: text("emergency_text").notNull().default("Post an emergency request — donors respond within minutes."),
  copyrightText: text("copyright_text").notNull().default("LifeFlow Blood Donation Network. All rights reserved."),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type FooterSettings = typeof footerSettings.$inferSelect;
