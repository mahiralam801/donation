import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage, db } from "./storage";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { insertUserSchema, insertBloodRequestSchema, insertDonationSchema, insertCampSchema, insertChatMessageSchema, adminUsers } from "@shared/schema";
import { generateOTP, sendVerificationEmail, isEmailVerificationEnabled } from "./email";

const JWT_SECRET = process.env.SESSION_SECRET || "blooddonation_jwt_secret_2024";

interface AuthRequest extends Request {
  user?: { id: string; role?: string };
}

function generateToken(id: string, role?: string) {
  return jwt.sign({ id, role }, JWT_SECRET, { expiresIn: "30d" });
}

function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ message: "No token provided" });
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; role?: string };
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ message: "Invalid token" });
  }
}

function adminMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  authMiddleware(req, res, () => {
    if (req.user?.role !== "admin") return res.status(403).json({ message: "Admin access required" });
    next();
  });
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // === USER AUTH ===
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const existing = await storage.getUserByEmail(data.email);
      if (existing) return res.status(400).json({ message: "Email already registered" });
      const existingPhone = await storage.getUserByPhone(data.phone);
      if (existingPhone) return res.status(400).json({ message: "Phone already registered" });
      const hashed = await bcrypt.hash(data.password, 10);
      const verificationRequired = await isEmailVerificationEnabled();
      const user = await storage.createUser({ ...data, id: randomUUID(), password: hashed, isVerified: !verificationRequired });
      if (verificationRequired) {
        const otp = generateOTP();
        await storage.createEmailVerification(randomUUID(), user.id, otp);
        try { await sendVerificationEmail(user.email, user.fullName, otp); } catch (_) {}
        return res.json({ message: "Registration successful. Please verify your email.", email: user.email, requiresVerification: true });
      }
      const token = generateToken(user.id);
      const { password: _, ...safeUser } = user;
      res.json({ user: safeUser, token, requiresVerification: false });
    } catch (e: any) {
      res.status(400).json({ message: e.message || "Registration failed" });
    }
  });

  app.post("/api/auth/verify-email", async (req, res) => {
    try {
      const { email, otp } = req.body;
      if (!email || !otp) return res.status(400).json({ message: "Email and OTP are required" });
      const user = await storage.getUserByEmail(email.toLowerCase().trim());
      if (!user) return res.status(404).json({ message: "Account not found" });
      if (user.isVerified) return res.status(400).json({ message: "Email already verified" });
      const verification = await storage.getLatestEmailVerification(user.id);
      if (!verification) return res.status(400).json({ message: "No verification code found. Please request a new one." });
      if (new Date() > verification.expiresAt) return res.status(400).json({ message: "Verification code expired. Please request a new one." });
      if (verification.otp !== otp.trim()) return res.status(400).json({ message: "Invalid verification code" });
      await storage.markEmailVerificationUsed(verification.id);
      await storage.updateUser(user.id, { isVerified: true });
      const token = generateToken(user.id);
      const { password: _, ...safeUser } = { ...user, isVerified: true };
      res.json({ user: safeUser, token, message: "Email verified successfully!" });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.post("/api/auth/resend-verification", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) return res.status(400).json({ message: "Email is required" });
      const user = await storage.getUserByEmail(email.toLowerCase().trim());
      if (!user) return res.status(404).json({ message: "Account not found" });
      if (user.isVerified) return res.status(400).json({ message: "Email already verified" });
      const otp = generateOTP();
      await storage.createEmailVerification(randomUUID(), user.id, otp);
      try { await sendVerificationEmail(user.email, user.fullName, otp); } catch (_) {}
      res.json({ message: "Verification code sent!" });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      if (!user) return res.status(401).json({ message: "Invalid email or password" });
      const valid = await bcrypt.compare(password, user.password);
      if (!valid) return res.status(401).json({ message: "Invalid email or password" });
      if (!user.isActive) return res.status(401).json({ message: "Account deactivated" });
      if (!user.isVerified) return res.status(403).json({ message: "Please verify your email before logging in.", needsVerification: true, email: user.email });
      const token = generateToken(user.id);
      const { password: _, ...safeUser } = user;
      res.json({ user: safeUser, token });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { email, phone, newPassword } = req.body;
      if (!email || !phone || !newPassword) return res.status(400).json({ message: "Email, phone and new password are required" });
      if (newPassword.length < 6) return res.status(400).json({ message: "Password must be at least 6 characters" });
      const user = await storage.getUserByEmail(email.toLowerCase().trim());
      if (!user) return res.status(404).json({ message: "No account found with this email" });
      const phoneClean = phone.replace(/\s/g, "");
      const storedPhone = (user.phone || "").replace(/\s/g, "");
      if (storedPhone !== phoneClean) return res.status(400).json({ message: "Phone number does not match our records" });
      const hashed = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(user.id, { password: hashed });
      res.json({ message: "Password reset successfully" });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: AuthRequest, res) => {
    const user = await storage.getUser(req.user!.id);
    if (!user) return res.status(404).json({ message: "User not found" });
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  // === PUBLIC STATS (no auth required) ===
  app.get("/api/stats", async (_req, res) => {
    const stats = await storage.getStats();
    res.json({
      activeDonors: stats.activeDonors,
      livesSaved: stats.totalDonations,
      campsHeld: stats.totalCamps,
    });
  });

  // === ADMIN AUTH ===
  app.post("/api/admin/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const admin = await storage.getAdminByUsername(username);
      if (!admin) return res.status(401).json({ message: "Invalid credentials" });
      const valid = await bcrypt.compare(password, admin.password);
      if (!valid) return res.status(401).json({ message: "Invalid credentials" });
      const token = generateToken(admin.id, "admin");
      const { password: _, ...safeAdmin } = admin;
      res.json({ admin: safeAdmin, token });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  // === USERS ===
  app.get("/api/users", adminMiddleware, async (req, res) => {
    const allUsers = await storage.getAllUsers();
    res.json(allUsers.map(({ password: _, ...u }) => u));
  });

  app.get("/api/users/:id", authMiddleware, async (req: AuthRequest, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) return res.status(404).json({ message: "Not found" });
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.patch("/api/users/:id", authMiddleware, async (req: AuthRequest, res) => {
    if (req.user!.id !== req.params.id && req.user!.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    const { password: _, id: __, ...data } = req.body;
    const updated = await storage.updateUser(req.params.id, data);
    if (!updated) return res.status(404).json({ message: "Not found" });
    const { password: _p, ...safeUser } = updated;
    res.json(safeUser);
  });

  app.patch("/api/admin/users/:id/status", adminMiddleware, async (req: AuthRequest, res) => {
    const { isActive } = req.body;
    const updated = await storage.updateUser(req.params.id, { isActive });
    if (!updated) return res.status(404).json({ message: "Not found" });
    res.json({ success: true });
  });

  // Partial update for any donor/user fields (used by AdminDonors toggles and photo upload)
  app.patch("/api/admin/users/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const allowed = ["fullName", "email", "phone", "bloodGroup", "city", "state", "country",
        "isActive", "isAvailable", "isVerified", "isDonor", "profilePhoto", "lastDonationDate",
        "rewardPoints", "totalDonations"];
      const updates: Record<string, any> = {};
      for (const key of allowed) {
        if (req.body[key] !== undefined) updates[key] = req.body[key];
      }
      if (Object.keys(updates).length === 0) return res.status(400).json({ message: "No valid fields to update" });
      const updated = await storage.updateUser(req.params.id, updates);
      if (!updated) return res.status(404).json({ message: "User not found" });
      const { password: _, ...safeUser } = updated;
      res.json(safeUser);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.post("/api/admin/users", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { fullName, email, phone, password, bloodGroup, city, state, country, isDonor, isActive } = req.body;
      if (!fullName || !email || !phone || !password || !bloodGroup) {
        return res.status(400).json({ message: "Name, email, phone, password and blood group are required" });
      }
      const existing = await storage.getUserByEmail(email);
      if (existing) return res.status(400).json({ message: "Email already registered" });
      const hashed = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        id: randomUUID(), fullName, email, phone, password: hashed,
        bloodGroup, city: city || null, state: state || null, country: country || null,
        isDonor: isDonor ?? false, isActive: isActive ?? true, isVerified: true,
      });
      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.put("/api/admin/users/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { fullName, email, phone, bloodGroup, city, state, country, isActive, lastDonationDate, isAvailable, isVerified } = req.body;
      const updated = await storage.updateUser(req.params.id, {
        fullName, email, phone, bloodGroup, city, state, country, isActive,
        ...(lastDonationDate !== undefined && { lastDonationDate: lastDonationDate || null }),
        ...(isAvailable !== undefined && { isAvailable }),
        ...(isVerified !== undefined && { isVerified }),
      });
      if (!updated) return res.status(404).json({ message: "User not found" });
      const { password: _, ...safeUser } = updated;
      res.json(safeUser);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.delete("/api/admin/users/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) return res.status(404).json({ message: "User not found" });
      await storage.deleteUser(req.params.id);
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  // === DONORS ===
  app.get("/api/donors/locations", authMiddleware, async (_req, res) => {
    const allUsers = await storage.getAllUsers();
    const donors = allUsers.filter(u => u.isDonor && u.isActive);
    const countrySet = new Set<string>();
    const stateMap: Record<string, Set<string>> = {};
    const statesByCountry: Record<string, Set<string>> = {};
    for (const d of donors) {
      const country = (d.country || "").trim();
      const s = (d.state || "").trim();
      const c = (d.city || "").trim();
      if (country) countrySet.add(country);
      if (s) {
        if (!stateMap[s]) stateMap[s] = new Set();
        if (c) stateMap[s].add(c);
        if (country) {
          if (!statesByCountry[country]) statesByCountry[country] = new Set();
          statesByCountry[country].add(s);
        }
      }
    }
    const result: Record<string, string[]> = {};
    for (const [s, cities] of Object.entries(stateMap)) {
      result[s] = Array.from(cities).sort();
    }
    const sbcResult: Record<string, string[]> = {};
    for (const [country, states] of Object.entries(statesByCountry)) {
      sbcResult[country] = Array.from(states).sort();
    }
    res.json({
      countries: Array.from(countrySet).sort(),
      states: Object.keys(result).sort(),
      cities: result,
      statesByCountry: sbcResult,
    });
  });

  app.get("/api/donors", authMiddleware, async (req, res) => {
    const { bloodGroup, country, state, city } = req.query;
    let donors = await storage.getAllUsers();
    donors = donors.filter(u => u.isDonor && u.isActive);

    // 90-day eligibility rule: only show donors eligible to donate again
    const today = new Date();
    donors = donors.filter(u => {
      if (!u.lastDonationDate) return true;
      const last = new Date(u.lastDonationDate);
      if (isNaN(last.getTime())) return true;
      const daysDiff = Math.floor((today.getTime() - last.getTime()) / (1000 * 60 * 60 * 24));
      return daysDiff >= 90;
    });

    if (bloodGroup && bloodGroup !== "all") {
      donors = donors.filter(u => u.bloodGroup === bloodGroup);
    }
    if (country && country !== "all") {
      donors = donors.filter(u => (u.country || "").toLowerCase() === (country as string).toLowerCase());
    }
    if (state) {
      donors = donors.filter(u => (u.state || "").toLowerCase() === (state as string).toLowerCase());
    }
    if (city) {
      donors = donors.filter(u => (u.city || "").toLowerCase().includes((city as string).toLowerCase()));
    }
    res.json(donors.map(({ password: _, ...u }) => u));
  });

  // === BLOOD REQUESTS ===
  app.post("/api/requests", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertBloodRequestSchema.parse(req.body);
      const requestType = req.body.requestType || "user_to_donor";
      const contactName = req.body.contactName || null;
      const district = req.body.district || null;
      const requisitionForm = req.body.requisitionForm || null;
      const requisitionFormType = req.body.requisitionFormType || null;
      const request = await storage.createBloodRequest({
        ...data,
        id: randomUUID(),
        requesterId: req.user!.id,
        requestType,
        contactName,
        district,
        requisitionForm,
        requisitionFormType,
      });

      if (requestType === "user_to_donor" || requestType === "emergency_alert") {
        const isEmergency = data.urgency === "emergency" || requestType === "emergency_alert";
        const limit = isEmergency ? 50 : 10;
        const allDonors = await storage.getDonorsByBloodGroup(data.bloodGroup);

        let notifyList = allDonors;
        if (isEmergency) {
          const district = req.body.district || null;
          const requestCity = (data.city || "").toLowerCase();
          const requestState = (data.state || "").toLowerCase();
          const requestDistrict = (district || "").toLowerCase();

          const sameCity = allDonors.filter(d =>
            (d.city || "").toLowerCase().includes(requestCity) || requestCity.includes((d.city || "").toLowerCase())
          );
          const sameState = allDonors.filter(d =>
            !sameCity.find(x => x.id === d.id) &&
            (d.state || "").toLowerCase() === requestState
          );
          const rest = allDonors.filter(d =>
            !sameCity.find(x => x.id === d.id) && !sameState.find(x => x.id === d.id)
          );
          notifyList = [...sameCity, ...sameState, ...rest];
        }

        for (const donor of notifyList.slice(0, limit)) {
          const titlePrefix = isEmergency ? "🚨 EMERGENCY" : data.urgency === "urgent" ? "⚠️ Urgent" : "Blood Request";
          await storage.createNotification({
            id: randomUUID(),
            userId: donor.id,
            title: `${titlePrefix}: ${data.bloodGroup} blood needed at ${data.hospital}`,
            message: `${isEmergency ? "🚨 Emergency! " : ""}${data.unitsNeeded} unit(s) of ${data.bloodGroup} needed at ${data.hospital}, ${data.city}${data.state ? `, ${data.state}` : ""}. Contact: ${data.contactPhone}`,
            type: "request",
            relatedId: request.id,
          });
        }
      }
      res.json(request);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.get("/api/requests", authMiddleware, async (req: AuthRequest, res) => {
    const requests = await storage.getUserRequests(req.user!.id);
    res.json(requests);
  });

  app.get("/api/requests/all", adminMiddleware, async (req, res) => {
    const requests = await storage.getAllRequests();
    res.json(requests);
  });

  app.put("/api/admin/requests/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { patientName, bloodGroup, unitsNeeded, hospital, city, state, district, contactPhone, contactName, urgency, status, notes, requiredByDate, requestType } = req.body;
      const updated = await storage.updateBloodRequest(req.params.id, {
        patientName, bloodGroup, unitsNeeded, hospital, city, state, district, contactPhone, contactName, urgency, status, notes, requiredByDate, requestType,
      });
      if (!updated) return res.status(404).json({ message: "Request not found" });

      // Notify requester when admin accepts or rejects
      if (["accepted", "approved", "donor_found", "rejected", "fulfilled"].includes(status)) {
        const titleMap: Record<string, string> = {
          accepted:   "Your blood request was accepted",
          approved:   "Your blood request was accepted",
          donor_found:"A donor has been found for your request",
          rejected:   "Your blood request was rejected",
          fulfilled:  "Your blood request is now completed",
        };
        const msgMap: Record<string, string> = {
          accepted:   `Your request for ${updated.bloodGroup} blood at ${updated.hospital} has been accepted by admin.`,
          approved:   `Your request for ${updated.bloodGroup} blood at ${updated.hospital} has been approved.`,
          donor_found:`A donor has been matched for ${updated.bloodGroup} blood at ${updated.hospital}.`,
          rejected:   `Your request for ${updated.bloodGroup} blood at ${updated.hospital} was not fulfilled.`,
          fulfilled:  `Your blood request for ${updated.patientName} has been successfully completed.`,
        };
        await storage.createNotification({
          id: randomUUID(),
          userId: updated.requesterId,
          title: titleMap[status] || "Blood request update",
          message: msgMap[status] || `Your request status changed to ${status}.`,
          type: "request",
          relatedId: updated.id,
        });
      }

      res.json(updated);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.delete("/api/admin/requests/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const request = await storage.getBloodRequest(req.params.id);
      if (!request) return res.status(404).json({ message: "Request not found" });
      await storage.deleteBloodRequest(req.params.id);
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  // IMPORTANT: specific paths must come before /api/requests/:id to avoid param conflict
  app.get("/api/requests/open", authMiddleware, async (req: AuthRequest, res) => {
    // Active requests visible to donors:
    // - user_to_donor: show when pending/approved/donor_found
    // - user_to_admin: only show after admin approves (approved/donor_found)
    const all = await storage.getAllRequests();
    const open = all.filter(r => {
      if (r.requesterId === req.user!.id) return false;
      const status = r.status || "pending";
      const requestType = (r as any).requestType || "user_to_donor";
      if (requestType === "user_to_admin") {
        return ["approved", "donor_found"].includes(status);
      }
      return ["pending", "approved", "donor_found"].includes(status);
    });
    res.json(open);
  });

  app.get("/api/requests/open/:bloodGroup", authMiddleware, async (req, res) => {
    const requests = await storage.getOpenRequestsByBloodGroup(req.params.bloodGroup);
    res.json(requests);
  });

  app.get("/api/requests/:id", authMiddleware, async (req, res) => {
    const req2 = await storage.getBloodRequest(req.params.id);
    if (!req2) return res.status(404).json({ message: "Not found" });
    res.json(req2);
  });

  app.patch("/api/requests/:id", authMiddleware, async (req: AuthRequest, res) => {
    const request = await storage.getBloodRequest(req.params.id);
    if (!request) return res.status(404).json({ message: "Not found" });

    const { status, donorId } = req.body;

    // Prevent requester from accepting their own request
    if (status === "accepted" && request.requesterId === req.user!.id) {
      return res.status(403).json({ message: "You cannot accept your own blood request" });
    }

    // Only allow requester to cancel their own request
    if (status === "cancelled" && request.requesterId !== req.user!.id && req.user!.role !== "admin") {
      return res.status(403).json({ message: "Only the requester can cancel this request" });
    }

    const updated = await storage.updateBloodRequest(req.params.id, { status, ...(donorId ? { donorId } : {}) });

    // Notify requester when a donor accepts
    if (status === "accepted") {
      await storage.createNotification({
        id: randomUUID(),
        userId: request.requesterId,
        title: "Donor Found!",
        message: `A donor has accepted your blood request for ${request.patientName}`,
        type: "acceptance",
        relatedId: request.id,
      });
    }
    res.json(updated);
  });

  // === DONATIONS ===
  app.post("/api/donations", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertDonationSchema.parse(req.body);
      const certId = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      const donation = await storage.createDonation({ ...data, id: randomUUID(), certificateId: certId, donorId: req.user!.id });

      // Update user donation count and points
      const user = await storage.getUser(req.user!.id);
      if (user) {
        const newCount = (user.totalDonations || 0) + 1;
        const newPoints = (user.rewardPoints || 0) + 100;
        await storage.updateUser(req.user!.id, {
          totalDonations: newCount,
          rewardPoints: newPoints,
          lastDonationDate: data.donationDate,
        });
        await storage.checkAndAwardBadges(req.user!.id);
      }
      res.json(donation);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.get("/api/users/:id/donations", authMiddleware, async (req, res) => {
    const list = await storage.getUserDonations(req.params.id);
    res.json(list);
  });

  app.get("/api/donations", authMiddleware, async (req: AuthRequest, res) => {
    const list = await storage.getUserDonations(req.user!.id);
    res.json(list);
  });

  app.get("/api/donations/all", adminMiddleware, async (req, res) => {
    const list = await storage.getAllDonations();
    res.json(list);
  });

  app.get("/api/donations/:id", authMiddleware, async (req, res) => {
    const donation = await storage.getDonation(req.params.id);
    if (!donation) return res.status(404).json({ message: "Not found" });
    res.json(donation);
  });

  // === BLOOD CAMPS ===
  app.get("/api/camps", async (req, res) => {
    const camps = await storage.getActiveCamps();
    res.json(camps);
  });

  app.get("/api/camps/all", adminMiddleware, async (req, res) => {
    const camps = await storage.getAllCamps();
    res.json(camps);
  });

  app.post("/api/camps", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertCampSchema.parse(req.body);
      const camp = await storage.createCamp({ ...data, id: randomUUID() });
      res.json(camp);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.patch("/api/camps/:id", adminMiddleware, async (req, res) => {
    const updated = await storage.updateCamp(req.params.id, req.body);
    if (!updated) return res.status(404).json({ message: "Not found" });
    res.json(updated);
  });

  app.post("/api/camps/:id/register", authMiddleware, async (req: AuthRequest, res) => {
    const already = await storage.isUserRegisteredForCamp(req.user!.id, req.params.id);
    if (already) return res.status(400).json({ message: "Already registered" });
    const reg = await storage.registerForCamp(randomUUID(), req.params.id, req.user!.id);
    res.json(reg);
  });

  app.get("/api/camps/:id/registrations", authMiddleware, async (req, res) => {
    const regs = await storage.getCampRegistrations(req.params.id);
    res.json(regs);
  });

  app.get("/api/my-registrations", authMiddleware, async (req: AuthRequest, res) => {
    const regs = await storage.getUserCampRegistrations(req.user!.id);
    res.json(regs);
  });

  // === CHAT ===
  app.post("/api/chat", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertChatMessageSchema.omit({ senderId: true }).parse(req.body);
      const msg = await storage.createMessage({ ...data, id: randomUUID(), senderId: req.user!.id });
      res.json(msg);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.get("/api/chat/:requestId", authMiddleware, async (req, res) => {
    const msgs = await storage.getRequestMessages(req.params.requestId);
    res.json(msgs);
  });

  app.get("/api/conversations", authMiddleware, async (req: AuthRequest, res) => {
    const convs = await storage.getUserConversations(req.user!.id);
    res.json(convs);
  });

  app.post("/api/chat/:requestId/read", authMiddleware, async (req: AuthRequest, res) => {
    await storage.markMessagesRead(req.params.requestId, req.user!.id);
    res.json({ success: true });
  });

  // === DIRECT CHAT (Donor-to-Donor) ===
  app.get("/api/direct-chat/:userId", authMiddleware, async (req: AuthRequest, res) => {
    const msgs = await storage.getDirectMessages(req.user!.id, req.params.userId);
    res.json(msgs);
  });

  app.post("/api/direct-chat", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const { receiverId, message } = req.body;
      if (!receiverId || !message) return res.status(400).json({ message: "receiverId and message required" });
      const msg = await storage.createMessage({
        id: randomUUID(),
        senderId: req.user!.id,
        receiverId,
        message,
        requestId: null as any,
      });
      res.json(msg);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.post("/api/direct-chat/:userId/read", authMiddleware, async (req: AuthRequest, res) => {
    await storage.markDirectMessagesRead(req.params.userId, req.user!.id);
    res.json({ success: true });
  });

  // === NOTIFICATIONS ===
  app.get("/api/notifications", authMiddleware, async (req: AuthRequest, res) => {
    const notifs = await storage.getUserNotifications(req.user!.id);
    res.json(notifs);
  });

  app.post("/api/notifications/:id/read", authMiddleware, async (req, res) => {
    await storage.markNotificationRead(req.params.id);
    res.json({ success: true });
  });

  app.post("/api/notifications/read-all", authMiddleware, async (req: AuthRequest, res) => {
    await storage.markAllNotificationsRead(req.user!.id);
    res.json({ success: true });
  });

  app.post("/api/admin/notifications/broadcast", adminMiddleware, async (req, res) => {
    const { title, message } = req.body;
    const notif = await storage.createGlobalNotification(title, message);
    res.json(notif);
  });

  // === REWARDS & BADGES ===
  app.get("/api/badges", authMiddleware, async (req, res) => {
    const allBadges = await storage.getAllBadges();
    res.json(allBadges);
  });

  app.get("/api/my-badges", authMiddleware, async (req: AuthRequest, res) => {
    const ubs = await storage.getUserBadges(req.user!.id);
    res.json(ubs);
  });

  // === ANALYTICS ===
  app.get("/api/admin/stats", adminMiddleware, async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  // === ADMIN PROFILE ===
  app.get("/api/admin/profile", adminMiddleware, async (req: AuthRequest, res) => {
    const result = await db.select().from(adminUsers).where(eq(adminUsers.id, req.user!.id)).limit(1);
    const admin = result[0];
    if (!admin) return res.status(404).json({ message: "Admin not found" });
    const { password: _, ...safe } = admin;
    res.json(safe);
  });

  app.patch("/api/admin/profile", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { fullName, profileImage, email, phone, username } = req.body;
      // Check username uniqueness if changing
      if (username && username !== req.user!.username) {
        const existing = await storage.getAdminByUsername(username);
        if (existing && existing.id !== req.user!.id) {
          return res.status(400).json({ message: "Username already taken" });
        }
      }
      // Check email uniqueness if changing
      if (email && email !== req.user!.email) {
        const existing = await storage.getAdminByEmail(email);
        if (existing && existing.id !== req.user!.id) {
          return res.status(400).json({ message: "Email already in use" });
        }
      }
      const updated = await storage.updateAdmin(req.user!.id, { fullName, profileImage, email, phone, username });
      if (!updated) return res.status(404).json({ message: "Admin not found" });
      const { password: _, ...safe } = updated;
      res.json(safe);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.post("/api/admin/change-password", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current and new password are required" });
      }
      if (newPassword.length < 6) {
        return res.status(400).json({ message: "New password must be at least 6 characters" });
      }
      const result = await db.select().from(adminUsers).where(eq(adminUsers.id, req.user!.id)).limit(1);
      const admin = result[0];
      if (!admin) return res.status(404).json({ message: "Admin not found" });
      const valid = await bcrypt.compare(currentPassword, admin.password);
      if (!valid) return res.status(400).json({ message: "Current password is incorrect" });
      const hashed = await bcrypt.hash(newPassword, 10);
      await storage.updateAdmin(req.user!.id, { password: hashed });
      res.json({ message: "Password changed successfully" });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  // === BLOOD GROUPS ===
  app.get("/api/blood-groups", async (req, res) => {
    const groups = await storage.getAllBloodGroups();
    res.json(groups);
  });

  app.post("/api/admin/blood-groups", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { name, description, color, isRare, isActive } = req.body;
      if (!name) return res.status(400).json({ message: "Name is required" });
      const group = await storage.createBloodGroup({ name, description, color, isRare, isActive });
      res.status(201).json(group);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.put("/api/admin/blood-groups/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const { name, description, color, isRare, isActive } = req.body;
      const updated = await storage.updateBloodGroup(id, { name, description, color, isRare, isActive });
      if (!updated) return res.status(404).json({ message: "Blood group not found" });
      res.json(updated);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.delete("/api/admin/blood-groups/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteBloodGroup(id);
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  // === LOCATIONS ===
  app.get("/api/admin/locations", adminMiddleware, async (_req, res) => {
    const locs = await storage.getAllLocations();
    res.json(locs);
  });

  app.post("/api/admin/locations", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { country, state, city, address, isActive } = req.body;
      if (!country) return res.status(400).json({ message: "Country is required" });
      const loc = await storage.createLocation({ country, state, city, address, isActive: isActive !== false });
      res.status(201).json(loc);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.put("/api/admin/locations/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const { country, state, city, address, isActive } = req.body;
      if (!country) return res.status(400).json({ message: "Country is required" });
      const updated = await storage.updateLocation(id, { country, state, city, address, isActive });
      if (!updated) return res.status(404).json({ message: "Location not found" });
      res.json(updated);
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.delete("/api/admin/locations/:id", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteLocation(id);
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  // === ADMIN SMTP SETTINGS ===
  app.get("/api/admin/smtp", adminMiddleware, async (_req, res) => {
    try {
      const smtp = await storage.getSmtpSettings();
      if (smtp) {
        const { smtpPassword: _, ...safe } = smtp;
        res.json({ ...safe, smtpPassword: smtp.smtpPassword ? "••••••••" : "" });
      } else {
        res.json({
          smtpHost: "smtp.gmail.com", smtpPort: 587, smtpUsername: process.env.GMAIL_USER || "",
          smtpPassword: "", smtpEncryption: "tls",
          fromEmail: process.env.GMAIL_USER || "", fromName: "LifeFlow", enabled: true,
        });
      }
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.put("/api/admin/smtp", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = req.body;
      if (data.smtpPassword === "••••••••") {
        delete data.smtpPassword;
      }
      const result = await storage.upsertSmtpSettings(data);
      const { smtpPassword: _, ...safe } = result;
      res.json({ ...safe, smtpPassword: result.smtpPassword ? "••••••••" : "" });
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.post("/api/admin/smtp/test", adminMiddleware, async (req: AuthRequest, res) => {
    try {
      const { testEmail } = req.body;
      if (!testEmail) return res.status(400).json({ message: "Test email address required" });
      const nodemailer = (await import("nodemailer")).default;
      const smtp = await storage.getSmtpSettings();
      let transporter: any;
      let from: string;
      if (smtp && smtp.smtpHost && smtp.smtpUsername && smtp.smtpPassword) {
        transporter = nodemailer.createTransport({
          host: smtp.smtpHost, port: smtp.smtpPort || 587,
          secure: smtp.smtpEncryption === "ssl",
          auth: { user: smtp.smtpUsername, pass: smtp.smtpPassword },
        });
        from = `"${smtp.fromName || "LifeFlow"}" <${smtp.fromEmail || smtp.smtpUsername}>`;
      } else {
        transporter = nodemailer.createTransport({
          service: "gmail",
          auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD },
        });
        from = `"LifeFlow" <${process.env.GMAIL_USER}>`;
      }
      await transporter.sendMail({
        from, to: testEmail,
        subject: "LifeFlow SMTP Test Email",
        html: `<div style="font-family:Arial,sans-serif;padding:24px;"><h2 style="color:#D32F2F;">SMTP Test Successful!</h2><p>Your email configuration is working correctly.</p></div>`,
      });
      res.json({ message: "Test email sent successfully!" });
    } catch (e: any) { res.status(400).json({ message: `SMTP Error: ${e.message}` }); }
  });

  // === ADMIN EMAIL TEMPLATES ===
  app.get("/api/admin/email-templates", adminMiddleware, async (_req, res) => {
    try {
      const templates = await storage.getEmailTemplates();
      res.json(templates);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.get("/api/admin/email-templates/:type", adminMiddleware, async (req, res) => {
    try {
      const tpl = await storage.getEmailTemplate(req.params.type);
      res.json(tpl || null);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.put("/api/admin/email-templates/:type", adminMiddleware, async (req, res) => {
    try {
      const result = await storage.upsertEmailTemplate(req.params.type, req.body);
      res.json(result);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  // === SITE PAGES (Public) ===
  app.get("/api/pages/:type", async (req, res) => {
    try {
      const page = await storage.getSitePage(req.params.type);
      if (!page) return res.status(404).json({ message: "Page not found" });
      res.json(page);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  // === SITE PAGES (Admin) ===
  app.get("/api/admin/pages", adminMiddleware, async (_req, res) => {
    try {
      const pages = await storage.getAllSitePages();
      res.json(pages);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.put("/api/admin/pages/:type", adminMiddleware, async (req, res) => {
    try {
      const { title, content, isPublished } = req.body;
      if (!title) return res.status(400).json({ message: "Title is required" });
      const page = await storage.upsertSitePage(req.params.type, { title, content: content || "", isPublished: isPublished ?? true });
      res.json(page);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  // === PUBLIC FEATURED DONORS (no auth) ===
  app.get("/api/public/donors/featured", async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit as string || "12"), 24);
      const all = await storage.getAllUsers();
      const featured = all
        .filter(u => u.isDonor && u.isActive && u.isAvailable)
        .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
        .slice(0, limit)
        .map(({ password, ...u }) => u);
      res.json(featured);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  // === FOOTER SETTINGS ===
  app.get("/api/public/footer", async (_req, res) => {
    try {
      const settings = await storage.getFooterSettings();
      res.json(settings || {});
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.get("/api/admin/footer", adminMiddleware, async (_req, res) => {
    try {
      const settings = await storage.getFooterSettings();
      res.json(settings || {});
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.put("/api/admin/footer", adminMiddleware, async (req, res) => {
    try {
      const settings = await storage.upsertFooterSettings(req.body);
      res.json(settings);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  // === ADMIN EMAIL SETTINGS ===
  app.get("/api/admin/email-settings", adminMiddleware, async (_req, res) => {
    try {
      const settings = await storage.getEmailSettings();
      res.json(settings);
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  app.put("/api/admin/email-settings", adminMiddleware, async (req, res) => {
    try {
      const { emailVerificationEnabled } = req.body;
      await storage.setEmailVerificationEnabled(emailVerificationEnabled);
      res.json({ emailVerificationEnabled });
    } catch (e: any) { res.status(400).json({ message: e.message }); }
  });

  return httpServer;
}
