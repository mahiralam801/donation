import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import { db, storage } from "./storage";
import { users, adminUsers, bloodRequests, donations, bloodCamps, badges, chatMessages } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  try {
    // Check if already seeded
    const existing = await db.select().from(adminUsers).limit(1);
    if (existing.length > 0) {
      console.log("[seed] Database already seeded, skipping.");
      return;
    }

    console.log("[seed] Seeding database...");

    // Create admin
    const adminHash = await bcrypt.hash("admin123", 10);
    await db.insert(adminUsers).values({
      id: randomUUID(),
      username: "admin",
      email: "admin@lifeflow.com",
      password: adminHash,
      fullName: "Admin User",
      role: "admin",
      isActive: true,
    });

    // Seed users
    const userIds = Array.from({ length: 8 }, () => randomUUID());
    const usersData = [
      { id: userIds[0], fullName: "Sarah Johnson", email: "sarah@example.com", phone: "+15551001001", bloodGroup: "O+" as const, city: "New York", state: "NY", isDonor: true, isAvailable: true, totalDonations: 8, rewardPoints: 800, isVerified: true },
      { id: userIds[1], fullName: "Michael Chen", email: "michael@example.com", phone: "+15551001002", bloodGroup: "A+" as const, city: "Los Angeles", state: "CA", isDonor: true, isAvailable: true, totalDonations: 12, rewardPoints: 1200, isVerified: true },
      { id: userIds[2], fullName: "Emma Davis", email: "emma@example.com", phone: "+15551001003", bloodGroup: "B+" as const, city: "Chicago", state: "IL", isDonor: true, isAvailable: false, totalDonations: 3, rewardPoints: 300 },
      { id: userIds[3], fullName: "James Wilson", email: "james@example.com", phone: "+15551001004", bloodGroup: "AB+" as const, city: "Houston", state: "TX", isDonor: true, isAvailable: true, totalDonations: 5, rewardPoints: 500, isVerified: true },
      { id: userIds[4], fullName: "Priya Patel", email: "priya@example.com", phone: "+15551001005", bloodGroup: "O-" as const, city: "Phoenix", state: "AZ", isDonor: true, isAvailable: true, totalDonations: 15, rewardPoints: 1500, isVerified: true },
      { id: userIds[5], fullName: "Robert Brown", email: "robert@example.com", phone: "+15551001006", bloodGroup: "A-" as const, city: "Philadelphia", state: "PA", isDonor: false, isAvailable: false, totalDonations: 0, rewardPoints: 0 },
      { id: userIds[6], fullName: "Maria Garcia", email: "maria@example.com", phone: "+15551001007", bloodGroup: "B-" as const, city: "San Antonio", state: "TX", isDonor: true, isAvailable: true, totalDonations: 2, rewardPoints: 200 },
      { id: userIds[7], fullName: "David Kim", email: "david@example.com", phone: "+15551001008", bloodGroup: "AB-" as const, city: "Dallas", state: "TX", isDonor: true, isAvailable: true, totalDonations: 6, rewardPoints: 600, isVerified: true },
    ];

    const pwHash = await bcrypt.hash("password123", 10);
    for (const u of usersData) {
      await db.insert(users).values({ ...u, password: pwHash, isActive: true }).onConflictDoNothing();
    }

    // Seed blood requests
    const requestIds = Array.from({ length: 4 }, () => randomUUID());
    const requestsData = [
      { id: requestIds[0], requesterId: userIds[0], patientName: "John Smith", bloodGroup: "O+" as const, unitsNeeded: 2, hospital: "NYC General Hospital", city: "New York", state: "NY", contactPhone: "+15559001001", urgency: "urgent" as const, status: "accepted" as const, donorId: userIds[1] },
      { id: requestIds[1], requesterId: userIds[2], patientName: "Linda Davis", bloodGroup: "B+" as const, unitsNeeded: 1, hospital: "Rush University Medical Center", city: "Chicago", state: "IL", contactPhone: "+15559001002", urgency: "emergency" as const, status: "pending" as const },
      { id: requestIds[2], requesterId: userIds[5], patientName: "Thomas Brown", bloodGroup: "A-" as const, unitsNeeded: 3, hospital: "Jefferson Hospital", city: "Philadelphia", state: "PA", contactPhone: "+15559001003", urgency: "normal" as const, status: "accepted" as const, donorId: userIds[4] },
      { id: requestIds[3], requesterId: userIds[3], patientName: "Anna Wilson", bloodGroup: "AB+" as const, unitsNeeded: 2, hospital: "Houston Methodist", city: "Houston", state: "TX", contactPhone: "+15559001004", urgency: "urgent" as const, status: "fulfilled" as const, donorId: userIds[4] },
    ];

    for (const r of requestsData) {
      await db.insert(bloodRequests).values(r as any).onConflictDoNothing();
    }

    // Seed chat messages for conversations
    const now = new Date();
    const messagesData = [
      { id: randomUUID(), requestId: requestIds[0], senderId: userIds[0], receiverId: userIds[1], message: "Hi Michael, I see you're available to donate O+ blood. Can you help?", createdAt: new Date(now.getTime() - 3600000).toISOString(), isRead: true },
      { id: randomUUID(), requestId: requestIds[0], senderId: userIds[1], receiverId: userIds[0], message: "Of course! I'll be at NYC General Hospital tomorrow morning. Will that work?", createdAt: new Date(now.getTime() - 3000000).toISOString(), isRead: true },
      { id: randomUUID(), requestId: requestIds[0], senderId: userIds[0], receiverId: userIds[1], message: "That's perfect! Thank you so much. The hospital address is 100 Broadway, NY.", createdAt: new Date(now.getTime() - 1800000).toISOString(), isRead: false },
      { id: randomUUID(), requestId: requestIds[2], senderId: userIds[4], receiverId: userIds[5], message: "Hello Robert! I can donate A- blood for Thomas. When is it needed?", createdAt: new Date(now.getTime() - 7200000).toISOString(), isRead: true },
      { id: randomUUID(), requestId: requestIds[2], senderId: userIds[5], receiverId: userIds[4], message: "We need it by Friday. The hospital is Jefferson Hospital in Philadelphia.", createdAt: new Date(now.getTime() - 5400000).toISOString(), isRead: true },
    ];

    for (const m of messagesData) {
      await db.insert(chatMessages).values(m as any).onConflictDoNothing();
    }

    // Seed donations
    const donationsData = [
      { id: randomUUID(), donorId: userIds[0], bloodGroup: "O+" as const, units: 1, hospital: "NYC Blood Center", city: "New York", donationDate: "2025-01-15", status: "completed" as const, certificateId: "CERT-2025-001", pointsEarned: 100 },
      { id: randomUUID(), donorId: userIds[1], bloodGroup: "A+" as const, units: 1, hospital: "LA Blood Bank", city: "Los Angeles", donationDate: "2025-02-20", status: "completed" as const, certificateId: "CERT-2025-002", pointsEarned: 100 },
      { id: randomUUID(), donorId: userIds[4], bloodGroup: "O-" as const, units: 2, hospital: "Phoenix Children's Hospital", city: "Phoenix", donationDate: "2025-03-10", status: "completed" as const, certificateId: "CERT-2025-003", pointsEarned: 100 },
      { id: randomUUID(), donorId: userIds[7], bloodGroup: "AB-" as const, units: 1, hospital: "Dallas Medical Center", city: "Dallas", donationDate: "2025-03-22", status: "completed" as const, certificateId: "CERT-2025-004", pointsEarned: 100 },
    ];

    for (const d of donationsData) {
      await db.insert(donations).values(d as any).onConflictDoNothing();
    }

    // Seed blood camps
    const today = new Date();
    const future1 = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    const future2 = new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    const future3 = new Date(today.getTime() + 21 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    const past1 = new Date(today.getTime() - 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

    const campsData = [
      { id: randomUUID(), title: "Community Blood Drive 2026", organizer: "Red Cross NYC", venue: "Central Park Pavilion", city: "New York", state: "NY", startDate: future1, endDate: future1, startTime: "09:00", endTime: "17:00", targetUnits: 200, maxParticipants: 300, registeredCount: 87, contactPhone: "+15558001001", isActive: true, description: "Join us for our annual community blood drive. Free refreshments and t-shirts for all donors!" },
      { id: randomUUID(), title: "University Campus Drive", organizer: "UCLA Medical Center", venue: "UCLA Bruin Plaza", city: "Los Angeles", state: "CA", startDate: future2, endDate: future2, startTime: "10:00", endTime: "16:00", targetUnits: 150, maxParticipants: 200, registeredCount: 45, contactPhone: "+15558001002", isActive: true, description: "Students and faculty are encouraged to donate. Earn community service hours!" },
      { id: randomUUID(), title: "Houston Health Fair Blood Drive", organizer: "Houston Blood Bank", venue: "Reliant Center Hall A", city: "Houston", state: "TX", startDate: future3, endDate: future3, startTime: "08:00", endTime: "18:00", targetUnits: 300, maxParticipants: 400, registeredCount: 120, contactPhone: "+15558001003", isActive: true, description: "Part of the Houston Annual Health Fair. Donors receive a free health checkup." },
      { id: randomUUID(), title: "Winter Blood Drive 2025", organizer: "Chicago Blood Services", venue: "Navy Pier Grand Ballroom", city: "Chicago", state: "IL", startDate: past1, endDate: past1, startTime: "09:00", endTime: "15:00", targetUnits: 100, maxParticipants: 150, registeredCount: 140, collectedUnits: 115, contactPhone: "+15558001004", isActive: false, description: "Our winter blood drive was a great success! Thank you to all who participated." },
    ];

    for (const c of campsData) {
      await db.insert(bloodCamps).values(c as any).onConflictDoNothing();
    }

    // Seed badges
    const badgesData = [
      { id: randomUUID(), name: "First Drop", description: "Complete your first blood donation", icon: "🩸", level: "bronze" as const, donationsRequired: 1, pointsRequired: 100 },
      { id: randomUUID(), name: "Life Saver", description: "Complete 3 blood donations", icon: "❤️", level: "silver" as const, donationsRequired: 3, pointsRequired: 300 },
      { id: randomUUID(), name: "Blood Hero", description: "Complete 10 blood donations", icon: "🏆", level: "gold" as const, donationsRequired: 10, pointsRequired: 1000 },
      { id: randomUUID(), name: "Legend Donor", description: "Complete 25 blood donations", icon: "👑", level: "platinum" as const, donationsRequired: 25, pointsRequired: 2500 },
      { id: randomUUID(), name: "Community Champion", description: "Attend 3 blood donation camps", icon: "🌟", level: "silver" as const, donationsRequired: 1, pointsRequired: 500 },
    ];

    for (const b of badgesData) {
      await db.insert(badges).values(b as any).onConflictDoNothing();
    }

    console.log("[seed] Database seeded successfully!");
  } catch (error) {
    console.error("[seed] Error seeding database:", error);
  }
}
