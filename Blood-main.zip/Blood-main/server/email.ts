import nodemailer from "nodemailer";
import { storage } from "./storage";

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

async function getTransporter() {
  const smtp = await storage.getSmtpSettings();
  if (smtp && smtp.smtpHost && smtp.smtpUsername && smtp.smtpPassword) {
    return {
      transporter: nodemailer.createTransport({
        host: smtp.smtpHost,
        port: smtp.smtpPort || 587,
        secure: smtp.smtpEncryption === "ssl",
        auth: { user: smtp.smtpUsername, pass: smtp.smtpPassword },
      }),
      from: `"${smtp.fromName || "LifeFlow"}" <${smtp.fromEmail || smtp.smtpUsername}>`,
    };
  }
  return {
    transporter: nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD },
    }),
    from: `"LifeFlow" <${process.env.GMAIL_USER}>`,
  };
}

function buildEmailHtml(content: string, logoUrl?: string | null): string {
  const logo = logoUrl
    ? `<img src="${logoUrl}" alt="LifeFlow" style="height:40px;margin-bottom:8px;" />`
    : `<div style="display:inline-flex;align-items:center;gap:8px;margin-bottom:8px;">
        <div style="width:36px;height:36px;background:#D32F2F;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M12 2C12 2 4 10 4 15a8 8 0 0016 0C20 10 12 2 12 2Z"/></svg>
        </div>
        <span style="font-family:Arial,sans-serif;font-size:22px;font-weight:900;color:#fff;">LifeFlow</span>
       </div>`;
  return `
    <div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #f0f0f0;">
      <div style="background:linear-gradient(135deg,#B71C1C,#D32F2F);padding:28px 24px;text-align:center;">
        ${logo}
      </div>
      <div style="padding:32px 24px;">${content}</div>
    </div>`;
}

async function getTemplateOrDefault(type: string, defaults: { subject: string; body: (otp: string, name: string) => string }) {
  try {
    const tpl = await storage.getEmailTemplate(type);
    return tpl || null;
  } catch {
    return null;
  }
}

export async function sendVerificationEmail(to: string, name: string, otp: string): Promise<void> {
  const { transporter, from } = await getTransporter();
  const tpl = await getTemplateOrDefault("verification", {
    subject: "Verify your LifeFlow account",
    body: (o, n) => ``,
  });

  const subject = tpl?.subject?.replace("{{name}}", name).replace("{{otp}}", otp) || `Verify your LifeFlow account`;

  const defaultBody = `
    <h2 style="color:#111;font-size:20px;margin:0 0 8px;">Verify your email, ${name.split(" ")[0]}!</h2>
    <p style="color:#555;font-size:14px;margin:0 0 24px;line-height:1.6;">
      Thank you for joining LifeFlow. Enter the code below to verify your email address.
    </p>
    <div style="background:#fef2f2;border:2px dashed #D32F2F;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px;">
      <p style="color:#888;font-size:12px;margin:0 0 8px;text-transform:uppercase;letter-spacing:1px;">Verification code</p>
      <p style="color:#D32F2F;font-size:40px;font-weight:900;letter-spacing:12px;margin:0;">${otp}</p>
      <p style="color:#999;font-size:11px;margin:8px 0 0;">Expires in 15 minutes</p>
    </div>
    <p style="color:#999;font-size:12px;text-align:center;margin:0;">If you didn't create an account, you can safely ignore this email.</p>`;

  const body = tpl?.bodyHtml
    ? tpl.bodyHtml.replace("{{name}}", name).replace("{{otp}}", otp).replace("{{first_name}}", name.split(" ")[0])
    : defaultBody;

  await transporter.sendMail({
    from,
    to,
    subject,
    html: buildEmailHtml(body, tpl?.logoUrl),
  });
}

export async function sendPasswordResetEmail(to: string, name: string, otp: string): Promise<void> {
  const { transporter, from } = await getTransporter();
  const tpl = await getTemplateOrDefault("password_reset", { subject: "", body: () => "" });

  const subject = tpl?.subject?.replace("{{name}}", name).replace("{{otp}}", otp) || "Reset your LifeFlow password";

  const defaultBody = `
    <h2 style="color:#111;font-size:20px;margin:0 0 8px;">Password Reset Request</h2>
    <p style="color:#555;font-size:14px;margin:0 0 24px;line-height:1.6;">
      Hi ${name.split(" ")[0]}, use the code below to reset your password.
    </p>
    <div style="background:#fef2f2;border:2px dashed #D32F2F;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px;">
      <p style="color:#888;font-size:12px;margin:0 0 8px;text-transform:uppercase;letter-spacing:1px;">Reset code</p>
      <p style="color:#D32F2F;font-size:40px;font-weight:900;letter-spacing:12px;margin:0;">${otp}</p>
      <p style="color:#999;font-size:11px;margin:8px 0 0;">Expires in 15 minutes</p>
    </div>
    <p style="color:#999;font-size:12px;text-align:center;margin:0;">If you didn't request a reset, ignore this email.</p>`;

  const body = tpl?.bodyHtml
    ? tpl.bodyHtml.replace("{{name}}", name).replace("{{otp}}", otp).replace("{{first_name}}", name.split(" ")[0])
    : defaultBody;

  await transporter.sendMail({
    from,
    to,
    subject,
    html: buildEmailHtml(body, tpl?.logoUrl),
  });
}

export async function isEmailVerificationEnabled(): Promise<boolean> {
  try {
    const settings = await storage.getEmailSettings();
    return settings.emailVerificationEnabled;
  } catch {
    return true;
  }
}
